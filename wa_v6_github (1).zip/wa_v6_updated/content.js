/**
 * content.js
 * WhatsApp Unsaved Number Manager - Content Script
 * v2.1 — Added: Label Filter Bar (display:none fix), Contact→Label Assignment (right-click), Quick Replies, Download Contacts
 */

(function () {
  "use strict";

  // ─── Constants ────────────────────────────────────────────────────────────
  const SCAN_INTERVAL_MS = 3000;
  const PHONE_REGEX = /^\+?[\d\s\-().]{7,20}$/;
  const INDIAN_REGEX = /^(\+91|91)?[6-9]\d{9}$/;
  const QR_STORAGE_KEY  = "wnum_quick_replies";
  // QR item: { type:'text'|'photo', label:string, text?:string, images?:string[] }
  function normalizeQR(list) {
    return list.map(item => {
      if (typeof item === "string") return { type:"text", label:item, text:item };
      return item;
    });
  }
  const DEFAULT_QR = [
    { type:"text",  label:"Hello! How can we help you? 😊",   text:"Hello! How can we help you? 😊" },
    { type:"text",  label:"Hello! 👋",                         text:"Hello! 👋" },
    { type:"text",  label:"Thank you for using our service!",  text:"Thank you for using our service!" },
    { type:"text",  label:"Acknowledgment received ✅",        text:"Acknowledgment received ✅" },
    { type:"text",  label:"Follow-Up: Please share more details.", text:"Follow-Up: Please share more details." },
    { type:"text",  label:"Check-In: How are you doing?",      text:"Check-In: How are you doing?" },
    { type:"text",  label:"Payment Reminder: Your payment is due.", text:"Payment Reminder: Your payment is due." },
  ];

  // ─── State ────────────────────────────────────────────────────────────────
  let knownNumbers = new Set();
  let observer     = null;
  let scanTimer    = null;

  // ══════════════════════════════════════════════════════════════════════════
  // UTILITY FUNCTIONS
  // ══════════════════════════════════════════════════════════════════════════

  function normalizeNumber(raw) {
    let n = raw.replace(/[\s\-().+]/g, "");
    n = n.replace(/\D/g, "").replace(/^0+/, "");
    // Auto-add 91 for 10-digit Indian mobile numbers (starts with 6-9)
    if (n.length === 10 && /^[6-9]/.test(n)) n = "91" + n;
    return n;
  }

  function isPhoneNumber(str) {
    const cleaned = str.replace(/[\s\-().+]/g, "");
    return /^\d{7,15}$/.test(cleaned) && PHONE_REGEX.test(str.trim());
  }

  function isIndianNumber(num) {
    return INDIAN_REGEX.test(normalizeNumber(num));
  }

  function detectCountryCode(num) {
    const n = normalizeNumber(num);
    if (/^(\+91|91)/.test(n) || (n.length === 10 && /^[6-9]/.test(n))) return "IN";
    if (/^(\+1|1)\d{10}$/.test(n))  return "US";
    if (/^(\+44|44)/.test(n))        return "GB";
    if (/^(\+971|971)/.test(n))      return "AE";
    if (/^(\+92|92)/.test(n))        return "PK";
    return "Unknown";
  }

  function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
  }

  function showToast(msg, ms = 2800) {
    let el = document.getElementById("wnum-toast");
    if (!el) {
      el = document.createElement("div");
      el.id = "wnum-toast";
      el.style.cssText = `
        position:fixed;bottom:72px;left:50%;transform:translateX(-50%);
        background:#222e35;color:#fff;padding:10px 20px;border-radius:10px;
        font-size:13px;z-index:99999;pointer-events:none;
        opacity:0;transition:opacity 0.3s;white-space:nowrap;
      `;
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.style.opacity = "1";
    clearTimeout(el._t);
    el._t = setTimeout(() => { el.style.opacity = "0"; }, ms);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SHARED STYLES
  // ══════════════════════════════════════════════════════════════════════════
  function injectStyles() {
    if (document.getElementById("wnum-styles")) return;
    const s = document.createElement("style");
    s.id = "wnum-styles";
    s.textContent = `
      /* Floating badge */
      .wnum-badge {
        position:fixed;bottom:80px;right:20px;
        background:#25d366;color:#fff;padding:10px 16px;
        border-radius:20px;font-size:13px;font-weight:600;
        box-shadow:0 4px 12px rgba(0,0,0,0.25);z-index:99999;
        display:flex;align-items:center;gap:8px;
        transform:translateY(20px);opacity:0;
        transition:all 0.3s ease;pointer-events:none;
      }
      .wnum-badge--show { transform:translateY(0);opacity:1; }

      /* ── Custom Label Bar — fixed at TOP of left WA panel, above header ── */
      #wnum-label-bar {
        display:flex !important;align-items:center;gap:4px;
        padding:4px 8px;
        background:#0a1929;
        border-bottom:2px solid #00a884;
        overflow-x:auto;scrollbar-width:none;flex-shrink:0;
        position:fixed !important;
        top:0 !important;
        left:0 !important;
        width:var(--wnum-bar-width, 460px) !important;
        z-index:99999 !important;
        min-height:36px;
        box-sizing:border-box;
        box-shadow:0 2px 8px rgba(0,0,0,0.4);
      }
      #wnum-label-bar::-webkit-scrollbar{display:none}
      .wnum-chip {
        display:inline-flex;align-items:center;gap:4px;
        padding:3px 9px;border-radius:12px;font-size:12px;
        font-weight:500;cursor:pointer;user-select:none;white-space:nowrap;
        background:rgba(255,255,255,0.08);border:none;color:#aebac1;
        transition:all 0.15s;flex-shrink:0;
      }
      .wnum-chip:hover { background:rgba(255,255,255,0.15); color:#e9edef; }
      .wnum-chip.active {
        background:#00a884;color:#fff;
      }
      .wnum-chip .cnt {
        background:rgba(0,0,0,0.25);border-radius:8px;
        padding:0px 5px;font-size:10px;min-width:14px;text-align:center;
        line-height:1.5;
      }
      #wnum-label-add-btn {
        display:inline-flex;align-items:center;gap:3px;
        padding:3px 9px;border-radius:12px;font-size:12px;
        background:rgba(255,255,255,0.06);border:1px dashed rgba(255,255,255,0.2);
        color:#8696a0;cursor:pointer;white-space:nowrap;flex-shrink:0;
        transition:all 0.15s;
      }
      #wnum-label-add-btn:hover { border-color:#00a884;color:#00a884; }
      #wnum-label-mgr-btn {
        margin-left:auto;flex-shrink:0;
        display:inline-flex;align-items:center;justify-content:center;
        padding:5px;border-radius:8px;width:28px;height:28px;
        background:rgba(255,255,255,0.08);border:none;color:#aebac1;cursor:pointer;
        transition:all 0.2s;white-space:nowrap;
      }
      #wnum-label-mgr-btn:hover { color:#00a884;background:rgba(0,168,132,0.15);transform:rotate(30deg); }

      /* ── Label Manage Modal ── */
      #wnum-lbl-modal {
        display:none;position:fixed;inset:0;
        background:rgba(0,0,0,0.55);z-index:9999999;
        align-items:center;justify-content:center;
      }
      #wnum-lbl-modal.open { display:flex; }
      #wnum-lbl-box {
        background:#1f2c34;border-radius:14px;padding:20px;
        width:400px;max-width:95vw;max-height:82vh;
        overflow-y:auto;box-shadow:0 8px 40px rgba(0,0,0,0.5);
      }
      #wnum-lbl-box h3 { margin:0 0 14px;font-size:15px;color:#e9edef; }
      .lbl-row {
        display:flex;align-items:center;gap:8px;margin-bottom:8px;
      }
      .lbl-row input[type=text] {
        flex:1;padding:7px 10px;border-radius:8px;font-size:13px;
        background:#2a3942;border:1px solid rgba(255,255,255,0.1);color:#e9edef;
        outline:none;
      }
      .lbl-row input[type=text]:focus { border-color:#00a884; }
      .lbl-color-dot {
        width:22px;height:22px;border-radius:50%;cursor:pointer;
        border:2px solid rgba(255,255,255,0.2);flex-shrink:0;
      }
      .lbl-del-btn {
        background:none;border:none;color:#667781;cursor:pointer;
        font-size:16px;padding:2px 6px;border-radius:6px;
        transition:all 0.15s;flex-shrink:0;
      }
      .lbl-del-btn:hover { color:#f15c6d;background:rgba(241,92,109,0.1); }
      .lbl-filter-sel {
        padding:6px 8px;border-radius:8px;font-size:12px;
        background:#2a3942;border:1px solid rgba(255,255,255,0.1);color:#e9edef;
        outline:none;cursor:pointer;
      }
      #wnum-lbl-add-row {
        display:flex;gap:8px;margin-top:12px;
      }
      #wnum-lbl-new-name {
        flex:1;padding:8px 10px;border-radius:8px;font-size:13px;
        background:#2a3942;border:1px solid rgba(255,255,255,0.15);color:#e9edef;
        outline:none;
      }
      #wnum-lbl-new-name:focus { border-color:#00a884; }
      #wnum-lbl-add-ok {
        padding:8px 14px;border-radius:8px;background:#00a884;
        border:none;color:#fff;font-size:13px;font-weight:600;cursor:pointer;
      }
      .lbl-modal-footer {
        display:flex;gap:8px;justify-content:flex-end;margin-top:16px;
      }
      .lbl-modal-footer button {
        padding:8px 18px;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;
      }
      #wnum-lbl-cancel { background:#2a3942;border:none;color:#aebac1; }
      #wnum-lbl-save   { background:#00a884;border:none;color:#fff; }
      .lbl-color-picker {
        display:flex;gap:5px;flex-wrap:wrap;margin-top:4px;
      }
      .lbl-cp-swatch {
        width:18px;height:18px;border-radius:50%;cursor:pointer;
        border:2px solid transparent;transition:border 0.1s;
      }
      .lbl-cp-swatch.chosen { border-color:#fff; }
      .wnum-chip.active .cnt { background:rgba(255,255,255,0.28); }

      /* ── Inline Label Badges on Chat Rows (like second file) ── */
      .wnum-inline-badge-wrap {
        display:flex;gap:3px;overflow:hidden;pointer-events:none;
        align-items:center;margin-left:4px;flex-shrink:0;
      }
      .wnum-inline-lbl {
        font-size:10px;line-height:14px;padding:1px 5px;
        border-radius:3px;white-space:nowrap;overflow:hidden;
        text-overflow:ellipsis;max-width:80px;flex-shrink:0;
      }

      /* ── Download Button ── */
      #wnum-dl-btn {
        display:flex;align-items:center;gap:5px;
        padding:5px 10px;border-radius:6px;
        background:transparent;border:none;
        color:var(--text-secondary,#667781);font-size:12.5px;font-weight:500;
        cursor:pointer;user-select:none;white-space:nowrap;
        transition:all 0.15s;flex-shrink:0;margin-left:auto;
      }
      #wnum-dl-btn:hover { background:var(--hover-background,rgba(0,0,0,0.06)); color:#00a884; }

      /* ── Quick Replies Panel — fixed position above compose box ── */
      #wnum-qr-panel {
        position:fixed;
        left:480px;
        right:0;
        bottom:0;
        display:flex;
        flex-direction:row;
        align-items:center;
        gap:8px;
        padding:5px 12px;
        background:linear-gradient(to right, #f7fdf9, #f0f2f5);
        border-top:2px solid #00a884;
        z-index:9000;
        box-shadow:0 -3px 10px rgba(0,168,132,0.1);
        min-height:40px;
      }
      #wnum-qr-top-row {
        display:flex;align-items:center;gap:10px;flex:1;
      }
      #wnum-qr-panel .qr-title {
        display:none;
      }
      #wnum-qr-panel .qr-title::before {
        content:'⚡';font-size:12px;
      }
      #wnum-qr-scroll {
        display:flex;gap:6px;flex:1;
        flex-wrap:nowrap;
        align-items:center;
        overflow-x:auto;
        overflow-y:hidden;
        scrollbar-width:thin;
        scrollbar-color:#00a88440 transparent;
        padding-bottom:2px;
      }
      #wnum-qr-scroll::-webkit-scrollbar{height:4px;width:4px}
      #wnum-qr-scroll::-webkit-scrollbar-thumb{background:#00a88440;border-radius:4px}
      .wnum-qr-btn {
        display:inline-flex;align-items:center;gap:4px;
        padding:5px 14px;border-radius:20px;
        background:#fff;
        border:1.5px solid #00a884;
        color:#00a884;
        font-size:12.5px;font-weight:600;cursor:pointer;white-space:nowrap;
        flex-shrink:0;transition:all 0.18s;
        max-width:260px;overflow:hidden;text-overflow:ellipsis;
        box-shadow:0 1px 4px rgba(0,168,132,0.15);
        position:relative;
      }
      .wnum-qr-btn::before { content:'⚡'; font-size:10px; opacity:0.7; }
      .wnum-qr-btn:hover {
        background:linear-gradient(135deg,#00a884,#008f72);
        color:#fff;border-color:#00a884;
        transform:translateY(-1px);
        box-shadow:0 4px 12px rgba(0,168,132,0.35);
      }
      .wnum-qr-btn:active { transform:translateY(0); }
      .wnum-qr-edit {
        display:inline-flex;align-items:center;gap:4px;
        padding:4px 10px;border-radius:16px;
        background:transparent;border:1.5px solid #d1d7db;color:#8696a0;
        font-size:11px;font-weight:500;cursor:pointer;white-space:nowrap;flex-shrink:0;
        transition:all 0.18s;
      }
      .wnum-qr-edit:hover {
        border-color:#00a884;color:#00a884;
        background:#e8f5f1;
      }
      .qr-row.photo-row { background:#fff8f0; border-color:#ffd6a5; }
      .qr-row.photo-row:hover { border-color:#f97316; }
      #wnum-qr-add-photo-btn:hover {
        transform:translateY(-1px);
        box-shadow:0 4px 12px rgba(249,115,22,0.4);
      }

      /* ── QR Edit Modal ── */
      #wnum-qr-modal {
        display:none;position:fixed;inset:0;
        background:rgba(0,0,0,0.6);z-index:999999;
        align-items:center;justify-content:center;
        backdrop-filter:blur(4px);
      }
      #wnum-qr-modal.open { display:flex; }
      #wnum-qr-box {
        background:#fff;border-radius:20px;padding:0;
        width:460px;max-width:94vw;max-height:80vh;
        overflow:hidden;
        box-shadow:0 20px 60px rgba(0,0,0,0.3), 0 0 0 1px rgba(0,168,132,0.1);
        display:flex;flex-direction:column;
      }
      #wnum-qr-box-header {
        background:linear-gradient(135deg,#00a884,#008f72);
        padding:16px 20px;
        display:flex;align-items:center;justify-content:space-between;
      }
      #wnum-qr-box-header h3 {
        margin:0;font-size:15px;color:#fff;font-weight:700;
        display:flex;align-items:center;gap:8px;
      }
      #wnum-qr-box-body {
        padding:16px 20px;overflow-y:auto;flex:1;
      }
      .qr-row {
        display:flex;align-items:center;gap:8px;margin-bottom:8px;
        background:#f8fffe;border:1.5px solid #e0f5ef;border-radius:10px;
        padding:6px 8px;transition:border-color 0.15s;
      }
      .qr-row:hover { border-color:#00a884; }
      .qr-row-num {
        font-size:10px;color:#aaa;font-weight:600;width:16px;text-align:center;flex-shrink:0;
      }
      .qr-row input, .qr-row textarea {
        flex:1;padding:6px 10px;border:none;
        border-radius:6px;font-size:13px;outline:none;background:transparent;
        color:#111;resize:none;line-height:1.5;font-family:inherit;
        overflow:hidden;min-height:32px;
      }
      .qr-del {
        background:none;border:none;cursor:pointer;
        color:#ccc;font-size:16px;padding:2px 6px;
        border-radius:6px;line-height:1;transition:all 0.15s;flex-shrink:0;
      }
      .qr-del:hover { color:#ff4545;background:#ffe0e0; }
      #wnum-qr-add {
        display:flex;gap:8px;margin:12px 0 4px;
        background:#f0fdf9;border:1.5px dashed #00a884;
        border-radius:10px;padding:8px;
      }
      #wnum-qr-add input {
        flex:1;padding:7px 10px;border:none;
        border-radius:8px;font-size:13px;outline:none;background:transparent;
        color:#111;
      }
      #wnum-qr-add input::placeholder { color:#aaa; }
      #wnum-qr-add button {
        padding:7px 16px;border-radius:8px;
        background:linear-gradient(135deg,#00a884,#008f72);border:none;
        color:#fff;font-size:13px;font-weight:600;cursor:pointer;
        transition:all 0.15s;white-space:nowrap;
      }
      #wnum-qr-add button:hover { transform:translateY(-1px);box-shadow:0 3px 10px rgba(0,168,132,0.4); }
      #wnum-qr-footer {
        display:flex;gap:10px;justify-content:flex-end;padding:12px 20px;
        border-top:1px solid #f0f0f0;background:#fafafa;border-radius:0 0 20px 20px;
      }
      #wnum-qr-footer button {
        padding:9px 24px;border-radius:12px;
        font-size:13px;cursor:pointer;border:none;font-weight:600;
        transition:all 0.15s;
      }
      #wnum-qr-save   { background:linear-gradient(135deg,#00a884,#008f72);color:#fff;box-shadow:0 3px 10px rgba(0,168,132,0.35); }
      #wnum-qr-save:hover { transform:translateY(-1px);box-shadow:0 5px 15px rgba(0,168,132,0.45); }
      #wnum-qr-cancel { background:#f0f2f5;color:#667781; }
      #wnum-qr-cancel:hover { background:#e0e3e7; }

      /* ── Quick Reply Main Button (panel mein) ── */
      .wnum-qr-main-btn {
        display:inline-flex;align-items:center;justify-content:center;gap:5px;
        padding:6px 16px;border-radius:18px;flex:1;
        background:linear-gradient(135deg,#00a884,#008f72);
        border:none;color:#fff;
        font-size:13px;font-weight:700;cursor:pointer;white-space:nowrap;
        transition:all 0.18s;
        box-shadow:0 2px 6px rgba(0,168,132,0.3);
      }
      .wnum-qr-main-btn:hover {
        transform:translateY(-1px);
        box-shadow:0 3px 10px rgba(0,168,132,0.45);
        background:linear-gradient(135deg,#00c49a,#00a884);
      }
      .wnum-qr-main-btn:active { transform:translateY(0); }

      /* ── DB Search Button (Quick Reply panel mein) ── */
      .wnum-db-search-btn {
        display:inline-flex;align-items:center;justify-content:center;gap:5px;
        padding:6px 16px;border-radius:18px;flex:1;
        background:linear-gradient(135deg,#6366f1,#4f46e5);
        border:none;color:#fff;
        font-size:13px;font-weight:700;cursor:pointer;white-space:nowrap;
        transition:all 0.18s;
        box-shadow:0 2px 6px rgba(99,102,241,0.3);
      }
      .wnum-db-search-btn:hover {
        transform:translateY(-1px);
        box-shadow:0 3px 10px rgba(99,102,241,0.45);
        background:linear-gradient(135deg,#818cf8,#6366f1);
      }
      .wnum-db-search-btn:active { transform:translateY(0); }

      /* ── DB Data Popup ── */
      #wnum-db-popup {
        display:none;position:fixed;
        background:#fff;border-radius:16px;
        padding:0;
        width:340px;max-width:92vw;
        max-height:70vh;overflow:hidden;
        box-shadow:0 8px 32px rgba(0,0,0,0.22), 0 0 0 1px rgba(99,102,241,0.15);
        z-index:999998;
        flex-direction:column;
      }
      #wnum-db-popup.open { display:flex; }
      #wnum-db-popup-header {
        background:linear-gradient(135deg,#6366f1,#4f46e5);
        padding:12px 16px;
        display:flex;align-items:center;justify-content:space-between;
        border-radius:16px 16px 0 0;flex-shrink:0;
      }
      #wnum-db-popup-header h4 {
        margin:0;color:#fff;font-size:13px;font-weight:700;
        display:flex;align-items:center;gap:6px;
      }
      #wnum-db-popup-close {
        background:none;border:none;color:#fff;font-size:18px;
        cursor:pointer;opacity:0.8;transition:opacity 0.15s;line-height:1;
        padding:2px 4px;
      }
      #wnum-db-popup-close:hover { opacity:1; }
      #wnum-db-popup-phone {
        font-size:11px;color:rgba(255,255,255,0.75);
        padding:2px 16px 10px;flex-shrink:0;
        background:linear-gradient(135deg,#6366f1,#4f46e5);
      }
      #wnum-db-popup-body {
        overflow-y:auto;flex:1;padding:10px 12px;
      }
      #wnum-db-popup-body::-webkit-scrollbar{width:4px}
      #wnum-db-popup-body::-webkit-scrollbar-thumb{background:#c7d2fe;border-radius:4px}
      .wnum-db-row {
        display:flex;align-items:center;justify-content:space-between;
        gap:8px;padding:7px 10px;border-radius:10px;
        border:1.5px solid #e0e7ff;margin-bottom:6px;
        background:#f8f9ff;cursor:pointer;transition:all 0.15s;
      }
      .wnum-db-row:hover {
        border-color:#6366f1;background:#eef2ff;
        box-shadow:0 2px 8px rgba(99,102,241,0.15);
        transform:translateX(2px);
      }
      .wnum-db-row-info { flex:1;min-width:0; }
      .wnum-db-row-label {
        font-size:10px;font-weight:700;color:#6366f1;
        text-transform:uppercase;letter-spacing:0.4px;margin-bottom:2px;
      }
      .wnum-db-row-val {
        font-size:12.5px;color:#111;font-weight:500;
        overflow:hidden;text-overflow:ellipsis;white-space:nowrap;
      }
      .wnum-db-row-val.empty { color:#aaa;font-style:italic; }
      .wnum-db-row-copy {
        font-size:10px;color:#6366f1;font-weight:600;
        background:#e0e7ff;border:none;border-radius:6px;
        padding:3px 8px;cursor:pointer;flex-shrink:0;
        transition:all 0.15s;white-space:nowrap;
      }
      .wnum-db-row-copy:hover { background:#6366f1;color:#fff; }
      #wnum-db-loading {
        text-align:center;padding:24px;color:#6366f1;
        font-size:13px;font-weight:600;
      }
      #wnum-db-error {
        text-align:center;padding:16px;color:#ef4444;
        font-size:12px;display:none;
      }
      #wnum-db-notfound {
        text-align:center;padding:20px;color:#aaa;
        font-size:12px;display:none;
      }
      #wnum-db-sheet-selector {
        display: flex;
        gap: 5px;
        padding: 6px 10px;
        background: #f0f4ff;
        border-bottom: 1px solid #e0e7ff;
        flex-wrap: wrap;
        align-items: center;
      }
      .wnum-db-sheet-btn {
        padding: 3px 10px;
        border-radius: 20px;
        border: 1.5px solid #c7d2fe;
        background: #fff;
        color: #4f46e5;
        font-size: 11px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.15s;
        white-space: nowrap;
      }
      .wnum-db-sheet-btn.active {
        background: #4f46e5;
        color: #fff;
        border-color: #4f46e5;
      }
      .wnum-db-sheet-btn:hover:not(.active) {
        background: #e0e7ff;
      }
      #wnum-db-sheet-selector .wnum-db-sheet-label {
        font-size: 10px;
        color: #6b7280;
        margin-right: 2px;
        font-weight: 500;
      }
      #wnum-db-popup-footer {
        padding:8px 12px;border-top:1px solid #f0f0f0;
        font-size:10px;color:#aaa;text-align:center;
        flex-shrink:0;background:#fafafa;border-radius:0 0 16px 16px;
      }
    `;
    document.head.appendChild(s);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // ══════════════════════════════════════════════════════════════════════════
  // FEATURE 1 — CUSTOM LABEL BAR (above WhatsApp header)
  // ══════════════════════════════════════════════════════════════════════════

  const LABEL_STORAGE_KEY = "wnum_custom_labels";
  const CONTACT_LABEL_KEY  = "wnum_contact_labels";   // { phone/name → [labelId, ...] }
  const LABEL_COLORS = ["#00a884","#f15c6d","#f0b429","#3b82f6","#8b5cf6","#ec4899","#10b981","#f97316","#06b6d4","#84cc16"];

  const DEFAULT_LABELS = [
    { id:"all", name:"All", icon:"", color:"#00a884", filter:"all" },
  ];

  // On first load, clean any old stored labels that include unread/business/personal
  (function cleanOldDefaultLabels() {
    try {
      chrome.storage.local.get(LABEL_STORAGE_KEY, res => {
        const stored = res[LABEL_STORAGE_KEY];
        if (!stored) return;
        const cleaned = stored.filter(l => !['unread','business','personal','individual'].includes(l.id));
        // Only update if something was removed
        if (cleaned.length !== stored.length) {
          chrome.storage.local.set({ [LABEL_STORAGE_KEY]: cleaned });
        }
      });
    } catch(e) {}
  })();

  async function getLabels() {
    return new Promise(resolve => {
      try {
        chrome.storage.local.get(LABEL_STORAGE_KEY, res => {
          resolve(res[LABEL_STORAGE_KEY] || DEFAULT_LABELS);
        });
      } catch(e) { resolve(DEFAULT_LABELS); }
    });
  }

  async function saveLabels(list) {
    return new Promise(resolve => {
      chrome.storage.local.set({ [LABEL_STORAGE_KEY]: list }, resolve);
    });
  }

  // Find WhatsApp's native tab buttons (All, Unread)
  function clickWANativeTab(label) {
    const allBtns = Array.from(document.querySelectorAll(
      '#pane-side button, #pane-side [role="button"], #pane-side [role="tab"]'
    ));
    for (const btn of allBtns) {
      const txt = (btn.textContent || btn.innerText || '').trim().toLowerCase();
      if (label === 'All'    && (txt === 'all'    || txt.startsWith('all')))  { btn.click(); return true; }
      if (label === 'Unread' && txt.includes('unread'))                        { btn.click(); return true; }
    }
    return false;
  }

  function getChatRows() {
    const pane = document.querySelector("#pane-side");
    if (!pane) return [];
    return Array.from(pane.querySelectorAll('[data-testid="cell-frame-container"],[role="row"]'));
  }

  function getCountForFilter(filter) {
    const rows = getChatRows();
    if (filter === 'all')        return rows.length;
    if (filter === 'unread')     return rows.filter(r => !!r.querySelector('[data-testid="icon-unread-count"]')).length;
    if (filter === 'business')   return rows.filter(r => isBizRow(r)).length;
    if (filter === 'individual') return rows.filter(r => !isBizRow(r)).length;
    if (filter && filter.startsWith('kw:')) {
      const kw = filter.slice(3).toLowerCase();
      return rows.filter(r => (r.textContent||'').toLowerCase().includes(kw)).length;
    }
    // lbl: filter — count from stored assignments (accurate, not DOM-dependent)
    if (filter && filter.startsWith('lbl:')) {
      const lblId = filter.slice(4);
      return Object.values(_contactLabels).filter(ids => ids.includes(lblId)).length;
    }
    return rows.length;
  }

  function isBizRow(row) {
    return !!row.querySelector('[data-testid="business-chat-indicator"],[data-icon="verified-business"],[data-icon="business-chat"]');
  }

  let activeFilter = 'all';

  function applyLabelFilter(filter) {
    activeFilter = filter;
    const pane = document.querySelector("#pane-side");
    if (!pane) return;

    // Always reset WA to "All" first
    clickWANativeTab('All');

    if (filter === 'all') {
      clearFilterOverlay(pane); return;
    }
    if (filter === 'unread') {
      setTimeout(() => clickWANativeTab('Unread'), 150); return;
    }

    if (filter.startsWith('lbl:')) {
      // For label filters: use a pinned overlay panel instead of CSS hide
      // because virtual scroll makes display:none unreliable
      setTimeout(() => applyLabelOverlay(filter), 300);
      return;
    }

    // Custom CSS overlay for business/individual/keyword
    setTimeout(() => {
      tagAndFilter(pane, filter);
      const scrollEl = pane.querySelector('[data-testid="chat-list"],[role="grid"]') ||
                       pane.querySelector('[style*="overflow"]') || pane;
      scrollEl.scrollTop = 0;
    }, 250);
  }

  // ── Label filter using pinned overlay (beats virtual scroll) ──────────────
  async function applyLabelOverlay(filter) {
    const lblId = filter.slice(4);
    const labels = await getLabels();
    const lbl    = labels.find(l => l.id === lblId);

    const assignedNames = Object.entries(_contactLabels)
      .filter(([, ids]) => ids.includes(lblId))
      .map(([name]) => name);

    // Remove old overlay
    const oldOv = document.getElementById('wnum-lbl-overlay');
    if (oldOv) oldOv.remove();

    // Calculate position: below the label bar, within the left panel
    const bar      = document.getElementById('wnum-label-bar');
    const paneSide = document.querySelector('#pane-side');
    if (!paneSide) return;

    const paneRect = paneSide.getBoundingClientRect();
    const barRect  = bar ? bar.getBoundingClientRect() : null;
    const topOffset = barRect ? barRect.bottom : paneRect.top;

    const overlay = document.createElement('div');
    overlay.id = 'wnum-lbl-overlay';
    overlay.style.cssText = `
      position:fixed;
      left:${paneRect.left}px;
      top:${topOffset}px;
      width:${paneRect.width}px;
      bottom:0;
      background:#111b21;
      z-index:9000;
      overflow-y:auto;
      display:flex;
      flex-direction:column;
      box-shadow:2px 0 8px rgba(0,0,0,0.4);
    `;

    // Header row
    const hdr = document.createElement('div');
    hdr.style.cssText = `padding:10px 14px;font-size:13px;color:#8696a0;
      border-bottom:1px solid #2a373f;display:flex;align-items:center;
      gap:8px;flex-shrink:0;background:#1f2c34;`;
    hdr.innerHTML = `
      <span style="width:10px;height:10px;border-radius:50%;background:${lbl?.color||'#00a884'};display:inline-block;flex-shrink:0"></span>
      <b style="color:#e9edef">${lbl?.icon||'🏷️'} ${lbl?.name||lblId}</b>
      <span style="margin-left:4px">(${assignedNames.length})</span>
      <span id="wnum-lbl-ov-close" style="margin-left:auto;cursor:pointer;
        font-size:20px;color:#8696a0;line-height:1;padding:2px 6px;"
        title="Band karo">✕</span>`;
    overlay.appendChild(hdr);

    if (assignedNames.length === 0) {
      const empty = document.createElement('div');
      empty.style.cssText = 'padding:40px 20px;text-align:center;color:#8696a0;';
      empty.innerHTML = `<div style="font-size:40px">🏷️</div>
        <div style="margin-top:12px;line-height:1.6">Koi contact assign nahi hai<br>
        <small>Chat list mein contact par mouse le jaao → 🏷️ click karo</small></div>`;
      overlay.appendChild(empty);
    } else {
      // Get live rows from pane to clone their appearance
      const allRows = paneSide.querySelectorAll('[data-testid="cell-frame-container"],[role="listitem"],[role="row"]');
      const rowMap  = {};
      allRows.forEach(row => {
        const k = getRowKey(row);
        if (k) rowMap[k] = row;
      });

      assignedNames.forEach(name => {
        const liveRow = rowMap[name];

        const card = document.createElement('div');
        card.style.cssText = `display:flex;align-items:center;padding:10px 14px;
          border-bottom:1px solid #1f2c34;cursor:pointer;gap:12px;
          transition:background 0.1s;`;

        // Try to clone avatar from live row
        let avatarHTML = `<div style="width:48px;height:48px;border-radius:50%;background:#2a373f;
          display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0">👤</div>`;
        if (liveRow) {
          const img = liveRow.querySelector('img');
          if (img && img.src) {
            avatarHTML = `<img src="${img.src}" style="width:48px;height:48px;border-radius:50%;object-fit:cover;flex-shrink:0">`;
          }
        }

        // Last message preview from live row
        let preview = '';
        if (liveRow) {
          const previewEl = liveRow.querySelector('[data-testid="last-msg-status"] ~ span, [data-testid="cell-frame-primary-detail"] span');
          preview = (previewEl?.textContent || '').trim().substring(0, 40);
        }

        card.innerHTML = `
          ${avatarHTML}
          <div style="flex:1;min-width:0">
            <div style="color:#e9edef;font-size:15px;font-weight:500;
              white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${name}</div>
            <div style="color:#8696a0;font-size:12px;margin-top:2px;
              white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
              ${preview || 'Click karein chat kholne ke liye'}</div>
          </div>
          <button class="wnum-lbl-remove-btn" title="Label se remove karo"
            style="flex-shrink:0;background:transparent;border:1px solid #3b4a54;
            color:#ef4444;border-radius:6px;padding:4px 8px;cursor:pointer;
            font-size:16px;line-height:1;margin-left:8px;transition:background 0.15s;"
            data-name="${name.replace(/"/g,'&quot;')}" data-lblid="${lblId}">🗑️</button>
        `;

        card.addEventListener('mouseenter', () => card.style.background = '#2a373f');
        card.addEventListener('mouseleave', () => card.style.background = '');

        // Remove button — stop propagation so card click (open chat) doesn't fire
        card.querySelector('.wnum-lbl-remove-btn').addEventListener('click', async (e) => {
          e.stopPropagation();
          const keyToRemove = e.currentTarget.dataset.name;
          const targetLblId = e.currentTarget.dataset.lblid;

          // Remove this labelId from the contact's label list
          if (_contactLabels[keyToRemove]) {
            _contactLabels[keyToRemove] = _contactLabels[keyToRemove].filter(id => id !== targetLblId);
            if (_contactLabels[keyToRemove].length === 0) {
              delete _contactLabels[keyToRemove];
            }
            await saveContactLabels();
          }

          // Visual feedback: animate card out, then refresh overlay
          card.style.transition = 'opacity 0.25s, transform 0.25s';
          card.style.opacity = '0';
          card.style.transform = 'translateX(30px)';
          setTimeout(() => {
            card.remove();
            // Update header count
            const hdrCount = overlay.querySelector('b + span');
            const remaining = overlay.querySelectorAll('.wnum-lbl-remove-btn').length;
            if (hdrCount) hdrCount.textContent = `(${remaining})`;
            if (remaining === 0) {
              const emptyDiv = document.createElement('div');
              emptyDiv.style.cssText = 'padding:40px 20px;text-align:center;color:#8696a0;';
              emptyDiv.innerHTML = `<div style="font-size:40px">🏷️</div>
                <div style="margin-top:12px;line-height:1.6">Koi contact assign nahi<br>
                <small>Sab contacts label se remove ho gaye</small></div>`;
              overlay.appendChild(emptyDiv);
            }
          }, 250);
          showToast(`✅ "${keyToRemove}" label se remove ho gaya`);
        });
        card.addEventListener('click', () => {
          // Close overlay first
          overlay.remove();
          activeFilter = 'all';

          // Method 1: Click live row directly if visible
          if (liveRow) {
            liveRow.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
            liveRow.dispatchEvent(new MouseEvent('mouseup',   { bubbles: true, cancelable: true }));
            liveRow.dispatchEvent(new MouseEvent('click',     { bubbles: true, cancelable: true }));
            return;
          }

          // Method 2: Use WA search to open chat
          const searchInput = document.querySelector(
            '[data-testid="chat-list-search-input"] input,' +
            'input[aria-label="Search input textbox"],' +
            '#side input[type="text"]'
          );
          if (searchInput) {
            searchInput.focus();
            searchInput.click();
            const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
            setter.call(searchInput, name);
            searchInput.dispatchEvent(new Event('input', { bubbles: true }));
            // After WA shows results, click first result
            setTimeout(() => {
              const firstResult = document.querySelector(
                '[data-testid="cell-frame-container"],[role="listitem"],[role="row"]'
              );
              if (firstResult) {
                firstResult.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
              }
            }, 700);
          }
        });

        overlay.appendChild(card);
      });
    }

    document.body.appendChild(overlay);

    // Close button handler
    overlay.querySelector('#wnum-lbl-ov-close').addEventListener('click', () => {
      overlay.remove();
      activeFilter = 'all';
      document.querySelectorAll('.wnum-chip').forEach(ch => {
        ch.classList.remove('active');
        ch.style.background = '';
      });
      const allChip = document.querySelector('.wnum-chip[data-filter="all"]');
      if (allChip) { allChip.classList.add('active'); allChip.style.background = '#00a884'; }
    });

    // Reposition if window resizes
    const reposition = () => {
      const pr = paneSide.getBoundingClientRect();
      const br = bar ? bar.getBoundingClientRect() : null;
      overlay.style.left  = pr.left + 'px';
      overlay.style.width = pr.width + 'px';
      overlay.style.top   = (br ? br.bottom : pr.top) + 'px';
    };
    window.addEventListener('resize', reposition, { once: true });
  }

  function clearFilterOverlay(pane) {
    pane.removeAttribute('data-wnum-filter');
    const s = document.getElementById('wnum-filter-style');
    if (s) s.textContent = '';
    if (pane._filterObserver) { pane._filterObserver.disconnect(); pane._filterObserver = null; }
    // Also remove label overlay if present
    const ov = document.getElementById('wnum-lbl-overlay');
    if (ov) ov.remove();
  }

  function tagAndFilter(pane, filter) {
    // Tag all currently visible rows
    tagRows(pane, filter);

    pane.setAttribute('data-wnum-filter', filter);

    let styleEl = document.getElementById('wnum-filter-style');
    if (!styleEl) {
      styleEl = document.createElement('style');
      styleEl.id = 'wnum-filter-style';
      document.head.appendChild(styleEl);
    }

    if (filter === 'individual') {
      styleEl.textContent =
        `#pane-side[data-wnum-filter="individual"] [data-wnum-type="business"]
         { display:none !important; }`;
    } else if (filter === 'business') {
      styleEl.textContent =
        `#pane-side[data-wnum-filter="business"] [data-wnum-type="individual"]
         { display:none !important; }`;
    } else if (filter.startsWith('kw:')) {
      styleEl.textContent =
        `#pane-side[data-wnum-filter="${filter}"] [data-wnum-kw="0"]
         { display:none !important; }`;
    } else if (filter.startsWith('lbl:')) {
      styleEl.textContent =
        `#pane-side[data-wnum-filter="${filter}"] [data-wnum-lbl-match="0"]
         { display:none !important; }`;
    }

    // Keep re-tagging as virtual scroll adds new rows
    if (pane._filterObserver) pane._filterObserver.disconnect();
    const listEl = pane.querySelector('[data-testid="chat-list"],[role="grid"]') || pane;
    let retagTimer = null;
    pane._filterObserver = new MutationObserver(() => {
      clearTimeout(retagTimer);
      retagTimer = setTimeout(() => {
        if (activeFilter !== filter) return;
        tagRows(pane, filter);
      }, 100);
    });
    pane._filterObserver.observe(listEl, { childList:true, subtree:true });
  }

  function getRowKey(row) {
    // Try multiple selectors to extract contact name/title
    const selectors = [
      '[data-testid="cell-frame-title"] span',
      '[data-testid="cell-frame-title"]',
      'span[title]',
      '[title]',
    ];
    for (const sel of selectors) {
      const el = row.querySelector(sel);
      if (el) {
        const key = (el.getAttribute('title') || el.textContent || '').trim();
        if (key) return key;
      }
    }
    return '';
  }

  function tagRows(pane, filter) {
    pane.querySelectorAll('[data-testid="cell-frame-container"],[role="row"],[role="listitem"]').forEach(row => {
      const isBiz = isBizRow(row);
      row.setAttribute('data-wnum-type', isBiz ? 'business' : 'individual');
      if (filter.startsWith('kw:')) {
        const kw = filter.slice(3).toLowerCase();
        row.setAttribute('data-wnum-kw', (row.textContent||'').toLowerCase().includes(kw) ? '1' : '0');
      }
      if (filter.startsWith('lbl:')) {
        const lblId = filter.slice(4);
        const key   = getRowKey(row);
        const assigned = (key && _contactLabels[key]) ? _contactLabels[key] : [];
        row.setAttribute('data-wnum-lbl-match', assigned.includes(lblId) ? '1' : '0');
      }
    });
  }

  // ── Label Modal ──────────────────────────────────────────────────────────
  let lblModal = null;
  let _editLabels = [];

  function openLabelModal() {
    if (!lblModal) buildLabelModal();
    getLabels().then(list => {
      _editLabels = JSON.parse(JSON.stringify(list));
      renderLabelList();
      lblModal.classList.add("open");
    });
  }

  function buildLabelModal() {
    lblModal = document.createElement("div");
    lblModal.id = "wnum-lbl-modal";
    lblModal.innerHTML = `
      <div id="wnum-lbl-box">
        <h3>✏️ Apne Labels Manage Karo</h3>
        <div id="wnum-lbl-list"></div>
        <div id="wnum-lbl-add-row">
          <input id="wnum-lbl-new-name" type="text" placeholder="Naya label naam likhein… (jaise: ITR Client, GST, VIP)" />
          <button id="wnum-lbl-add-ok">+ Add</button>
        </div>
        <div style="margin-top:8px;font-size:11px;color:#667781;">
          💡 Tip: Keyword filter set karo — us naam wale contacts filter honge
        </div>
        <div class="lbl-modal-footer">
          <button id="wnum-lbl-cancel">Cancel</button>
          <button id="wnum-lbl-save">✅ Save</button>
        </div>
      </div>`;
    document.body.appendChild(lblModal);

    document.getElementById("wnum-lbl-add-ok").addEventListener("click", () => {
      const inp = document.getElementById("wnum-lbl-new-name");
      const name = inp.value.trim();
      if (!name) return;
      const id = "custom_" + Date.now();
      const color = LABEL_COLORS[_editLabels.length % LABEL_COLORS.length];
      _editLabels.push({ id, name, icon:"🏷️", color, filter:"lbl:" + id });
      inp.value = "";
      renderLabelList();
    });

    document.getElementById("wnum-lbl-cancel").addEventListener("click", () => {
      lblModal.classList.remove("open");
    });

    document.getElementById("wnum-lbl-save").addEventListener("click", async () => {
      await saveLabels(_editLabels);
      lblModal.classList.remove("open");
      // Rebuild bar
      const bar = document.getElementById("wnum-label-bar");
      if (bar) { bar.remove(); window._wnumBarBuilding = false; }
      buildLabelBar();
    });

    lblModal.addEventListener("click", e => {
      if (e.target === lblModal) lblModal.classList.remove("open");
    });
  }

  function renderLabelList() {
    const list = document.getElementById("wnum-lbl-list");
    list.innerHTML = "";
    _editLabels.forEach((lbl, i) => {
      const row = document.createElement("div");
      row.className = "lbl-row";

      // Color dot
      const dot = document.createElement("div");
      dot.className = "lbl-color-dot";
      dot.style.background = lbl.color;
      dot.title = "Color change";
      // Color picker popup
      dot.addEventListener("click", () => {
        // Remove any existing picker
        document.querySelectorAll(".lbl-color-picker").forEach(p => p.remove());
        const picker = document.createElement("div");
        picker.className = "lbl-color-picker";
        picker.style.cssText = "position:absolute;background:#1f2c34;border:1px solid rgba(255,255,255,0.15);border-radius:10px;padding:8px;z-index:9999999;display:flex;gap:5px;flex-wrap:wrap;width:160px;";
        LABEL_COLORS.forEach(c => {
          const sw = document.createElement("div");
          sw.className = "lbl-cp-swatch" + (c === lbl.color ? " chosen" : "");
          sw.style.background = c;
          sw.addEventListener("click", (e) => {
            e.stopPropagation();
            lbl.color = c;
            picker.remove();
            renderLabelList();
          });
          picker.appendChild(sw);
        });
        dot.parentElement.appendChild(picker);
        setTimeout(() => document.addEventListener("click", () => picker.remove(), { once: true }), 50);
      });
      row.appendChild(dot);

      // Name input
      const nameInp = document.createElement("input");
      nameInp.type = "text";
      nameInp.value = lbl.name;
      nameInp.addEventListener("input", () => { lbl.name = nameInp.value; });
      row.appendChild(nameInp);

      // Filter select
      const sel = document.createElement("select");
      sel.className = "lbl-filter-sel";
      sel.title = "Filter type";
      const filterOpts = [
        { v:"all",        t:"All Chats"   },
        { v:"unread",     t:"Unread"      },
        { v:"business",   t:"Business"    },
        { v:"individual", t:"Personal"    },
        { v:"lbl:"+lbl.id, t:"By Label Assignment" },
        { v:"kw:"+lbl.name.toLowerCase(), t:"By Name/Keyword" },
      ];
      // Add current custom filter if different
      if ((lbl.filter.startsWith("kw:") || lbl.filter.startsWith("lbl:")) && !filterOpts.find(o => o.v === lbl.filter)) {
        filterOpts.push({ v:lbl.filter, t:"Custom: " + lbl.filter });
      }
      filterOpts.forEach(opt => {
        const o = document.createElement("option");
        o.value = opt.v; o.textContent = opt.t;
        if (lbl.filter === opt.v) o.selected = true;
        sel.appendChild(o);
      });
      sel.addEventListener("change", () => { lbl.filter = sel.value; });
      row.appendChild(sel);

      // Delete (only for custom labels)
      if (!["all","unread","business","personal"].includes(lbl.id)) {
        const del = document.createElement("button");
        del.className = "lbl-del-btn";
        del.innerHTML = "✕";
        del.title = "Delete";
        del.addEventListener("click", () => {
          _editLabels.splice(i, 1);
          renderLabelList();
        });
        row.appendChild(del);
      }

      list.appendChild(row);
    });
  }

  async function buildLabelBar() {
    if (document.getElementById("wnum-label-bar")) return;
    if (window._wnumBarBuilding) return;
    window._wnumBarBuilding = true;

    const paneSide = document.querySelector('#pane-side');
    if (!paneSide) { window._wnumBarBuilding = false; return; }

    // ── Insert ABOVE everything in pane-side (first child) ──
    const labels = await getLabels();

    const bar = document.createElement("div");
    bar.id = "wnum-label-bar";

    labels.forEach(lbl => {
      const chip = document.createElement("div");
      chip.className = "wnum-chip" + (lbl.filter === "all" ? " active" : "");
      chip.dataset.filter = lbl.filter;
      const cnt = getCountForFilter(lbl.filter);
      chip.style.setProperty("--chip-color", lbl.color);
      chip.innerHTML =
        `<span>${lbl.icon ? lbl.icon + " " : ""}${lbl.name}</span><span class="cnt">${cnt}</span>`;
      chip.addEventListener("click", () => {
        document.querySelectorAll(".wnum-chip").forEach(ch => {
          ch.classList.remove("active");
          ch.style.background = "";
          ch.style.color = "";
        });
        chip.classList.add("active");
        chip.style.background = lbl.color;
        chip.style.color = "#fff";
        applyLabelFilter(lbl.filter);
      });
      bar.appendChild(chip);
    });

    // ── Manage Labels button (Settings Icon) ──
    const mgrBtn = document.createElement("div");
    mgrBtn.id = "wnum-label-mgr-btn";
    mgrBtn.title = "Labels manage karo";
    mgrBtn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="12" cy="12" r="3"/>
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
    </svg>`;
    mgrBtn.addEventListener("click", openLabelModal);
    bar.appendChild(mgrBtn);

    // Bar is position:fixed at top-left — just append to body
    document.body.appendChild(bar);
    window._wnumBarBuilding = false;  // Race-condition guard reset

    // ── Dynamic bar width + paddingTop: match actual #pane-side width ──
    function updateBarPosition() {
      const pane = document.querySelector('#pane-side');
      const side = document.querySelector('#side');
      if (pane) {
        const rect = pane.getBoundingClientRect();
        document.documentElement.style.setProperty('--wnum-bar-width', rect.width + 'px');
        bar.style.left  = rect.left + 'px';
        bar.style.width = rect.width + 'px';
      }
      // Push #side down so bar doesn't cover WA header
      const appRoot = side || document.querySelector('#app');
      if (appRoot) {
        appRoot.style.paddingTop = '36px';
      }
    }
    updateBarPosition();

    // Re-run on resize so bar tracks panel width
    if (!window._wnumResizeAttached) {
      window._wnumResizeAttached = true;
      window.addEventListener('resize', () => {
        const b = document.getElementById('wnum-label-bar');
        if (b) updateBarPosition();
      });
    }

    // Refresh counts + bar position every 5 sec
    setInterval(() => {
      // Re-sync bar width with actual pane-side size (handles WA resize/split)
      const barEl = document.getElementById('wnum-label-bar');
      if (barEl) {
        const pane = document.querySelector('#pane-side');
        if (pane) {
          const rect = pane.getBoundingClientRect();
          barEl.style.left  = rect.left + 'px';
          barEl.style.width = rect.width + 'px';
        }
      }
      getLabels().then(lbls => {
        document.querySelectorAll(".wnum-chip").forEach(chip => {
          const f = chip.dataset.filter;
          const lbl = lbls.find(l => l.filter === f);
          const el = chip.querySelector(".cnt");
          if (el) el.textContent = getCountForFilter(f);
          if (chip.classList.contains("active") && lbl) {
            chip.style.background = lbl.color;
            chip.style.color = "#fff";
          } else {
            chip.style.background = "";
            chip.style.color = "";
          }
        });
      });
    }, 5000);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // FEATURE 1b — CONTACT ↔ LABEL ASSIGNMENT (right-click on chat row)
  // ══════════════════════════════════════════════════════════════════════════

  let _contactLabels = {};   // { contactKey → [labelId, ...] }

  async function loadContactLabels() {
    return new Promise(resolve => {
      try {
        chrome.storage.local.get(CONTACT_LABEL_KEY, res => {
          _contactLabels = res[CONTACT_LABEL_KEY] || {};
          resolve();
        });
      } catch(e) { resolve(); }
    });
  }

  /** Render inline label badges on chat row — next to contact name, before time (like SheetWA v6) */
  function renderInlineLabelBadges(row, labels, labelIds) {
    const existing = row.querySelector('.wnum-inline-badge-wrap');
    if (existing) existing.remove();
    if (!labelIds || !labelIds.length) return;
    const nameEl =
      row.querySelector('[data-testid="cell-frame-title"] span') ||
      row.querySelector('[data-testid="cell-frame-title"]');
    if (!nameEl) return;
    const nameParent = nameEl.parentElement;
    if (!nameParent) return;
    const isDark = document.body.classList.contains('dark');
    const colors = isDark
      ? { bg:'#ffffff14', text:'#ffffffaa', border:'#ffffff1a' }
      : { bg:'#f0f0f0',   text:'#333333',   border:'#d0d0d0'   };
    const wrap = document.createElement('div');
    wrap.className = 'wnum-inline-badge-wrap';
    const shown = labelIds.slice(0, 2);
    const extra = labelIds.length - shown.length;
    shown.forEach(id => {
      const lbl = labels.find(l => l.id === id);
      if (!lbl) return;
      const span = document.createElement('span');
      span.className = 'wnum-inline-lbl';
      span.style.cssText = 'background:' + colors.bg + ';color:' + colors.text + ';border:1px solid ' + colors.border;
      span.textContent = (lbl.icon ? lbl.icon + ' ' : '') + lbl.name;
      wrap.appendChild(span);
    });
    if (extra > 0) {
      const plus = document.createElement('span');
      plus.className = 'wnum-inline-lbl';
      plus.style.cssText = 'background:' + colors.bg + ';color:' + colors.text + ';border:1px solid ' + colors.border;
      plus.textContent = '+' + extra;
      wrap.appendChild(plus);
    }
    const timeEl = nameParent.querySelector('span[dir], [data-testid*="time"]');
    if (timeEl && !nameEl.contains(timeEl)) {
      nameParent.insertBefore(wrap, timeEl);
    } else {
      nameParent.appendChild(wrap);
    }
  }

  async function saveContactLabels() {
    return new Promise(resolve => {
      try {
        chrome.storage.local.set({ [CONTACT_LABEL_KEY]: _contactLabels }, resolve);
      } catch(e) { resolve(); }
    });
  }

  // Build the right-click context menu for label assignment
  function buildContactLabelMenu() {
    // Remove old if exists
    const old = document.getElementById('wnum-ctx-menu');
    if (old) old.remove();

    const menu = document.createElement('div');
    menu.id = 'wnum-ctx-menu';
    Object.assign(menu.style, {
      position:'fixed', zIndex:'99999', background:'#202c33', border:'1px solid #3b4a54',
      borderRadius:'8px', padding:'6px 0', minWidth:'200px', boxShadow:'0 4px 20px rgba(0,0,0,0.5)',
      fontFamily:'inherit', fontSize:'14px', color:'#e9edef', display:'none'
    });
    document.body.appendChild(menu);

    // Close on outside click
    document.addEventListener('click', () => { menu.style.display = 'none'; }, true);
    return menu;
  }

  async function showLabelAssignMenu(e, contactKey) {
    e.preventDefault();
    e.stopPropagation();

    const labels = await getLabels();
    const customLabels = labels.filter(l => !['all','unread','business','personal'].includes(l.id));

    let menu = document.getElementById('wnum-ctx-menu');
    if (!menu) menu = buildContactLabelMenu();

    const assigned = _contactLabels[contactKey] || [];

    menu.innerHTML = `
      <div style="padding:6px 14px 4px;font-size:11px;color:#8696a0;border-bottom:1px solid #3b4a54;margin-bottom:4px;">
        🏷️ Label assign karo: <b style="color:#e9edef">${contactKey.substring(0,25)}</b>
      </div>
      ${customLabels.length === 0
        ? `<div style="padding:8px 14px;color:#8696a0">Pehle koi label banao ⚙️ Labels se</div>`
        : customLabels.map(lbl => {
            const isOn = assigned.includes(lbl.id);
            return `<div data-lbl-id="${lbl.id}" style="padding:8px 14px;cursor:pointer;display:flex;align-items:center;gap:8px;border-radius:4px;margin:0 4px;">
              <span style="width:10px;height:10px;border-radius:50%;background:${lbl.color};display:inline-block;flex-shrink:0"></span>
              <span>${lbl.icon || '🏷️'} ${lbl.name}</span>
              <span style="margin-left:auto;color:${isOn ? '#00a884' : '#3b4a54'}">${isOn ? '✅' : '⬜'}</span>
            </div>`;
          }).join('')
      }
      <div id="wnum-ctx-save" style="padding:8px 14px;cursor:pointer;color:#00a884;border-top:1px solid #3b4a54;margin-top:4px;font-weight:600">💾 Save</div>
    `;

    // Hover effect
    menu.querySelectorAll('[data-lbl-id]').forEach(item => {
      item.addEventListener('mouseenter', () => item.style.background = '#2a373f');
      item.addEventListener('mouseleave', () => item.style.background = '');
      item.addEventListener('click', (ev) => {
        ev.stopPropagation();
        const id = item.getAttribute('data-lbl-id');
        let cur = _contactLabels[contactKey] || [];
        if (cur.includes(id)) {
          cur = cur.filter(x => x !== id);
        } else {
          cur = [...cur, id];
        }
        _contactLabels[contactKey] = cur;
        // Re-render menu in place
        showLabelAssignMenu({ clientX: e.clientX, clientY: e.clientY, preventDefault:()=>{}, stopPropagation:()=>{} }, contactKey);
      });
    });

    const saveBtn = menu.querySelector('#wnum-ctx-save');
    if (saveBtn) {
      saveBtn.addEventListener('mouseenter', () => saveBtn.style.background = '#2a373f');
      saveBtn.addEventListener('mouseleave', () => saveBtn.style.background = '');
      saveBtn.addEventListener('click', async (ev) => {
        ev.stopPropagation();
        await saveContactLabels();
        menu.style.display = 'none';
        refreshAllRowDots();
        // Inline badges cleaned up — updateRowLabelDots handles all badge rendering
        // Retag if currently filtering by label
        if (activeFilter.startsWith('lbl:')) {
          const pane = document.querySelector('#pane-side');
          if (pane) tagRows(pane, activeFilter);
        }
      });
    }

    // Position menu
    const vw = window.innerWidth, vh = window.innerHeight;
    let x = e.clientX, y = e.clientY;
    menu.style.display = 'block';
    const mw = menu.offsetWidth, mh = menu.offsetHeight;
    if (x + mw > vw) x = vw - mw - 8;
    if (y + mh > vh) y = vh - mh - 8;
    menu.style.left = x + 'px';
    menu.style.top  = y + 'px';
  }

  function attachContactLabelContextMenu() {
    const pane = document.querySelector('#pane-side');
    if (!pane || pane._wnumCtxAttached) return;
    pane._wnumCtxAttached = true;

    // On mouseenter of each chat row → show 🏷️ button
    pane.addEventListener('mouseover', (e) => {
      const row = e.target.closest('[data-testid="cell-frame-container"],[role="listitem"]');
      if (!row || row._wnumBtnAttached) return;
      row._wnumBtnAttached = true;

      const key = getRowKey(row);
      if (!key) return;

      // Check assigned labels
      const assigned = _contactLabels[key] || [];

      const btn = document.createElement('div');
      btn.className = 'wnum-lbl-btn';
      btn.title = 'Label assign karo';
      btn.innerHTML = assigned.length > 0 ? '🏷️' : '🏷️';
      btn.style.cssText = `
        position:absolute;right:40px;top:50%;transform:translateY(-50%);
        z-index:9999;cursor:pointer;font-size:16px;
        background:rgba(32,44,51,0.92);border-radius:50%;
        width:28px;height:28px;display:flex;align-items:center;
        justify-content:center;opacity:0;transition:opacity 0.15s;
        border:1px solid rgba(255,255,255,0.15);
      `;

      // Make row relative if not already
      const rPos = getComputedStyle(row).position;
      if (rPos === 'static') row.style.position = 'relative';

      row.appendChild(btn);

      row.addEventListener('mouseenter', () => { btn.style.opacity = '1'; });
      row.addEventListener('mouseleave', () => { btn.style.opacity = '0'; });

      btn.addEventListener('click', (ev) => {
        ev.stopPropagation();
        ev.preventDefault();
        showLabelAssignMenu(ev, key);
      });

      // Show assigned label dots next to the button
      updateRowLabelDots(row, key);
    });
  }

  function updateRowLabelDots(row, key) {
    // Remove old label badges (both systems)
    row.querySelectorAll('.wnum-lbl-dot').forEach(d => d.remove());
    row.querySelectorAll('.wnum-inline-badge-wrap').forEach(d => d.remove());
    const assigned = _contactLabels[key] || [];
    if (assigned.length === 0) return;

    getLabels().then(labels => {
      // Find the metadata area (timestamp + last message row) to inject pills there
      // Try multiple WA DOM selectors for robustness
      const metaArea =
        row.querySelector('[data-testid="cell-frame-secondary-detail"]') ||
        row.querySelector('[data-testid="cell-frame-primary-detail"]') ||
        row.querySelector('div[class*="last-msg"]') ||
        row.querySelector('div[class*="message-"]') ||
        null;

      const wrap = document.createElement('div');
      wrap.className = 'wnum-lbl-dot';
      wrap.style.cssText = `
        display:inline-flex;flex-wrap:wrap;gap:3px;
        align-items:center;margin-top:2px;
        pointer-events:none;
      `;

      assigned.forEach(id => {
        const lbl = labels.find(l => l.id === id);
        if (!lbl) return;
        const pill = document.createElement('span');
        pill.title = lbl.name;
        pill.style.cssText = `
          display:inline-flex;align-items:center;gap:2px;
          background:${lbl.color}22;
          border:1px solid ${lbl.color}99;
          color:${lbl.color};
          border-radius:10px;
          padding:1px 6px;
          font-size:10px;
          font-weight:600;
          line-height:14px;
          max-width:80px;
          overflow:hidden;
          text-overflow:ellipsis;
          white-space:nowrap;
        `;
        pill.innerHTML = `<span style="width:6px;height:6px;border-radius:50%;background:${lbl.color};display:inline-block;flex-shrink:0"></span>${lbl.icon ? lbl.icon + ' ' : ''}${lbl.name}`;
        wrap.appendChild(pill);
      });

      if (!wrap.children.length) return;

      if (metaArea) {
        // Insert pills inside the secondary/detail area
        metaArea.appendChild(wrap);
      } else {
        // Fallback: absolute position at bottom-left of row
        wrap.style.cssText += `position:absolute;left:72px;bottom:4px;z-index:997;`;
        const rPos = getComputedStyle(row).position;
        if (rPos === 'static') row.style.position = 'relative';
        row.appendChild(wrap);
      }
    });
  }

  // Call after save to refresh all visible dots
  let _rowDotsTimer = null;
  function refreshAllRowDots() {
    clearTimeout(_rowDotsTimer);
    _rowDotsTimer = setTimeout(() => {
      const pane = document.querySelector('#pane-side');
      if (!pane) return;
      // Use all possible WA row selectors (handles different WA versions)
      const rows = pane.querySelectorAll(
        '[data-testid="cell-frame-container"],' +
        '[role="listitem"],' +
        '[role="row"],' +
        '[data-id]'
      );
      rows.forEach(row => {
        const key = getRowKey(row);
        if (key) updateRowLabelDots(row, key);
      });
    }, 300);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // FEATURE 2 — QUICK REPLIES PANEL
  // ══════════════════════════════════════════════════════════════════════════

  async function getQR() {
    return new Promise(resolve => {
      try {
        chrome.storage.local.get(QR_STORAGE_KEY, res => {
          const raw = res[QR_STORAGE_KEY] || DEFAULT_QR;
          resolve(normalizeQR(raw));
        });
      } catch (e) { resolve(DEFAULT_QR); }
    });
  }

  async function saveQR(list) {
    return new Promise(resolve => {
      try {
        chrome.storage.local.set({ [QR_STORAGE_KEY]: list }, resolve);
      } catch (e) { resolve(); }
    });
  }

  function insertInCompose(text) {
    const box = getComposeBox();
    if (!box) return;
    box.focus();
    const dt = new DataTransfer();
    dt.setData("text/plain", text);
    box.dispatchEvent(
      new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true })
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  // PHOTO QUICK REPLY — WPP.chat.sendFileMessage (MAIN world via background)
  // ════════════════════════════════════════════════════════════════════════

  // base64 dataURL → { base64: string (no header), mime, filename }
  function parseBase64DataUrl(dataUrl, index) {
    const match = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
    if (!match) return null;
    const mime = match[1];
    const b64  = match[2];
    const ext  = mime.split("/")[1] || "jpg";
    return { base64: b64, mime, filename: "photo_" + (index+1) + "." + ext };
  }

  // WPP.chat.sendFileMessage se current chat mein photos bhejo
  async function insertPhotos(base64List, caption) {
    if (!base64List || base64List.length === 0) return;

    // Current chat ka phone number lo
    const phone = await getCurrentChatPhone();
    if (!phone) {
      showToast("⚠️ Current chat ka number detect nahi hua", 3000);
      return;
    }

    showToast("📤 Photos bhej rahe hain...", 1500);

    let sentCount = 0;
    for (let i = 0; i < base64List.length; i++) {
      const parsed = parseBase64DataUrl(base64List[i], i);
      if (!parsed) continue;

      try {
        const result = await new Promise(resolve => {
          chrome.runtime.sendMessage({
            type:       "WPP_SEND_FILE",
            number:     phone,
            fileBase64: parsed.base64,
            fileMime:   parsed.mime,
            filename:   parsed.filename,
            fileType:   "image",
            caption:    (i === 0 && caption) ? caption : "",  // pehli image ke saath caption
          }, res => resolve(res || { success: false }));
        });

        if (result.success) {
          sentCount++;
        } else {
          console.warn("[QR Photo] WPP_SEND_FILE failed:", result.reason);
        }

        // Har photo ke beech thoda gap
        if (i < base64List.length - 1) await new Promise(r => setTimeout(r, 400));

      } catch(e) {
        console.warn("[QR Photo] message send error:", e);
      }
    }

    if (sentCount === base64List.length) {
      showToast("✅ " + sentCount + " photo(s) bhej di!", 2000);
    } else if (sentCount > 0) {
      showToast("⚠️ " + sentCount + "/" + base64List.length + " photos bheji", 2500);
    } else {
      showToast("❌ Photos nahi bheji ja ski — WPP ready nahi hai?", 3000);
    }
  }

  // ── Quick Reply item click handler ───────────────────────────────────────
  async function fireQRItem(item) {
    if (item.type === "photo") {
      // Photos WPP se bhejo — caption pehli image ke saath
      const caption = (item.text || "").trim();
      if (item.images && item.images.length) {
        await insertPhotos(item.images, caption);
      } else if (caption) {
        // Sirf caption hai, image nahi — text box mein daalo
        insertInCompose(caption);
      }
    } else {
      insertInCompose(item.text || item.label || "");
    }
  }

  let qrPanelEl = null;
  let qrBuilding = false;

  function getComposeBoxRect() {
    // Get the bounding rect of the compose area to position QR panel above it
    const box =
      document.querySelector('[data-testid="conversation-compose-box-input"]') ||
      document.querySelector('div[contenteditable="true"][data-tab="10"]')     ||
      document.querySelector('div[contenteditable="true"][role="textbox"]');
    if (!box) return null;
    // Walk up to find the full-width compose row (has emoji + attach buttons)
    let el = box;
    for (let i = 0; i < 8 && el; i++) {
      const r = el.getBoundingClientRect();
      if (r.width > 300 && r.height > 30) return r;
      el = el.parentElement;
    }
    return box.getBoundingClientRect();
  }

  function positionQRPanel() {
    const panel = document.getElementById("wnum-qr-panel");
    if (!panel) return;
    const rect = getComposeBoxRect();
    if (!rect) return;
    // Position panel so its bottom aligns just above the compose box top
    panel.style.bottom = (window.innerHeight - rect.top) + "px";
  }

  async function buildQRPanel() {
    // ── Strict single-instance guard ──────────────────────────────────────
    document.querySelectorAll("#wnum-qr-panel").forEach(el => el.remove());
    if (qrBuilding) return;
    qrPanelEl = null;
    qrBuilding = true;

    // Need compose box to exist before building
    const box =
      document.querySelector('[data-testid="conversation-compose-box-input"]') ||
      document.querySelector('div[contenteditable="true"][data-tab="10"]');
    if (!box) { qrBuilding = false; return; }

    const panel = document.createElement("div");
    panel.id = "wnum-qr-panel";

    // Top row: only 2 big buttons
    const topRow = document.createElement("div");
    topRow.id = "wnum-qr-top-row";

    // Button 1: DB Search
    const dbBtn = document.createElement("button");
    dbBtn.className = "wnum-db-search-btn";
    dbBtn.innerHTML = "\u{1F5C4}\uFE0F DB Search";
    dbBtn.title = "Is number ka data Google Sheet se fetch karo";
    dbBtn.style.cssText = "";
    dbBtn.addEventListener("click", () => openDBPopup());
    topRow.appendChild(dbBtn);

    // Button 2: Quick Reply
    const qrBtn = document.createElement("button");
    qrBtn.className = "wnum-qr-main-btn";
    qrBtn.innerHTML = "\u26A1 Quick Reply";
    qrBtn.title = "Quick Replies list kholo";
    qrBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      openQRListPopup(qrBtn);
    });
    topRow.appendChild(qrBtn);

    panel.appendChild(topRow);
    document.body.appendChild(panel);
    qrPanelEl = panel;
    qrBuilding = false;

    positionQRPanel();
    window.addEventListener("resize", positionQRPanel);
  }

  // ── Quick Reply List Popup (opens above the QR button) ────────────────
  let qrListPopupEl = null;

  async function openQRListPopup(anchorBtn) {
    // Toggle: if already open, close it
    if (qrListPopupEl) {
      qrListPopupEl.remove();
      qrListPopupEl = null;
      return;
    }

    const replies = await getQR();
    const popup = document.createElement("div");
    popup.id = "wnum-qr-list-popup";
    popup.style.cssText = [
      "position:fixed",
      "background:#fff",
      "border-radius:16px",
      "padding:0",
      "width:340px",
      "max-width:92vw",
      "max-height:60vh",
      "overflow:hidden",
      "box-shadow:0 8px 32px rgba(0,0,0,0.22), 0 0 0 1px rgba(0,168,132,0.18)",
      "z-index:999997",
      "display:flex",
      "flex-direction:column"
    ].join(";");

    // Header
    const hdr = document.createElement("div");
    hdr.style.cssText = "background:linear-gradient(135deg,#00a884,#008f72);padding:12px 16px;display:flex;align-items:center;justify-content:space-between;border-radius:16px 16px 0 0;";
    const hdrTitle = document.createElement("span");
    hdrTitle.style.cssText = "color:#fff;font-size:14px;font-weight:700;display:flex;align-items:center;gap:6px;";
    hdrTitle.textContent = "\u26A1 Quick Replies";
    hdr.appendChild(hdrTitle);

    const hdrRight = document.createElement("div");
    hdrRight.style.cssText = "display:flex;align-items:center;gap:8px;";

    const editHdrBtn = document.createElement("button");
    editHdrBtn.textContent = "\u270F\uFE0F Edit";
    editHdrBtn.style.cssText = "background:rgba(255,255,255,0.2);border:none;color:#fff;font-size:12px;font-weight:600;padding:4px 10px;border-radius:10px;cursor:pointer;";
    editHdrBtn.addEventListener("click", () => {
      popup.remove(); qrListPopupEl = null;
      openQRModal();
    });

    const closeHdrBtn = document.createElement("button");
    closeHdrBtn.textContent = "\u2715";
    closeHdrBtn.style.cssText = "background:rgba(255,255,255,0.2);border:none;color:#fff;font-size:14px;font-weight:700;padding:4px 9px;border-radius:10px;cursor:pointer;line-height:1;";
    closeHdrBtn.addEventListener("click", () => { popup.remove(); qrListPopupEl = null; });

    hdrRight.appendChild(editHdrBtn);
    hdrRight.appendChild(closeHdrBtn);
    hdr.appendChild(hdrRight);
    popup.appendChild(hdr);

    // Reply list
    const list = document.createElement("div");
    list.style.cssText = "overflow-y:auto;flex:1;padding:8px;display:flex;flex-direction:column;gap:6px;";

    if (replies.length === 0) {
      const empty = document.createElement("div");
      empty.style.cssText = "text-align:center;color:#aaa;padding:20px;font-size:13px;";
      empty.textContent = "Koi quick reply nahi hai. Edit karke add karo!";
      list.appendChild(empty);
    } else {
      replies.forEach((item) => {
        const isPhoto = item.type === "photo";
        const row = document.createElement("button");
        row.style.cssText = [
          "display:flex",
          "align-items:center",
          "gap:8px",
          isPhoto ? "background:#fff8f0" : "background:#f0fdf9",
          isPhoto ? "border:1.5px solid #ffd6a5" : "border:1.5px solid #d1f5e8",
          "border-radius:10px",
          "padding:9px 12px",
          "cursor:pointer",
          "text-align:left",
          "font-size:13px",
          "color:#111",
          "font-weight:500",
          "width:100%",
          "transition:all 0.15s"
        ].join(";");

        const icon = document.createElement("span");
        icon.style.cssText = "font-size:14px;flex-shrink:0;";
        icon.textContent = isPhoto ? "📷" : "⚡";

        const mid = document.createElement("div");
        mid.style.cssText = "flex:1;min-width:0;";

        const labelEl = document.createElement("span");
        labelEl.style.cssText = "display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:left;font-weight:600;";
        labelEl.textContent = item.label || item.text || "(no label)";

        mid.appendChild(labelEl);

        if (isPhoto && item.images && item.images.length) {
          const thumbRow = document.createElement("div");
          thumbRow.style.cssText = "display:flex;gap:4px;margin-top:5px;flex-wrap:wrap;";
          item.images.slice(0,4).forEach(src => {
            const img = document.createElement("img");
            img.src = src;
            img.style.cssText = "width:36px;height:36px;object-fit:cover;border-radius:5px;border:1.5px solid #ffd6a5;flex-shrink:0;";
            thumbRow.appendChild(img);
          });
          if (item.images.length > 4) {
            const more = document.createElement("span");
            more.style.cssText = "width:36px;height:36px;background:#fff0e0;border-radius:5px;display:flex;align-items:center;justify-content:center;font-size:10px;color:#f97316;font-weight:700;border:1.5px solid #ffd6a5;";
            more.textContent = "+" + (item.images.length - 4);
            thumbRow.appendChild(more);
          }
          mid.appendChild(thumbRow);
        }

        row.title = item.label || item.text || "";
        row.appendChild(icon);
        row.appendChild(mid);

        const hoverBg    = isPhoto ? "#fff0dc" : "#e0f9f0";
        const hoverBdr   = isPhoto ? "#f97316" : "#00a884";
        const normalBg   = isPhoto ? "#fff8f0" : "#f0fdf9";
        const normalBdr  = isPhoto ? "#ffd6a5" : "#d1f5e8";

        row.addEventListener("mouseenter", () => { row.style.background=hoverBg; row.style.borderColor=hoverBdr; });
        row.addEventListener("mouseleave", () => { row.style.background=normalBg; row.style.borderColor=normalBdr; });
        row.addEventListener("click", async (e) => {
          e.stopPropagation();
          popup.remove(); qrListPopupEl = null;
          await fireQRItem(item);
        });
        list.appendChild(row);
      });
    }

    popup.appendChild(list);
    document.body.appendChild(popup);
    qrListPopupEl = popup;

    // Position: above the anchor button
    const rect = anchorBtn.getBoundingClientRect();
    const popH = Math.min(replies.length * 52 + 80, window.innerHeight * 0.6);
    const topPos = Math.max(10, rect.top - popH - 8);
    popup.style.left = Math.max(8, rect.left) + "px";
    popup.style.top = topPos + "px";

    // Close on outside click
    setTimeout(() => {
      document.addEventListener("click", function outsideClose(ev) {
        if (!popup.contains(ev.target) && ev.target !== anchorBtn) {
          popup.remove(); qrListPopupEl = null;
          document.removeEventListener("click", outsideClose);
        }
      });
    }, 100);
  }

  async function refreshQRPanel() {
    // Remove ALL panels (prevents leftover duplicates)
    document.querySelectorAll("#wnum-qr-panel").forEach(el => el.remove());
    qrPanelEl = null;
    qrBuilding = false;
    await buildQRPanel();
    setTimeout(positionQRPanel, 100);
  }

  // ── QR Edit Modal ──────────────────────────────────────────
  let qrModal = null;
  let _editReplies = [];

  function openQRModal() {
    if (!qrModal) buildQRModal();
    getQR().then(list => {
      // Deep clone to avoid mutating stored objects
      _editReplies = list.map(item => ({
        ...item,
        images: item.images ? [...item.images] : undefined
      }));
      renderQRList();
      qrModal.classList.add("open");
    });
  }

  function renderQRList() {
    const container = document.getElementById("wnum-qr-list");
    container.innerHTML = "";
    _editReplies.forEach((item, i) => {
      const isPhoto = item.type === "photo";
      const row = document.createElement("div");
      row.className = "qr-row";
      row.style.cssText += ";align-items:flex-start;flex-direction:column;padding:10px 12px;gap:8px;";
      if (isPhoto) row.style.background = "#fff8f0";

      // ── Top: num + type badge + label + del ──
      const topLine = document.createElement("div");
      topLine.style.cssText = "display:flex;align-items:center;gap:8px;width:100%;";

      const num = document.createElement("span");
      num.className = "qr-row-num";
      num.textContent = i+1;

      const typeBadge = document.createElement("span");
      typeBadge.style.cssText = `font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;flex-shrink:0;${isPhoto ? "background:#fff0dc;color:#f97316;border:1px solid #ffd6a5;" : "background:#e0f9f0;color:#00a884;border:1px solid #b8f0df;"}`;
      typeBadge.textContent = isPhoto ? "📷 PHOTO" : "⚡ TEXT";

      const labelInp = document.createElement("input");
      labelInp.type = "text";
      labelInp.value = item.label || "";
      labelInp.placeholder = "Button ka naam (label)…";
      labelInp.style.cssText = "flex:1;padding:4px 8px;border:none;border-radius:6px;font-size:12px;outline:none;background:transparent;color:#111;font-weight:600;font-family:inherit;";
      labelInp.addEventListener("input", () => { _editReplies[i].label = labelInp.value; });

      const del = document.createElement("button");
      del.className = "qr-del"; del.innerHTML = "✕"; del.title = "Delete";
      del.addEventListener("click", () => { _editReplies.splice(i, 1); renderQRList(); });

      topLine.appendChild(num); topLine.appendChild(typeBadge); topLine.appendChild(labelInp); topLine.appendChild(del);
      row.appendChild(topLine);

      if (isPhoto) {
        // ── Photo section: thumbnails + add more ──
        const photoSection = document.createElement("div");
        photoSection.style.cssText = "width:100%;";

        // Optional caption text — multiline textarea
        const captionInp = document.createElement("textarea");
        captionInp.value = item.text || "";
        captionInp.placeholder = "📝 Caption likho…\n(Enter = naya line, jaise text reply)";
        captionInp.rows = 3;
        captionInp.style.cssText = "width:100%;box-sizing:border-box;padding:6px 10px;border:1.5px solid #ffd6a5;border-radius:7px;font-size:13px;color:#111;background:#fff;margin-bottom:8px;font-family:inherit;resize:none;overflow:hidden;line-height:1.6;outline:none;";
        const _autoResize = () => {
          captionInp.style.height = "auto";
          captionInp.style.height = Math.min(captionInp.scrollHeight, 160) + "px";
        };
        captionInp.addEventListener("input", () => {
          _editReplies[i].text = captionInp.value;
          _autoResize();
        });
        setTimeout(_autoResize, 0);
        photoSection.appendChild(captionInp);

        // Thumbnail grid
        const thumbGrid = document.createElement("div");
        thumbGrid.style.cssText = "display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px;";
        (item.images||[]).forEach((src, pi) => {
          const wrap = document.createElement("div");
          wrap.style.cssText = "position:relative;";
          const img = document.createElement("img");
          img.src = src;
          img.style.cssText = "width:52px;height:52px;object-fit:cover;border-radius:8px;border:2px solid #ffd6a5;display:block;";
          const rmBtn = document.createElement("button");
          rmBtn.innerHTML = "✕";
          rmBtn.style.cssText = "position:absolute;top:-5px;right:-5px;width:16px;height:16px;background:#ff4444;color:#fff;border:none;border-radius:50%;font-size:9px;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0;line-height:1;";
          rmBtn.title = "Remove photo";
          rmBtn.addEventListener("click", () => {
            _editReplies[i].images.splice(pi, 1);
            renderQRList();
          });
          wrap.appendChild(img); wrap.appendChild(rmBtn);
          thumbGrid.appendChild(wrap);
        });

        // Add photos button
        const addPhotoBtn = document.createElement("label");
        addPhotoBtn.style.cssText = "display:inline-flex;align-items:center;gap:4px;padding:5px 12px;background:#fff;border:1.5px dashed #f97316;border-radius:8px;font-size:12px;color:#f97316;font-weight:600;cursor:pointer;";
        addPhotoBtn.textContent = "📷 Photo Add Karo";
        const fileInp = document.createElement("input");
        fileInp.type = "file"; fileInp.accept = "image/*"; fileInp.multiple = true;
        fileInp.style.display = "none";
        fileInp.addEventListener("change", async () => {
          for (const file of fileInp.files) {
            const b64 = await _fileToBase64(file);
            if (!_editReplies[i].images) _editReplies[i].images = [];
            _editReplies[i].images.push(b64);
          }
          renderQRList();
        });
        addPhotoBtn.appendChild(fileInp);
        thumbGrid.appendChild(addPhotoBtn);
        photoSection.appendChild(thumbGrid);
        row.appendChild(photoSection);
      } else {
        // ── Text section ──
        const inp = document.createElement("textarea");
        inp.value = item.text || "";
        inp.maxLength = 1000;
        inp.rows = Math.max(2, ((item.text||"").match(/\n/g)||[]).length + 1);
        inp.placeholder = "Quick reply text… (Enter = naya line)";
        inp.style.cssText = "width:100%;box-sizing:border-box;padding:5px 8px;border:1px solid #d1f5e8;border-radius:7px;font-size:13px;outline:none;background:#fff;color:#111;resize:none;overflow:hidden;line-height:1.5;font-family:inherit;";
        inp.addEventListener("input", () => {
          _editReplies[i].text = inp.value;
          inp.style.height = "auto";
          inp.style.height = inp.scrollHeight + "px";
        });
        setTimeout(() => { inp.style.height = "auto"; inp.style.height = inp.scrollHeight + "px"; }, 0);
        row.appendChild(inp);
      }

      container.appendChild(row);
    });
  }

  function _fileToBase64(file) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(r.result);
      r.onerror = () => rej(r.error);
      r.readAsDataURL(file);
    });
  }

  function buildQRModal() {
    const m = document.createElement("div");
    m.id = "wnum-qr-modal";
    m.innerHTML = `
      <div id="wnum-qr-box">
        <div id="wnum-qr-box-header">
          <h3>⚡ Quick Replies Manage Karo</h3>
          <span id="wnum-qr-modal-close" style="cursor:pointer;color:#fff;font-size:20px;opacity:0.8;transition:opacity 0.15s;" title="Close">✕</span>
        </div>
        <div id="wnum-qr-box-body">
          <div style="font-size:11px;color:#aaa;margin-bottom:10px;">Reply par click karo edit karne ke liye · ✕ se delete karo</div>
          <div id="wnum-qr-list"></div>
          <div id="wnum-qr-add" style="flex-direction:column;gap:8px;">
            <div style="display:flex;gap:8px;align-items:flex-end;">
              <textarea id="wnum-qr-new" maxlength="1000" rows="2"
                placeholder="Naya text reply likho… (Ctrl+Enter = Add)"
                style="flex:1;padding:7px 10px;border:none;border-radius:8px;font-size:13px;outline:none;background:transparent;color:#111;resize:none;overflow:hidden;line-height:1.5;font-family:inherit;min-height:36px;"></textarea>
              <button id="wnum-qr-add-btn" style="white-space:nowrap;">⚡ Text Add</button>
            </div>
            <button id="wnum-qr-add-photo-btn" style="
              background:linear-gradient(135deg,#f97316,#ea580c);border:none;color:#fff;
              font-size:13px;font-weight:600;padding:8px 16px;border-radius:8px;cursor:pointer;
              width:100%;transition:all 0.15s;
            ">📷 Photo Reply Add Karo</button>
          </div>
        </div>
        <div id="wnum-qr-footer">
          <button id="wnum-qr-cancel">Cancel</button>
          <button id="wnum-qr-save">💾 Save</button>
        </div>
      </div>`;
    document.body.appendChild(m);
    qrModal = m;

    document.getElementById("wnum-qr-add-btn").addEventListener("click", () => {
      const inp = document.getElementById("wnum-qr-new");
      const val = inp.value.replace(/^\n+|\n+$/g, "");
      if (!val) return;
      const lbl = val.split("\n")[0].slice(0, 60) || val;
      _editReplies.push({ type:"text", label:lbl, text:val });
      inp.value = "";
      inp.style.height = "auto";
      renderQRList();
    });

    // ── Add Photo Reply button ──
    document.getElementById("wnum-qr-add-photo-btn").addEventListener("click", () => {
      _editReplies.push({ type:"photo", label:"📷 Photo Reply", images:[], text:"" });
      renderQRList();
      // Scroll to bottom so new item visible
      const body = document.getElementById("wnum-qr-box-body");
      if (body) setTimeout(() => { body.scrollTop = body.scrollHeight; }, 50);
    });
    const newInp = document.getElementById("wnum-qr-new");
    newInp.addEventListener("keydown", e => {
      if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        document.getElementById("wnum-qr-add-btn").click();
      }
    });
    newInp.addEventListener("input", () => {
      newInp.style.height = "auto";
      newInp.style.height = Math.min(newInp.scrollHeight, 120) + "px";
    });
    document.getElementById("wnum-qr-cancel").addEventListener("click", () => {
      m.classList.remove("open");
    });
    document.getElementById("wnum-qr-modal-close").addEventListener("click", () => {
      m.classList.remove("open");
    });
    document.getElementById("wnum-qr-save").addEventListener("click", async () => {
      const newList = _editReplies
        .map(item => {
          if (item.type === "photo") {
            return { type:"photo", label:(item.label||"📷 Photo").trim(), text:(item.text||"").trim(), images:(item.images||[]) };
          }
          const t = (item.text||"").replace(/^\n+|\n+$/g, "");
          const l = (item.label||t).replace(/^\n+|\n+$/g, "") || t;
          return { type:"text", label:l||t, text:t };
        })
        .filter(item => item.type==="photo" ? (item.images&&item.images.length>0)||item.label : item.text);
      await saveQR(newList);
      m.classList.remove("open");
      showToast("✅ Quick replies saved!");
      refreshQRPanel();
    });
    m.addEventListener("click", e => {
      if (e.target === m) m.classList.remove("open");
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // FEATURE: DB SEARCH — Current chat number se Google Sheet data fetch karo
  // ══════════════════════════════════════════════════════════════════════════

  let _dbPopupEl = null;

  /**
   * Current open chat ka phone number nikalta hai (multiple fallback methods)
   */
  /**
   * Check karo ki value real phone number hai ya WhatsApp internal LID
   */
  function isRealPhoneNumber(val) {
    if (!val) return false;
    const cleaned = String(val).replace(/\D/g, '');
    if (cleaned.length < 7 || cleaned.length > 15) return false;
    if (/^[6-9]\d{9}$/.test(cleaned)) return true;    // 10-digit Indian
    if (/^91[6-9]\d{9}$/.test(cleaned)) return true;  // 91 + Indian
    if (/^[1-9]\d{6,14}$/.test(cleaned)) return true; // international
    return false;
  }

  /**
   * Sync DOM-based phone detection (fast, no async needed)
   * Returns phone or null immediately
   */
  function getCurrentChatPhoneSync() {
    try {
      // Method A: message data-id attribute se (unsaved numbers ke liye best)
      const msgs = document.querySelectorAll('[data-id*="@c.us"]');
      for (const el of msgs) {
        const dataId = el.getAttribute('data-id') || '';
        const m = dataId.match(/(\d{10,15})@c\.us/);
        if (m && isRealPhoneNumber(m[1])) return m[1];
      }

      // Method B: main panel ke kisi bhi data-id se
      const mainPanel = document.getElementById('main');
      if (mainPanel) {
        const allDataIds = mainPanel.querySelectorAll('[data-id]');
        for (const el of allDataIds) {
          const did = el.getAttribute('data-id') || '';
          const m2 = did.match(/(\d{10,15})@c\.us/);
          if (m2 && isRealPhoneNumber(m2[1])) return m2[1];
        }
      }

      // Method C: URL/hash se
      const hash = window.location.hash || window.location.pathname || '';
      const hm = hash.match(/(\d{10,15})@c\.us/);
      if (hm && isRealPhoneNumber(hm[1])) return hm[1];

      // Method D: Header mein phone number text dhundho (subtitle mein "+91 XXXXX" format)
      const header = document.querySelector('[data-testid="conversation-header"]');
      if (header) {
        const allEls = header.querySelectorAll('span[title], div[title], span, div');
        for (const sp of allEls) {
          for (const raw of [sp.getAttribute('title') || '', sp.textContent || '']) {
            const cleaned = raw.trim().replace(/[\s\-().+]/g,'');
            if (isRealPhoneNumber(cleaned)) return cleaned;
          }
        }
      }
    } catch(e) {}
    return null;
  }

  /**
   * Async phone detection — DOM se try karo, phir MAIN world bridge se (saved contacts)
   * Returns Promise<string|null>
   */
  // Extract only digits from any string and return valid phone, or null
  function extractCleanPhone(raw) {
    if (!raw) return null;
    const digits = String(raw).replace(/\D/g, '').replace(/^0+/, '');
    if (isRealPhoneNumber(digits)) return digits;
    return null;
  }

  async function getCurrentChatPhone() {
    // Step 1: Fast DOM check pehle (unsaved numbers)
    const domPhone = getCurrentChatPhoneSync();
    if (domPhone) return domPhone;

    // Step 2: MAIN world bridge se active chat phone lo (saved contacts ke liye)
    return new Promise((resolve) => {
      const requestId = 'phone_' + Date.now();
      const timeout = setTimeout(() => {
        window.removeEventListener('message', handler);
        resolve(null);
      }, 2500);

      function handler(event) {
        if (!event.data || event.data.source !== 'wnum-main') return;
        if (event.data.action !== 'GET_ACTIVE_CHAT_PHONE_RESULT') return;
        if (event.data.requestId !== requestId) return;
        clearTimeout(timeout);
        window.removeEventListener('message', handler);
        // Clean karo — sirf valid phone number return karo
        const cleaned = extractCleanPhone(event.data.phone);
        resolve(cleaned);
      }

      window.addEventListener('message', handler);
      window.postMessage({ source: 'wnum-isolated', action: 'GET_ACTIVE_CHAT_PHONE', requestId }, '*');
    });
  }

  /**
   * Simple CSV parser (dashboard wala jo kaam karta hai)
   */
  function parseCSVForDB(text) {
    const lines = text.trim().split(/\r?\n/);
    if (lines.length < 2) return { headers: [], rows: [] };

    function splitCSVLine(line) {
      const result = [];
      let cur = '', inQ = false;
      for (let i = 0; i < line.length; i++) {
        const c = line[i];
        if (c === '"') { inQ = !inQ; continue; }
        if (c === ',' && !inQ) { result.push(cur); cur = ''; continue; }
        cur += c;
      }
      result.push(cur);
      return result.map(s => s.trim());
    }

    const headers = splitCSVLine(lines[0]);
    const rows = lines.slice(1).map(line => {
      const vals = splitCSVLine(line);
      const obj = {};
      headers.forEach((h, i) => { obj[h] = vals[i] !== undefined ? vals[i] : ''; });
      return obj;
    });
    return { headers, rows };
  }

  /**
   * Phone number search karo rows mein
   */
  function searchPhoneInRows(rows, headers, phone, numCol) {
    const searchPhone = phone.replace(/\D/g,'').replace(/^0+/,'');
    const last10 = searchPhone.slice(-10);

    // Pehle numCol mein search karo, phir saare columns mein
    const colsToSearch = numCol && headers.includes(numCol)
      ? [numCol]
      : headers;

    const matchedRows = [];
    for (const row of rows) {
      for (const col of colsToSearch) {
        const cellRaw = String(row[col] || '').replace(/\D/g,'').replace(/^0+/,'');
        if (!cellRaw || cellRaw.length < 7) continue;
        if (cellRaw === searchPhone || cellRaw.slice(-10) === last10) {
          matchedRows.push(row);
          break; // ek row ek baar hi add ho (dusre columns se duplicate nahi)
        }
      }
    }
    return matchedRows.length > 0 ? matchedRows : null;
  }

  /**
   * Google Sheet se us phone number ka row fetch karo
   * Method 1: CSV (fast, no Script URL needed)
   * Method 2: Apps Script readSheet (fallback)
   */
  async function fetchSheetRowByPhone(phone) {
    return new Promise((resolve, reject) => {
      try {
        chrome.storage.local.get(["gsSheetId","gsActiveGid","gsMapping","SCRIPT_URL","gs_sync_config","msSheets","msActiveIdx","wa_subscription_session"], async (data) => {
          const scriptUrl = data.SCRIPT_URL  || "";

          // ── ✅ Sheet Block Check: fetch se pehle server pe verify karo ──
          const _session = data.wa_subscription_session;
          if (_session && _session.username && scriptUrl && !scriptUrl.includes('APNA_SCRIPT_ID')) {
            try {
              const _checkUrl = new URL(scriptUrl);
              _checkUrl.searchParams.set('action',    'checkStatus');
              _checkUrl.searchParams.set('username',  _session.username);
              _checkUrl.searchParams.set('machineId', _session.machineId || '');
              const _checkResp = await fetch(_checkUrl.toString(), { cache: 'no-cache' });
              if (_checkResp.ok) {
                const _checkData = await _checkResp.json();
                if (!_checkData.valid) {
                  // Account block/expired/machine_blocked — data load mat karo
                  return reject('subscription_blocked: ' + (_checkData.message || _checkData.reason || 'blocked'));
                }
              }
            } catch(_e) {
              // Network fail ho toh silently allow karo (offline tolerance)
            }
          }
          // ── End Block Check ──

          // ── Multi-sheet: search across ALL configured sheets (msSheets) ──
          const msSheets = data.msSheets || [];
          if (msSheets.length > 0) {
            // Helper: extract sheetId from URL if not stored directly
            function extractIdFromUrl(url) {
              if (!url) return "";
              const m = url.match(/\/spreadsheets\/d\/([a-zA-Z0-9_-]+)/);
              return m ? m[1] : "";
            }
            // Helper: build CSV url
            function buildCsvUrlLocal(sheetId, gid) {
              let u = `https://docs.google.com/spreadsheets/d/${sheetId}/pub?output=csv`;
              if (gid) u += `&gid=${gid}`;
              return u;
            }

            // Build a list of sheets to search: active first, then others
            const activeIdx = data.msActiveIdx || 0;
            const ordered = [activeIdx, ...msSheets.map((_,i)=>i).filter(i=>i!==activeIdx)];
            const searchedSheets = [];

            for (const idx of ordered) {
              const sheet = msSheets[idx];
              if (!sheet) continue;
              // Get sheetId — try stored first, then extract from url
              const sheetId = sheet.sheetId || extractIdFromUrl(sheet.url) || "";
              if (!sheetId) continue;
              const gid = sheet.activeGid || sheet.gid || "";
              const numCol = (sheet.mapping && sheet.mapping.number) ? sheet.mapping.number : "";
              searchedSheets.push(sheet.name || ("Sheet " + (idx+1)));
              try {
                // If sheet has a direct CSV URL stored, prefer it; else build from sheetId+gid
                let csvUrl;
                if (sheet.url && sheet.url.includes("output=csv")) {
                  csvUrl = sheet.url;
                } else {
                  csvUrl = buildCsvUrlLocal(sheetId, gid);
                }
                const sep = csvUrl.includes("?") ? "&" : "?";
                const resp = await fetch(csvUrl + sep + `t=${Date.now()}`);
                if (resp.ok) {
                  const text = await resp.text();
                  if (text && !text.trim().startsWith('<') && text.includes(',')) {
                    const { headers, rows } = parseCSVForDB(text);
                    if (headers.length > 0 && rows.length > 0) {
                      const foundRows = searchPhoneInRows(rows, headers, phone, numCol);
                      if (foundRows) return resolve({ found: true, headers, rows: foundRows, phone, method: 'csv', sheetName: sheet.name || ("Sheet " + (idx+1)) });
                    }
                  }
                }
              } catch(e) { /* try next sheet */ }
            }
            // All sheets searched, not found — pass info about searched sheets
            const sheet0 = msSheets[activeIdx];
            const headers0 = (sheet0 && sheet0.headers) ? sheet0.headers : [];
            return resolve({ found: false, headers: headers0, phone, method: 'csv', searchedSheets });
          }

          // ── Fallback: legacy single-sheet mode ──
          const sheetId   = data.gsSheetId  || "";
          const gid       = data.gsActiveGid || "";
          const mapping   = data.gsMapping   || {};
          const numCol    = mapping.number   || "";

          if (!sheetId) {
            return reject("not_configured");
          }

          // ── Method 1: CSV (fast, works without Script URL) ──
          try {
            let csvUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/pub?output=csv`;
            if (gid) csvUrl += `&gid=${gid}`;

            const resp = await fetch(csvUrl + `&t=${Date.now()}`);
            if (resp.ok) {
              const text = await resp.text();
              // Check if it's actual CSV (not HTML error page)
              if (text && !text.trim().startsWith('<') && text.includes(',')) {
                const { headers, rows } = parseCSVForDB(text);
                if (headers.length > 0 && rows.length > 0) {
                  const foundRows = searchPhoneInRows(rows, headers, phone, numCol);
                  if (foundRows) return resolve({ found: true, headers, rows: foundRows, phone, method: 'csv' });
                  return resolve({ found: false, headers, phone, method: 'csv' });
                }
              }
            }
          } catch(csvErr) {
            // CSV failed, try Script URL
          }

          // ── Method 2: Apps Script readSheet (fallback) ──
          if (!scriptUrl) {
            return reject("sheet_not_published");
          }

          try {
            const apiUrl = scriptUrl + "?action=readSheet&sheetId=" + encodeURIComponent(sheetId) + (gid ? "&gid=" + encodeURIComponent(gid) : "") + "&t=" + Date.now();
            const resp2 = await fetch(apiUrl);
            const json = await resp2.json();
            if (!json.ok) return reject(json.error || "fetch error");

            const headers = json.headers || [];
            const rows    = json.rows    || [];

            const foundRows = searchPhoneInRows(rows, headers, phone, numCol);
            if (foundRows) return resolve({ found: true, headers, rows: foundRows, phone, method: 'script' });
            return resolve({ found: false, headers, phone, method: 'script' });

          } catch(apiErr) {
            reject(apiErr.message || String(apiErr));
          }
        });
      } catch(e) {
        reject(e.message || String(e));
      }
    });
  }

  // ── QR Preview Popup (DB Search style) ──────────────────────────────────
  /**
   * DB Popup open karo
   */
  // Track which sheet is selected in DB popup (0 = first, -1 = All sheets)
  let _dbSelectedSheetIdx = -1; // Default: ALL sheets search

  // ── Universal text search across ALL sheets ──────────────────────────────
  async function searchAllSheetsText(query) {
    return new Promise((resolve) => {
      chrome.storage.local.get(["msSheets","msActiveIdx","gsSheetId","gsActiveGid","gsMapping","SCRIPT_URL"], async (data) => {
        const msSheets = data.msSheets || [];
        const query_lower = query.trim().toLowerCase();
        if (!query_lower) return resolve({ found: false, results: [] });

        function extractIdFromUrl(url) {
          if (!url) return "";
          const m = url.match(/\/spreadsheets\/d\/([a-zA-Z0-9_-]+)/);
          return m ? m[1] : "";
        }

        // Multi-sheet mode
        if (msSheets.length > 0) {
          const allResults = []; // [{sheetName, headers, rows:[]}]

          for (let idx = 0; idx < msSheets.length; idx++) {
            const sheet = msSheets[idx];
            const sheetId = sheet.sheetId || extractIdFromUrl(sheet.url) || "";
            if (!sheetId) continue;
            const gid = sheet.activeGid || sheet.gid || "";
            let csvUrl = (sheet.url && sheet.url.includes("output=csv"))
              ? sheet.url
              : `https://docs.google.com/spreadsheets/d/${sheetId}/pub?output=csv` + (gid ? `&gid=${gid}` : "");
            try {
              const sep = csvUrl.includes("?") ? "&" : "?";
              const resp = await fetch(csvUrl + sep + `t=${Date.now()}`);
              if (resp.ok) {
                const text = await resp.text();
                if (text && !text.trim().startsWith("<") && text.includes(",")) {
                  const { headers, rows } = parseCSVForDB(text);
                  // Search in ALL columns
                  const matched = rows.filter(row =>
                    headers.some(h => String(row[h] || "").toLowerCase().includes(query_lower))
                  );
                  if (matched.length > 0) {
                    allResults.push({ sheetName: sheet.name || ("Sheet " + (idx+1)), headers, rows: matched });
                  }
                }
              }
            } catch(e) {}
          }

          if (allResults.length > 0) return resolve({ found: true, results: allResults });
          return resolve({ found: false, results: [] });
        }

        // Single sheet fallback
        const sheetId = data.gsSheetId || "";
        const gid = data.gsActiveGid || "";
        if (!sheetId) return resolve({ found: false, results: [], error: "not_configured" });
        try {
          const csvUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/pub?output=csv` + (gid ? `&gid=${gid}` : "");
          const resp = await fetch(csvUrl + `&t=${Date.now()}`);
          if (resp.ok) {
            const text = await resp.text();
            if (text && !text.trim().startsWith("<") && text.includes(",")) {
              const { headers, rows } = parseCSVForDB(text);
              const matched = rows.filter(row =>
                headers.some(h => String(row[h] || "").toLowerCase().includes(query_lower))
              );
              if (matched.length > 0) return resolve({ found: true, results: [{ sheetName: "Sheet 1", headers, rows: matched }] });
              return resolve({ found: false, results: [] });
            }
          }
        } catch(e) {}
        resolve({ found: false, results: [] });
      });
    });
  }

  // Fetch from one specific sheet by index (phone search)
  async function fetchFromOneSheet(sheetIdx, phone) {
    return new Promise((resolve, reject) => {
      chrome.storage.local.get(["msSheets","msActiveIdx","gsSheetId","gsActiveGid","gsMapping","SCRIPT_URL"], async (data) => {
        const msSheets = data.msSheets || [];
        function extractIdFromUrl(url) {
          if (!url) return "";
          const m = url.match(/\/spreadsheets\/d\/([a-zA-Z0-9_-]+)/);
          return m ? m[1] : "";
        }

        if (msSheets.length > 0 && sheetIdx >= 0 && sheetIdx < msSheets.length) {
          const sheet = msSheets[sheetIdx];
          const sheetId = sheet.sheetId || extractIdFromUrl(sheet.url) || "";
          if (!sheetId) return resolve({ found: false, phone });
          const gid = sheet.activeGid || sheet.gid || "";
          const numCol = (sheet.mapping && sheet.mapping.number) ? sheet.mapping.number : "";
          let csvUrl = (sheet.url && sheet.url.includes("output=csv"))
            ? sheet.url
            : `https://docs.google.com/spreadsheets/d/${sheetId}/pub?output=csv` + (gid ? `&gid=${gid}` : "");
          try {
            const sep = csvUrl.includes("?") ? "&" : "?";
            const resp = await fetch(csvUrl + sep + `t=${Date.now()}`);
            if (resp.ok) {
              const text = await resp.text();
              if (text && !text.trim().startsWith("<") && text.includes(",")) {
                const { headers, rows } = parseCSVForDB(text);
                const foundRows = searchPhoneInRows(rows, headers, phone, numCol);
                if (foundRows) return resolve({ found: true, headers, rows: foundRows, phone, sheetName: sheet.name });
                return resolve({ found: false, headers, phone, sheetName: sheet.name });
              }
            }
          } catch(e) {}
          return resolve({ found: false, phone, sheetName: sheet.name });
        }

        // All-sheets phone search (sheetIdx === -1)
        if (sheetIdx === -1 && msSheets.length > 0) {
          for (let idx = 0; idx < msSheets.length; idx++) {
            const sheet = msSheets[idx];
            const sheetId = sheet.sheetId || extractIdFromUrl(sheet.url) || "";
            if (!sheetId) continue;
            const gid = sheet.activeGid || sheet.gid || "";
            const numCol = (sheet.mapping && sheet.mapping.number) ? sheet.mapping.number : "";
            let csvUrl = (sheet.url && sheet.url.includes("output=csv"))
              ? sheet.url
              : `https://docs.google.com/spreadsheets/d/${sheetId}/pub?output=csv` + (gid ? `&gid=${gid}` : "");
            try {
              const sep = csvUrl.includes("?") ? "&" : "?";
              const resp = await fetch(csvUrl + sep + `t=${Date.now()}`);
              if (resp.ok) {
                const text = await resp.text();
                if (text && !text.trim().startsWith("<") && text.includes(",")) {
                  const { headers, rows } = parseCSVForDB(text);
                  const foundRows = searchPhoneInRows(rows, headers, phone, numCol);
                  if (foundRows) return resolve({ found: true, headers, rows: foundRows, phone, sheetName: sheet.name || ("Sheet " + (idx+1)) });
                }
              }
            } catch(e) {}
          }
          return resolve({ found: false, phone, searchedSheets: msSheets.map((s,i) => s.name || ("Sheet "+(i+1))) });
        }

        // fallback single sheet
        const sheetId = data.gsSheetId || "";
        const gid = data.gsActiveGid || "";
        const numCol = (data.gsMapping && data.gsMapping.number) ? data.gsMapping.number : "";
        if (!sheetId) return resolve({ found: false, phone });
        try {
          const csvUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/pub?output=csv` + (gid ? `&gid=${gid}` : "");
          const resp = await fetch(csvUrl + `&t=${Date.now()}`);
          if (resp.ok) {
            const text = await resp.text();
            const { headers, rows } = parseCSVForDB(text);
            const foundRows = searchPhoneInRows(rows, headers, phone, numCol);
            if (foundRows) return resolve({ found: true, headers, rows: foundRows, phone });
            return resolve({ found: false, headers, phone });
          }
        } catch(e) {}
        resolve({ found: false, phone });
      });
    });
  }

  async function openDBPopup() {
    // Create popup if not exists
    if (!_dbPopupEl) {
      _dbPopupEl = buildDBPopup();
    }

    // Position: just above the QR panel
    const qrPanel = document.getElementById("wnum-qr-panel");
    if (qrPanel && _dbPopupEl) {
      const rect = qrPanel.getBoundingClientRect();
      _dbPopupEl.style.bottom = (window.innerHeight - rect.top + 8) + "px";
      _dbPopupEl.style.right  = "16px";
      _dbPopupEl.style.left   = "auto";
    }

    _dbPopupEl.classList.add("open");

    const phoneDisplay = _dbPopupEl.querySelector("#wnum-db-popup-phone");
    const bodyEl = _dbPopupEl.querySelector("#wnum-db-popup-body");
    const selectorEl = _dbPopupEl.querySelector("#wnum-db-sheet-selector");
    const searchInputEl = _dbPopupEl.querySelector("#wnum-db-universal-search");
    const searchBtnEl = _dbPopupEl.querySelector("#wnum-db-universal-search-btn");
    const footerEl = _dbPopupEl.querySelector("#wnum-db-popup-footer");

    // Selected rows for multi-fill (Map: key = sheetName+rowIdx, value = {rowData, headers, sheetName})
    const _selectedRows = new Map();

    function updateFooterSendBtn() {
      if (!footerEl) return;
      const count = _selectedRows.size;
      if (count > 0) {
        footerEl.innerHTML = `<button id="wnum-db-send-selected" style="
          width:100%;padding:9px 14px;background:linear-gradient(135deg,#00a884,#00cf9d);
          color:#fff;border:none;border-radius:10px;font-size:13px;font-weight:700;
          cursor:pointer;letter-spacing:0.3px;box-shadow:0 2px 8px rgba(0,168,132,0.3);">
          ✅ ${count} row${count>1?"s":""} send karo chatbox mein
        </button>`;
        footerEl.querySelector("#wnum-db-send-selected").addEventListener("click", () => {
          sendSelectedRowsToChat();
        });
      } else {
        footerEl.innerHTML = `<span style="font-size:11px;color:#888;">☑️ Checkbox tick karo → chatbox mein send karo</span>`;
      }
    }

    function sendSelectedRowsToChat() {
      if (_selectedRows.size === 0) return;
      let lines = [];
      _selectedRows.forEach(({ rowData, headers, sheetName }) => {
        if (sheetName) lines.push("📂 " + sheetName);
        headers.forEach(h => {
          const val = (rowData[h] || "").trim();
          if (val) lines.push("*" + h + "* - " + val);
        });
        lines.push(""); // blank line between rows
      });
      // Remove trailing blank
      while (lines.length > 0 && lines[lines.length-1] === "") lines.pop();

      // WhatsApp mein multiline paste karne ka sahi tarika: text/html with <br>
      const box = getComposeBox();
      if (!box) return;
      box.focus();

      // Escape HTML special chars
      function esc(s) {
        return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
      }

      const htmlContent = lines.map(l => l === "" ? "<br>" : esc(l)).join("<br>");
      const dt = new DataTransfer();
      dt.setData("text/plain", lines.join("\n"));
      dt.setData("text/html", "<span>" + htmlContent + "</span>");
      box.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));

      // Uncheck all
      _selectedRows.clear();
      _dbPopupEl.querySelectorAll(".wnum-db-row-checkbox").forEach(cb => { cb.checked = false; });
      _dbPopupEl.querySelectorAll(".wnum-db-row-wrap").forEach(el => {
        el.classList.remove("checked");
        el.style.borderColor = "#e2e8f0";
        el.style.background = "#fff";
        const top = el.querySelector("div");
        if (top) top.style.background = "#f8fafc";
        const hint = el.querySelector("span:last-child");
        if (hint && hint.style) { hint.style.color = "#94a3b8"; hint.textContent = "☑ Full row"; }
      });
      updateFooterSendBtn();
    }

    // Helper: reset body with a single message element
    function showBodyMsg(html, color) {
      bodyEl.innerHTML = "";
      const el = document.createElement("div");
      el.style.cssText = "padding:14px 16px;font-size:13px;color:" + (color||"#555") + ";text-align:center;line-height:1.6;";
      el.innerHTML = html;
      bodyEl.appendChild(el);
    }

    // Build sheet selector buttons (Sheet 1, Sheet 2, ALL)
    async function buildSheetSelector(phone) {
      if (!selectorEl) return;
      const stored = await new Promise(r => chrome.storage.local.get(["msSheets","msActiveIdx"], r));
      const msSheets = stored.msSheets || [];
      const validSheets = msSheets.filter(s => s.sheetId || (s.url && s.url.includes("spreadsheets")));
      if (validSheets.length < 1) { selectorEl.style.display = "none"; return; }

      selectorEl.style.display = "flex";
      selectorEl.innerHTML = "";

      const label = document.createElement("span");
      label.className = "wnum-db-sheet-label";
      label.textContent = "Sheet:";
      selectorEl.appendChild(label);

      // "ALL" button
      const allBtn = document.createElement("button");
      allBtn.className = "wnum-db-sheet-btn" + (_dbSelectedSheetIdx === -1 ? " active" : "");
      allBtn.textContent = "🔍 All";
      allBtn.dataset.sheetIdx = -1;
      selectorEl.appendChild(allBtn);

      // One button per sheet
      msSheets.forEach((s, i) => {
        const hasConfig = s.sheetId || (s.url && s.url.includes("spreadsheets"));
        if (!hasConfig) return;
        const btn = document.createElement("button");
        btn.className = "wnum-db-sheet-btn" + (_dbSelectedSheetIdx === i ? " active" : "");
        btn.textContent = "📂 " + (s.name || ("Sheet " + (i+1)));
        btn.dataset.sheetIdx = i;
        selectorEl.appendChild(btn);
      });

      // Click handler
      selectorEl.onclick = async (e) => {
        const btn = e.target.closest(".wnum-db-sheet-btn");
        if (!btn) return;
        const idx = parseInt(btn.dataset.sheetIdx, 10);
        _dbSelectedSheetIdx = idx;
        selectorEl.querySelectorAll(".wnum-db-sheet-btn").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        showBodyMsg("⏳ Fetching...", "#6366f1");
        await doPhoneFetch(phone);
      };
    }

    // ── Phone-based fetch ──────────────────────────────────────────────────
    async function doPhoneFetch(phone) {
      const result = await fetchFromOneSheet(_dbSelectedSheetIdx, phone);
      renderPhoneResult(result);
    }

    // ── Universal text search handler ──────────────────────────────────────
    if (searchInputEl) {
      // Allow pressing Enter in search box
      searchInputEl.onkeydown = async (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          await doUniversalSearch();
        }
      };
    }
    if (searchBtnEl) {
      searchBtnEl.onclick = async () => { await doUniversalSearch(); };
    }

    async function doUniversalSearch() {
      const query = searchInputEl ? searchInputEl.value.trim() : "";
      if (!query) {
        showBodyMsg("⚠️ Kuch type karo search karne ke liye", "#e67e22");
        return;
      }
      showBodyMsg("⏳ Sabhi sheets mein search ho raha hai...", "#6366f1");
      try {
        const result = await searchAllSheetsText(query);
        renderUniversalResult(result, query);
      } catch(e) {
        showBodyMsg("❌ Search error: " + String(e), "#e74c3c");
      }
    }

    // ── Render: universal search results (grouped by sheet) ───────────────
    function renderUniversalResult(result, query) {
      bodyEl.innerHTML = "";
      _selectedRows.clear();
      updateFooterSendBtn();

      if (!result.found || result.results.length === 0) {
        showBodyMsg("🔍 <strong>" + query + "</strong> kisi bhi sheet mein nahi mila", "#e74c3c");
        return;
      }

      // Count total
      let totalRows = result.results.reduce((s, r) => s + r.rows.length, 0);
      const banner = document.createElement("div");
      banner.style.cssText = "padding:5px 10px;font-size:11px;background:#eef2ff;color:#4f46e5;border-radius:8px;margin-bottom:8px;text-align:center;font-weight:700;";
      banner.textContent = "✅ " + totalRows + " result" + (totalRows>1?"s":"") + " mile — " + result.results.length + " sheet" + (result.results.length>1?"s mein":"");
      bodyEl.appendChild(banner);

      // Group by sheet
      result.results.forEach(({ sheetName, headers, rows }) => {
        // Sheet group header
        const sheetHeader = document.createElement("div");
        sheetHeader.style.cssText = "padding:5px 10px;font-size:11px;font-weight:800;color:#fff;background:linear-gradient(90deg,#6366f1,#818cf8);border-radius:8px;margin:6px 0 4px 0;letter-spacing:0.4px;";
        sheetHeader.textContent = "📂 " + sheetName + " (" + rows.length + " record" + (rows.length>1?"s":"") + ")";
        bodyEl.appendChild(sheetHeader);

        rows.forEach((rowData, rowIdx) => {
          renderRowCard(bodyEl, rowData, headers, sheetName, "univ_" + sheetName + "_" + rowIdx);
        });
      });
    }

    // ── Render: phone search result ────────────────────────────────────────
    function renderPhoneResult(result) {
      bodyEl.innerHTML = "";
      _selectedRows.clear();
      updateFooterSendBtn();

      if (!result.found) {
        const sheetsInfo = result.searchedSheets && result.searchedSheets.length > 0
          ? "<br><span style='font-size:11px;opacity:0.75'>Searched: " + result.searchedSheets.join(", ") + "</span>"
          : (result.sheetName ? "<br><span style='font-size:11px;opacity:0.75'>Sheet: " + result.sheetName + "</span>" : "");
        showBodyMsg("🔍 <strong>" + (result.phone||"") + "</strong> ka data kisi bhi sheet mein nahi mila" + sheetsInfo, "#e74c3c");
        return;
      }

      const headers = result.headers || Object.keys(result.rows[0]);
      const allRows = result.rows;
      const sheetName = result.sheetName || "";

      if (sheetName) {
        const sheetHeader = document.createElement("div");
        sheetHeader.style.cssText = "padding:5px 10px;font-size:11px;font-weight:800;color:#fff;background:linear-gradient(90deg,#6366f1,#818cf8);border-radius:8px;margin-bottom:6px;letter-spacing:0.4px;";
        sheetHeader.textContent = "📂 " + sheetName;
        bodyEl.appendChild(sheetHeader);
      }

      if (allRows.length > 1) {
        const banner = document.createElement("div");
        banner.style.cssText = "padding:5px 10px;font-size:11px;background:#eef2ff;color:#4f46e5;border-radius:8px;margin-bottom:8px;text-align:center;font-weight:600;";
        banner.textContent = "📋 " + allRows.length + " records mile";
        bodyEl.appendChild(banner);
      }

      allRows.forEach((rowData, idx) => {
        renderRowCard(bodyEl, rowData, headers, sheetName, "phone_" + idx);
      });
    }

    // ── Core: render a single row as a card with checkbox + bold fields ────
    function renderRowCard(container, rowData, headers, sheetName, uniqKey) {
      const card = document.createElement("div");
      card.className = "wnum-db-row-wrap";
      card.style.cssText = [
        "border:1.5px solid #e2e8f0;border-radius:10px;margin-bottom:7px;",
        "overflow:hidden;transition:border-color 0.15s,background 0.15s;background:#fff;"
      ].join("");

      // ── Card top: checkbox + title ─────────────────────────────────────
      const cardTop = document.createElement("div");
      cardTop.style.cssText = [
        "display:flex;align-items:center;gap:8px;",
        "padding:6px 10px 5px 10px;background:#f8fafc;",
        "border-bottom:1px solid #e2e8f0;cursor:pointer;user-select:none;"
      ].join("");

      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.className = "wnum-db-row-checkbox";
      cb.style.cssText = "width:15px;height:15px;cursor:pointer;accent-color:#6366f1;flex-shrink:0;margin-top:1px;";
      cb.title = "Tick karo → poori row chatbox mein send karo";

      // Title: first non-empty non-number value
      const titleVal = headers.map(h => rowData[h]).find(v => v && v.trim() && !/^\d+$/.test(v.trim())) || ("Record");
      const titleSpan = document.createElement("span");
      titleSpan.style.cssText = "font-size:12px;font-weight:700;color:#374151;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;";
      titleSpan.textContent = String(titleVal).substring(0, 38);

      // Hint label on the right
      const cbHint = document.createElement("span");
      cbHint.style.cssText = "font-size:9.5px;color:#94a3b8;white-space:nowrap;flex-shrink:0;";
      cbHint.textContent = "☑ Full row";

      // Expand/collapse arrow
      const arrowSpan = document.createElement("span");
      arrowSpan.style.cssText = "font-size:11px;color:#94a3b8;flex-shrink:0;transition:transform 0.2s;display:inline-block;margin-left:2px;";
      arrowSpan.textContent = "▶";

      cardTop.appendChild(cb);
      cardTop.appendChild(titleSpan);
      cardTop.appendChild(cbHint);
      cardTop.appendChild(arrowSpan);
      card.appendChild(cardTop);

      // ── Card body: fields — LABEL bold | value | 📝 Fill button ─────────
      const cardBody = document.createElement("div");
      // Collapsed by default
      cardBody.style.cssText = "padding:0 8px;max-height:0;overflow:hidden;transition:max-height 0.3s ease,padding 0.2s;";
      let cardExpanded = false;

      headers.forEach(header => {
        const val = (rowData[header] || "").trim();
        if (!val) return; // Skip empty fields

        const fieldRow = document.createElement("div");
        fieldRow.className = "wnum-db-field-row";
        fieldRow.style.cssText = [
          "display:flex;align-items:center;gap:5px;",
          "padding:3px 2px;border-bottom:1px solid #f1f5f9;",
          "transition:background 0.12s;border-radius:4px;"
        ].join("");

        // Bold label
        const fieldLabel = document.createElement("span");
        fieldLabel.style.cssText = "font-size:10.5px;font-weight:800;color:#6366f1;min-width:72px;flex-shrink:0;text-transform:uppercase;letter-spacing:0.2px;line-height:1.3;";
        fieldLabel.textContent = header;

        // Separator
        const fieldSep = document.createElement("span");
        fieldSep.style.cssText = "font-size:11px;color:#cbd5e1;flex-shrink:0;font-weight:600;";
        fieldSep.textContent = "—";

        // Value text
        const fieldVal = document.createElement("span");
        fieldVal.style.cssText = "font-size:11.5px;color:#1e293b;font-weight:500;flex:1;word-break:break-word;line-height:1.35;";
        fieldVal.textContent = val;

        // 📝 Fill button — single value bhejo chatbox mein
        const fillBtn = document.createElement("button");
        fillBtn.className = "wnum-db-row-copy";
        fillBtn.textContent = "📝";
        fillBtn.title = "Sirf yeh value chatbox mein daalo: " + val;
        fillBtn.style.cssText = [
          "padding:2px 7px;font-size:11px;border:1px solid #c7d2fe;",
          "background:#f0f4ff;color:#4f46e5;border-radius:6px;cursor:pointer;",
          "flex-shrink:0;transition:background 0.15s;font-weight:600;line-height:1.4;"
        ].join("");

        fillBtn.addEventListener("mouseenter", () => { fillBtn.style.background = "#6366f1"; fillBtn.style.color = "#fff"; });
        fillBtn.addEventListener("mouseleave", () => { fillBtn.style.background = "#f0f4ff"; fillBtn.style.color = "#4f46e5"; });

        fillBtn.addEventListener("click", (e) => {
          e.stopPropagation();
          const box = getComposeBox();
          if (box) {
            box.focus();
            function escH(s) { return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
            const lineText = "*" + header + "* - " + val;
            // Chatbox mein kuch hai ya nahi check karo
            const isEmpty = (box.textContent || "").trim() === "" && (box.innerHTML || "").replace(/<br\s*\/?>/gi,"").trim() === "";
            const htmlLine = isEmpty
              ? escH(lineText)                          // Pehli line: no <br>
              : "<br>" + escH(lineText);                // Agle lines: <br> pehle
            const dt = new DataTransfer();
            dt.setData("text/plain", isEmpty ? lineText : "\n" + lineText);
            dt.setData("text/html", "<span>" + htmlLine + "</span>");
            box.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
          }
          fillBtn.textContent = "✅";
          fillBtn.style.background = "#d1fae5";
          fillBtn.style.borderColor = "#6ee7b7";
          setTimeout(() => {
            fillBtn.textContent = "📝";
            fillBtn.style.background = "#f0f4ff";
            fillBtn.style.borderColor = "#c7d2fe";
            fillBtn.style.color = "#4f46e5";
          }, 1000);
        });

        // Highlight row on hover
        fieldRow.addEventListener("mouseenter", () => { fieldRow.style.background = "#f8faff"; });
        fieldRow.addEventListener("mouseleave", () => { fieldRow.style.background = ""; });

        fieldRow.appendChild(fieldLabel);
        fieldRow.appendChild(fieldSep);
        fieldRow.appendChild(fieldVal);
        fieldRow.appendChild(fillBtn);
        cardBody.appendChild(fieldRow);
      });

      card.appendChild(cardBody);

      // ── Checkbox toggle logic (poori row select) ──────────────────────
      function toggleCheck(checked) {
        cb.checked = checked;
        card.classList.toggle("checked", checked);
        card.style.borderColor = checked ? "#6366f1" : "#e2e8f0";
        card.style.background  = checked ? "#f5f3ff" : "#fff";
        cardTop.style.background = checked ? "#ede9fe" : "#f8fafc";
        cbHint.style.color = checked ? "#6366f1" : "#94a3b8";
        cbHint.textContent = checked ? "✔ Selected" : "☑ Full row";
        // Auto-expand card when checkbox is ticked
        if (checked && !cardExpanded) toggleExpand();
        if (checked) {
          _selectedRows.set(uniqKey, { rowData, headers, sheetName });
        } else {
          _selectedRows.delete(uniqKey);
        }
        updateFooterSendBtn();
      }

      cb.addEventListener("change", (e) => { e.stopPropagation(); toggleCheck(cb.checked); });

      // Toggle expand/collapse on cardTop click (not on checkbox)
      function toggleExpand() {
        cardExpanded = !cardExpanded;
        if (cardExpanded) {
          cardBody.style.maxHeight = cardBody.scrollHeight + 80 + "px";
          cardBody.style.padding = "4px 8px 4px 8px";
          arrowSpan.style.transform = "rotate(90deg)";
          arrowSpan.style.color = "#6366f1";
          cardTop.style.borderBottom = "1px solid #e2e8f0";
        } else {
          cardBody.style.maxHeight = "0";
          cardBody.style.padding = "0 8px";
          arrowSpan.style.transform = "rotate(0deg)";
          arrowSpan.style.color = "#94a3b8";
          cardTop.style.borderBottom = "1px solid transparent";
        }
      }

      cardTop.addEventListener("click", (e) => {
        if (e.target === cb) return;
        toggleExpand();
      });

      container.appendChild(card);
    }

    // ── Initial load ───────────────────────────────────────────────────────
    showBodyMsg("⏳ Sheet se data fetch ho raha hai...", "#00a884");
    if (phoneDisplay) phoneDisplay.textContent = "🔍 Number detect ho raha hai...";

    // Get current phone
    const rawPhone = await getCurrentChatPhone();
    const phone = rawPhone
      ? (String(rawPhone).replace(/\D/g,'').replace(/^0+/,'') || null)
      : null;

    if (phoneDisplay) {
      phoneDisplay.textContent = phone
        ? "📱 " + phone
        : "⚠️ Phone number detect nahi hua";
    }

    // Build sheet selector (non-blocking)
    buildSheetSelector(phone);

    updateFooterSendBtn();

    if (!phone) {
      showBodyMsg("⚠️ Pehle koi chat open karo jisme phone number ho — ya upar universal search use karo", "#e67e22");
      return;
    }

    // Initial phone-based fetch
    doPhoneFetch(phone).catch(err => {
      let msg;
      if (err === "not_configured") {
        msg = "⚙️ Google Sheet connect nahi hai.<br><small>Dashboard → Google Sheets tab mein Sheet URL daalo</small>";
      } else if (err === "sheet_not_published") {
        msg = "📋 Sheet publish nahi hai.<br><small>Google Sheet → File → Share → Publish to web → CSV</small>";
      } else {
        msg = "❌ Error: <small>" + String(err) + "</small>";
      }
      showBodyMsg(msg, "#e74c3c");
    });
  }

  /**
   * DB Popup DOM element banao
   */
  function buildDBPopup() {
    const popup = document.createElement("div");
    popup.id = "wnum-db-popup";
    popup.innerHTML = `
      <div id="wnum-db-popup-header">
        <h4>🗄️ DB Data Search</h4>
        <button id="wnum-db-popup-close" title="Close">✕</button>
      </div>
      <div id="wnum-db-popup-phone"></div>
      <div id="wnum-db-universal-search-wrap" style="display:flex;gap:6px;padding:6px 10px 4px 10px;align-items:center;">
        <input id="wnum-db-universal-search" type="text" placeholder="🔍 Naam, number, kuch bhi search karo..." style="
          flex:1;padding:7px 10px;border:1.5px solid #c7d2fe;border-radius:8px;
          font-size:12px;background:#f8faff;color:#1e293b;outline:none;
          transition:border-color 0.15s;" />
        <button id="wnum-db-universal-search-btn" style="
          padding:7px 12px;background:linear-gradient(135deg,#6366f1,#818cf8);
          color:#fff;border:none;border-radius:8px;font-size:12px;font-weight:700;
          cursor:pointer;white-space:nowrap;">Search</button>
      </div>
      <div id="wnum-db-sheet-selector" style="display:none"></div>
      <div id="wnum-db-popup-body">
        <div id="wnum-db-loading">⏳ Sheet se data fetch ho raha hai...</div>
        <div id="wnum-db-error"></div>
        <div id="wnum-db-notfound"></div>
      </div>
      <div id="wnum-db-popup-footer" style="padding:8px 10px;border-top:1px solid #e2e8f0;text-align:center;font-size:11px;color:#888;">
        ☑️ Checkbox tick karo → chatbox mein send karo
      </div>`;
    document.body.appendChild(popup);

    // Close button
    popup.querySelector("#wnum-db-popup-close").addEventListener("click", () => {
      popup.classList.remove("open");
    });

    // Click outside to close
    document.addEventListener("mousedown", (e) => {
      if (popup.classList.contains("open") && !popup.contains(e.target)) {
        const dbBtns = document.querySelectorAll(".wnum-db-search-btn");
        let clickedBtn = false;
        dbBtns.forEach(btn => { if (btn.contains(e.target)) clickedBtn = true; });
        if (!clickedBtn) popup.classList.remove("open");
      }
    });

    return popup;
  }

  // Watch for footer (compose box) to appear
  // Sync our chip highlights if user clicks WA's own native tabs
  function watchNativeTabs() {
    const pane = document.querySelector('#pane-side');
    if (!pane || pane._nativeTabWatcher) return;
    pane._nativeTabWatcher = true;
    pane.addEventListener('click', e => {
      const btn = e.target.closest('button,[role="button"],[role="tab"]');
      if (!btn) return;
      const txt = (btn.textContent || '').trim().toLowerCase();
      let waKey = null;
      if (txt === 'all' || txt.startsWith('all')) waKey = 'All';
      else if (txt.includes('unread'))            waKey = 'Unread';
      if (waKey) {
        document.querySelectorAll('.wnum-chip').forEach(c => c.classList.remove('active'));
        const ourChip = document.querySelector(`.wnum-chip[data-key="${waKey}"]`);
        if (ourChip) ourChip.classList.add('active');
        activeFilter = waKey;
        clearFilterOverlay(document.querySelector('#pane-side'));
      }
    }, true);
  }

  let footerObserver = null;
  function watchForFooter() {
    if (footerObserver) return;
    let debounce = null;
    footerObserver = new MutationObserver(() => {
      clearTimeout(debounce);
      debounce = setTimeout(() => {
        // Skip if we're already building
        if (qrBuilding) return;
        // Reset stale ref if panel was removed from DOM
        if (qrPanelEl && !document.contains(qrPanelEl)) {
          qrPanelEl = null;
        }
        const hasCompose =
          document.querySelector('[data-testid="conversation-compose-box-input"]') ||
          document.querySelector('div[contenteditable="true"][data-tab="10"]');
        const panelInDOM = qrPanelEl && document.contains(qrPanelEl);

        if (hasCompose && !panelInDOM) {
          // Remove any ghost panels then rebuild
          document.querySelectorAll("#wnum-qr-panel").forEach(el => { if (el !== qrPanelEl) el.remove(); });
          qrPanelEl = null; qrBuilding = false;
          buildQRPanel().then(() => setTimeout(positionQRPanel, 200));
        } else if (hasCompose && panelInDOM) {
          positionQRPanel();
        } else if (!hasCompose && panelInDOM) {
          qrPanelEl.style.display = "none";
        }
      }, 400);
    });
    footerObserver.observe(document.body, { childList: true, subtree: true });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // FEATURE 3 — DOWNLOAD CONTACTS
  // Scans visible chat list → exports as CSV
  // ══════════════════════════════════════════════════════════════════════════

  // ══════════════════════════════════════════════════════════════════════════
  // GROUP CONTACT DOWNLOAD — Using WhatsApp Internal Modules (like SheetWA)
  // ══════════════════════════════════════════════════════════════════════════

  /** postMessage bridge to group-extractor.js (MAIN world) */
  let _reqCounter = 0;
  function waRequest(action, extra = {}) {
    return new Promise((resolve) => {
      const requestId = ++_reqCounter;
      const resultAction = action + "_RESULT";
      function handler(event) {
        if (!event.data || event.data.source !== "wnum-main") return;
        if (event.data.action !== resultAction) return;
        if (event.data.requestId !== requestId) return;
        window.removeEventListener("message", handler);
        resolve(event.data);
      }
      window.addEventListener("message", handler);
      window.postMessage({ source: "wnum-isolated", action, requestId, ...extra }, "*");
      // Timeout after 8 seconds
      setTimeout(() => {
        window.removeEventListener("message", handler);
        resolve({ error: "timeout", groups: [], contacts: [] });
      }, 8000);
    });
  }

  /** Get all groups via MAIN world bridge */
  async function getAllGroupNames() {
    const result = await waRequest("GET_GROUPS");
    if (result.groups && result.groups.length > 0) return result.groups;
    // Fallback: scrape visible chat list for group icons
    const groups = [];
    const pane = document.querySelector('#pane-side,[data-testid="chat-list"]');
    if (!pane) return groups;
    pane.querySelectorAll('[data-testid="cell-frame-container"],[role="row"]').forEach(row => {
      const hasGroupIcon =
        !!row.querySelector('[data-icon="default-group"]')         ||
        !!row.querySelector('[data-icon="group"]')                 ||
        !!row.querySelector('[data-testid="group-chat-indicator"]');
      if (!hasGroupIcon) return;
      const titleEl =
        row.querySelector('[data-testid="cell-frame-title"] span') ||
        row.querySelector('span[title]');
      if (!titleEl) return;
      const name = titleEl.textContent.trim();
      if (name) groups.push({ name, id: '' });
    });
    return groups;
  }

  /** Download contacts from a specific group via MAIN world bridge */
  async function downloadGroupContacts(groupId, groupName) {
    showToast('⏳ Group contacts load ho rahe hain...');
    if (!groupId) { showToast('⚠️ Group ID nahi mila.'); return; }
    const result = await waRequest("GET_GROUP_CONTACTS", { groupId });
    if (result.error) { showToast('⚠️ Error: ' + result.error); return; }
    const contacts = result.contacts || [];
    if (!contacts.length) { showToast('⚠️ Is group mein koi contact nahi mila.'); return; }
    const headers = ['#', 'Name', 'Phone', 'Business', 'Group'];
    const rows = contacts.map(c => [
      c.index,
      `"${(c.name || '').replace(/"/g, '""')}"`,
      c.phone,
      c.isBusiness ? 'Yes' : 'No',
      `"${groupName.replace(/"/g, '""')}"`,
    ]);
    const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `group_${groupName.replace(/[^a-z0-9]/gi,'_')}_contacts.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showToast(`✅ ${contacts.length} contacts download ho gaye!`);
  }

  /** Build a floating "📥 Groups" button always visible on WhatsApp Web */
  function buildGroupFloatingBtn() {
    if (document.getElementById('wnum-float-grp')) return;
    const btn = document.createElement('div');
    btn.id = 'wnum-float-grp';
    btn.title = 'Group contacts download karo';
    btn.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
        stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"
        style="flex-shrink:0;">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
        <circle cx="9" cy="7" r="4"/>
        <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
        <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
      </svg>
      <span style="font-size:12px;font-weight:600;">Groups</span>
      <span style="font-size:10px;opacity:0.8;">↓</span>
    `;
    btn.style.cssText = `
      position: fixed;
      bottom: 130px;
      left: 20px;
      z-index: 99999;
      background: linear-gradient(135deg, #00a884, #008f72);
      color: #fff;
      padding: 9px 15px;
      border-radius: 22px;
      display: flex;
      align-items: center;
      gap: 6px;
      cursor: pointer;
      box-shadow: 0 4px 16px rgba(0,168,132,0.4);
      font-family: inherit;
      user-select: none;
      transition: all 0.2s;
      border: 1.5px solid rgba(255,255,255,0.25);
    `;
    btn.onmouseover = () => { btn.style.transform = 'scale(1.05)'; btn.style.boxShadow = '0 6px 18px rgba(0,0,0,0.3)'; };
    btn.onmouseout  = () => { btn.style.transform = 'scale(1)';    btn.style.boxShadow = '0 4px 14px rgba(0,0,0,0.25)'; };
    btn.onclick = () => showGroupDownloadPanel();
    document.body.appendChild(btn);
  }

    /** Show group selection panel and trigger download */
  async function showGroupDownloadPanel() {
    document.getElementById('wnum-group-panel')?.remove();
    showToast('⏳ Groups load ho rahe hain...');
    const groups = await getAllGroupNames();
    if (!groups.length) {
      showToast('⚠️ Koi group nahi mila. WhatsApp Web mein groups hone chahiye.');
      return;
    }

    const panel = document.createElement('div');
    panel.id = 'wnum-group-panel';
    panel.style.cssText = `
      position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);
      background:#fff;border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,0.25);
      z-index:999999;width:340px;max-height:480px;display:flex;flex-direction:column;
      font-family:inherit;overflow:hidden;
    `;

    panel.innerHTML = `
      <div style="background:linear-gradient(135deg,#00a884,#008f72);color:#fff;padding:14px 16px;font-size:14px;font-weight:600;
                  display:flex;justify-content:space-between;align-items:center;border-radius:12px 12px 0 0;">
        <span>📥 Contact Download</span>
        <span id="wnum-gp-close" style="cursor:pointer;font-size:18px;opacity:0.8;transition:opacity 0.15s;" onmouseover="this.style.opacity=1" onmouseout="this.style.opacity=0.8">✕</span>
      </div>
      <!-- Tabs -->
      <div style="display:flex;border-bottom:2px solid #eee;background:#f8f9fa;">
        <button id="wnum-tab-group" style="flex:1;padding:10px;border:none;background:#00a884;color:#fff;font-size:13px;font-weight:600;cursor:pointer;border-radius:0;transition:all 0.2s;">
          👥 Groups
        </button>
        <button id="wnum-tab-label" style="flex:1;padding:10px;border:none;background:transparent;color:#667781;font-size:13px;font-weight:500;cursor:pointer;border-radius:0;transition:all 0.2s;">
          🏷️ Labels
        </button>
        <button id="wnum-tab-all" style="flex:1;padding:10px;border:none;background:transparent;color:#667781;font-size:13px;font-weight:500;cursor:pointer;border-radius:0;transition:all 0.2s;">
          📋 All
        </button>
        <button id="wnum-tab-bulk" style="flex:1;padding:10px;border:none;background:transparent;color:#667781;font-size:13px;font-weight:500;cursor:pointer;border-radius:0;transition:all 0.2s;">
          📲 Bulk
        </button>
        <button id="wnum-tab-remind" style="flex:1;padding:10px;border:none;background:transparent;color:#667781;font-size:13px;font-weight:500;cursor:pointer;border-radius:0;transition:all 0.2s;">
          🔔 Remind
        </button>
      </div>
      <div style="padding:8px 12px;font-size:11px;color:#aaa;border-bottom:1px solid #f0f0f0;" id="wnum-tab-hint">
        Group select karo → CSV download hoga
      </div>
      <div id="wnum-group-list" style="overflow-y:auto;flex:1;padding:8px 0;"></div>
      <div style="padding:10px 12px;border-top:1px solid #eee;display:flex;gap:8px;">
        <button id="wnum-gp-all" style="flex:1;padding:9px;background:linear-gradient(135deg,#00a884,#008f72);color:#fff;
          border:none;border-radius:8px;font-size:13px;cursor:pointer;font-weight:600;box-shadow:0 2px 8px rgba(0,168,132,0.3);">
          📥 Sab Download Karo
        </button>
      </div>
    `;

    const list = panel.querySelector('#wnum-group-list');

    // ── Tab rendering functions ──
    async function renderGroupTab() {
      list.innerHTML = '';
      panel.querySelector('#wnum-tab-hint').textContent = 'Group select karo → CSV download hoga';
      groups.forEach(g => {
        const item = document.createElement('div');
        item.style.cssText = 'padding:10px 14px;cursor:pointer;font-size:13px;border-bottom:1px solid #f5f5f5;display:flex;justify-content:space-between;align-items:center;transition:background 0.15s;';
        item.innerHTML = '<span style="display:flex;align-items:center;gap:8px;"><span style="width:28px;height:28px;background:#e8f5f1;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;">👥</span>' + g.name + '</span><span style="font-size:11px;color:#00a884;font-weight:600;background:#e8f5f1;padding:3px 8px;border-radius:10px;">Download ↓</span>';
        item.onmouseover = () => item.style.background = '#f0faf7';
        item.onmouseout  = () => item.style.background = '';
        item.onclick = () => { panel.remove(); if (g.id) downloadGroupContacts(g.id, g.name); else showToast('⚠️ Group ID nahi mila.'); };
        list.appendChild(item);
      });
    }

    async function renderLabelTab() {
      list.innerHTML = '';
      panel.querySelector('#wnum-tab-hint').textContent = 'Label select karo → us label ke contacts download honge';
      const lbls = await getLabels();
      if (!lbls.length) {
        list.innerHTML = '<div style="padding:20px;text-align:center;color:#aaa;font-size:13px;">Koi label nahi mila.<br>Pehle label banao 🏷️</div>';
        return;
      }
      lbls.forEach(lbl => {
        const ids = Object.entries(_contactLabels).filter(([k,v]) => v.includes(lbl.id)).map(([k]) => k);
        const item = document.createElement('div');
        item.style.cssText = 'padding:10px 14px;cursor:pointer;font-size:13px;border-bottom:1px solid #f5f5f5;display:flex;justify-content:space-between;align-items:center;transition:background 0.15s;';
        item.innerHTML = '<span style="display:flex;align-items:center;gap:8px;"><span style="width:10px;height:10px;border-radius:50%;background:' + lbl.color + ';display:inline-block;"></span>' + (lbl.icon||'🏷️') + ' ' + lbl.name + ' <span style="font-size:10px;color:#aaa;">(' + ids.length + ' contacts)</span></span><span style="font-size:11px;color:#00a884;font-weight:600;background:#e8f5f1;padding:3px 8px;border-radius:10px;">Download ↓</span>';
        item.onmouseover = () => item.style.background = '#f0faf7';
        item.onmouseout  = () => item.style.background = '';
        item.onclick = async () => {
          panel.remove();
          if (!ids.length) { showToast('⚠️ Is label mein koi contact nahi.'); return; }
          showToast('⏳ Contacts load ho rahe hain...');
          // Build name→phone map using bridge (most accurate)
          let nameMap = {};
          try {
            const result = await waRequest('GET_ALL_CONTACTS');
            if (result.contacts && result.contacts.length) {
              result.contacts.forEach(c => {
                // Map every alias (all name variations) → phone
                (c.aliases || [c.name, c.phone]).forEach(alias => {
                  if (alias && alias.trim()) nameMap[alias.trim()] = c;
                });
              });
            }
          } catch(e) {}
          // Fallback: WPP
          if (!Object.keys(nameMap).length) {
            try {
              if (window.WPP && window.WPP.contact && window.WPP.contact.list) {
                const all = await window.WPP.contact.list();
                all.forEach(c => {
                  const ph = c.id ? (c.id.user || '').replace('@c.us','') : '';
                  const obj = { phone: ph, name: c.formattedName||c.name||c.pushname||'', isBusiness: !!c.isBusiness, aliases: [] };
                  [c.formattedName,c.name,c.pushname,c.displayName,ph,'+'+ph].forEach(a => { if(a&&a.trim()) nameMap[a.trim()]=obj; });
                });
              }
            } catch(e) {}
          }
          const headers = ['#','Name','Phone','Business','Label'];
          const rows = ids.map((k,i) => {
            const key = k.trim();
            const info = nameMap[key] || nameMap[key.replace(/^\+/,'')] || {};
            const isPhone = /^\+?\d[\d\s\-]{6,}$/.test(key.replace(/\s/g,''));
            const name = isPhone ? (info.name || '') : key;
            const phone = info.phone || (isPhone ? key.replace(/^\+/,'') : '');
            const biz = info.isBusiness ? 'Yes' : 'No';
            return [i+1, '"' + name.replace(/"/g,'""') + '"', phone, biz, '"' + lbl.name.replace(/"/g,'""') + '"'];
          });
          const csv = [headers.join(','), ...rows.map(r=>r.join(','))].join('\n');
          const blob = new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8;'});
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href=url; a.download='label_' + lbl.name.replace(/[^a-z0-9]/gi,'_') + '_contacts.csv';
          a.click(); URL.revokeObjectURL(url);
          showToast('✅ Label "' + lbl.name + '" ke ' + ids.length + ' contacts download ho gaye!');
        };
        list.appendChild(item);
      });
    }

    async function renderAllTab() {
      list.innerHTML = '<div style="padding:16px;text-align:center;color:#667781;font-size:13px;"><div style="font-size:24px;margin-bottom:8px;">⏳</div>Contacts load ho rahe hain...</div>';
      panel.querySelector('#wnum-tab-hint').textContent = 'WhatsApp Web mein dikhne wale sab contacts';
      let contacts = [];
      try {
        if (window.WPP && window.WPP.contact && window.WPP.contact.list) {
          const all = await window.WPP.contact.list();
          contacts = all.filter(c => {
            const ph = c.id ? (c.id._serialized || '') : '';
            return ph && !ph.includes('broadcast') && !ph.includes('status') && !ph.includes('@g.us');
          }).map((c,i) => ({
            index: i+1,
            name: c.formattedName || c.name || c.pushname || '',
            phone: c.id ? (c.id.user || c.id._serialized || '').replace('@c.us','') : '',
            isBusiness: !!c.isBusiness,
          }));
        }
      } catch(e) {}
      if (!contacts.length) {
        const extracted = extractAllContacts();
        contacts = extracted.map((c,i) => ({ index:i+1, name:c.name||c.phone, phone:c.phone, isBusiness: c.type==='Business' }));
      }
      if (!contacts.length) {
        list.innerHTML = '<div style="padding:16px;text-align:center;color:#aaa;font-size:13px;">Koi contact nahi mila.<br>WhatsApp Web refresh karo 🔄</div>';
        return;
      }
      list.innerHTML = '';
      const summary = document.createElement('div');
      summary.style.cssText = 'padding:12px 14px;font-size:12px;color:#667781;border-bottom:1px solid #f0f0f0;display:flex;justify-content:space-between;align-items:center;';
      summary.innerHTML = '<span>📋 ' + contacts.length + ' contacts ready</span><span style="color:#00a884;font-weight:600;cursor:pointer;background:#e8f5f1;padding:4px 10px;border-radius:10px;" id="wnum-all-dl-btn">Download CSV ↓</span>';
      list.appendChild(summary);
      contacts.slice(0,50).forEach(c => {
        const item = document.createElement('div');
        item.style.cssText = 'padding:8px 14px;font-size:12px;border-bottom:1px solid #f5f5f5;display:flex;justify-content:space-between;color:#3b4a54;';
        item.innerHTML = '<span>' + (c.name||'—') + '</span><span style="color:#667781;">' + (c.phone||'') + (c.isBusiness?' 🏢':'') + '</span>';
        list.appendChild(item);
      });
      if (contacts.length > 50) {
        const more = document.createElement('div');
        more.style.cssText = 'padding:8px 14px;font-size:11px;color:#aaa;text-align:center;';
        more.textContent = '... aur ' + (contacts.length-50) + ' contacts';
        list.appendChild(more);
      }
      const dlBtn = list.querySelector('#wnum-all-dl-btn');
      if (dlBtn) {
        dlBtn.onclick = () => {
          const headers = ['#','Name','Phone','Business'];
          const rows = contacts.map(c => [c.index, '"'+( c.name||'').replace(/"/g,'""')+'"', c.phone, c.isBusiness?'Yes':'No']);
          const csv = [headers.join(','), ...rows.map(r=>r.join(','))].join('\n');
          const blob = new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8;'});
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href=url; a.download='all_contacts_'+Date.now()+'.csv';
          a.click(); URL.revokeObjectURL(url);
          showToast('✅ '+contacts.length+' contacts download ho gaye!');
          panel.remove();
        };
      }
    }

    // Tab switching
    ['group','label','all','bulk','remind'].forEach(tab => {
      const btn = panel.querySelector('#wnum-tab-' + tab);
      if (!btn) return;
      btn.onclick = () => {
        ['group','label','all','bulk','remind'].forEach(t => {
          const b = panel.querySelector('#wnum-tab-' + t);
          if (b) { b.style.background = t===tab ? '#00a884' : 'transparent'; b.style.color = t===tab ? '#fff' : '#667781'; b.style.fontWeight = t===tab ? '600' : '500'; }
        });
        if (tab==='group') renderGroupTab();
        else if (tab==='label') renderLabelTab();
        else if (tab==='all') renderAllTab();
        else if (tab==='bulk') renderBulkTab();
        else if (tab==='remind') renderRemindTab();
      };
    });


    // ─── BULK MESSAGE TAB ────────────────────────────────────────────────
    async function renderBulkTab() {
      panel.querySelector('#wnum-tab-hint').textContent = 'Label/Group select karo → sab ko message bhejo';
      list.innerHTML = '';

      // Load labels + groups + broadcasts
      const labels = await getLabels();
      const customLabels = labels.filter(l => !['all','unread','business','personal'].includes(l.id));
      // Groups load
      const groupsResult = await waRequest('GET_GROUPS').catch(() => ({ groups: [] }));
      const allGroups = groupsResult.groups || [];
      // Broadcasts load
      const bcResult = await waRequest('GET_BROADCAST_LISTS').catch(() => ({ broadcasts: [] }));
      const allBroadcasts = bcResult.broadcasts || [];

      // --- Source selector with category tabs ---
      const sourceDiv = document.createElement('div');
      sourceDiv.style.cssText = 'padding:10px 14px;border-bottom:1px solid #f0f0f0;';
      sourceDiv.innerHTML = `
        <div style="font-size:12px;color:#667781;margin-bottom:6px;font-weight:600;">📌 Contacts source:</div>
        <div style="display:flex;gap:4px;margin-bottom:8px;border-bottom:1px solid #f0f0f0;padding-bottom:8px;" id="wnum-bulk-cats">
          <button data-cat="label" style="padding:4px 10px;border-radius:8px;border:1.5px solid #00a884;background:#00a884;font-size:11px;cursor:pointer;color:#fff;font-weight:600;">🏷️ Labels</button>
          <button data-cat="group" style="padding:4px 10px;border-radius:8px;border:1.5px solid #ddd;background:#fff;font-size:11px;cursor:pointer;color:#3b4a54;">👥 Groups</button>
          <button data-cat="broadcast" style="padding:4px 10px;border-radius:8px;border:1.5px solid #ddd;background:#fff;font-size:11px;cursor:pointer;color:#3b4a54;">📢 Broadcast</button>
          <button data-cat="all" style="padding:4px 10px;border-radius:8px;border:1.5px solid #ddd;background:#fff;font-size:11px;cursor:pointer;color:#3b4a54;">📋 Sab</button>
        </div>
        <div id="wnum-bulk-source" style="display:flex;gap:6px;flex-wrap:wrap;min-height:28px;">
          ${customLabels.length
            ? customLabels.map(l => `<button data-type="label" data-id="${l.id}" data-name="${l.name.replace(/"/g,'&quot;')}"
                style="padding:4px 10px;border-radius:12px;border:1.5px solid #ddd;background:#fff;font-size:11px;cursor:pointer;color:#3b4a54;">
                🏷️ ${l.name}</button>`).join('')
            : '<span style="font-size:11px;color:#aaa;">Koi label nahi mila</span>'
          }
        </div>
        <div id="wnum-bulk-selected-info" style="margin-top:6px;font-size:11px;color:#00a884;"></div>
      `;
      list.appendChild(sourceDiv);

      // --- Message template ---
      const msgDiv = document.createElement('div');
      msgDiv.style.cssText = 'padding:10px 14px;border-bottom:1px solid #f0f0f0;';
      msgDiv.innerHTML = `
        <div style="font-size:12px;color:#667781;margin-bottom:4px;font-weight:600;">✍️ Message Template:</div>
        <div style="font-size:10px;color:#aaa;margin-bottom:4px;">{name} = contact ka naam automatically aa jayega</div>
        <textarea id="wnum-bulk-msg" rows="4" style="width:100%;box-sizing:border-box;padding:8px;border:1.5px solid #ddd;
          border-radius:8px;font-size:12px;resize:vertical;font-family:inherit;outline:none;"
          placeholder="Namaste {name} ji,&#10;Aapka ITR filing due hai...&#10;&#10;Please contact karein."></textarea>
        <div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap;">
          <button id="wnum-bulk-insert-name" style="padding:3px 8px;border-radius:8px;border:1px solid #00a884;background:#e8f5f1;font-size:10px;cursor:pointer;color:#00a884;">{name}</button>
          <button id="wnum-bulk-insert-phone" style="padding:3px 8px;border-radius:8px;border:1px solid #667781;background:#f5f5f5;font-size:10px;cursor:pointer;color:#667781;">{phone}</button>
        </div>
      `;
      list.appendChild(msgDiv);

      // --- Delay & Preview ---
      const ctrlDiv = document.createElement('div');
      ctrlDiv.style.cssText = 'padding:10px 14px;border-bottom:1px solid #f0f0f0;display:flex;gap:8px;align-items:center;';
      ctrlDiv.innerHTML = `
        <div style="flex:1;">
          <div style="font-size:11px;color:#667781;margin-bottom:3px;">⏱️ Delay (seconds):</div>
          <div style="display:flex;gap:4px;align-items:center;">
            <input id="wnum-bulk-delay-min" type="number" value="3" min="1" max="30"
              style="width:45px;padding:4px;border:1px solid #ddd;border-radius:6px;font-size:11px;text-align:center;">
            <span style="font-size:11px;color:#aaa;">–</span>
            <input id="wnum-bulk-delay-max" type="number" value="8" min="2" max="60"
              style="width:45px;padding:4px;border:1px solid #ddd;border-radius:6px;font-size:11px;text-align:center;">
          </div>
        </div>
        <div style="flex:1;">
          <div style="font-size:11px;color:#667781;margin-bottom:3px;">🔢 Max contacts:</div>
          <input id="wnum-bulk-limit" type="number" value="50" min="1" max="500"
            style="width:60px;padding:4px;border:1px solid #ddd;border-radius:6px;font-size:11px;text-align:center;">
        </div>
      `;
      list.appendChild(ctrlDiv);

      // --- Send button ---
      const sendDiv = document.createElement('div');
      sendDiv.style.cssText = 'padding:10px 14px;';
      sendDiv.innerHTML = `
        <div id="wnum-bulk-progress" style="display:none;margin-bottom:8px;">
          <div style="font-size:11px;color:#667781;margin-bottom:4px;" id="wnum-bulk-prog-text">Bhej raha hoon...</div>
          <div style="background:#eee;border-radius:4px;height:6px;">
            <div id="wnum-bulk-prog-bar" style="background:#00a884;height:6px;border-radius:4px;width:0%;transition:width 0.3s;"></div>
          </div>
        </div>
        <button id="wnum-bulk-send-btn" style="width:100%;padding:10px;background:linear-gradient(135deg,#00a884,#008f72);
          color:#fff;border:none;border-radius:8px;font-size:13px;cursor:pointer;font-weight:600;box-shadow:0 2px 8px rgba(0,168,132,0.3);">
          📲 Bulk Message Bhejo
        </button>
        <div id="wnum-bulk-log" style="margin-top:8px;max-height:80px;overflow-y:auto;font-size:10px;color:#667781;"></div>
      `;
      list.appendChild(sendDiv);

      // State
      let selectedContacts = [];
      let isSending = false;

      // Source button click
      // ── Category tab switching ──
      function renderSourceItems(cat) {
        const container = sourceDiv.querySelector('#wnum-bulk-source');
        container.innerHTML = '';
        if (cat === 'label') {
          if (!customLabels.length) {
            container.innerHTML = '<span style="font-size:11px;color:#aaa;">Koi label nahi mila</span>';
            return;
          }
          customLabels.forEach(l => {
            const cnt = Object.entries(_contactLabels).filter(([k,v]) => v.includes(l.id)).length;
            const b = document.createElement('button');
            b.dataset.type = 'label'; b.dataset.id = l.id; b.dataset.name = l.name;
            b.style.cssText = 'padding:4px 10px;border-radius:12px;border:1.5px solid #ddd;background:#fff;font-size:11px;cursor:pointer;color:#3b4a54;';
            b.innerHTML = `🏷️ ${l.name} <span style="color:#aaa">(${cnt})</span>`;
            attachSourceBtn(b); container.appendChild(b);
          });
        } else if (cat === 'group') {
          if (!allGroups.length) {
            container.innerHTML = '<span style="font-size:11px;color:#aaa;">Koi group nahi mila</span>';
            return;
          }
          allGroups.forEach(g => {
            const b = document.createElement('button');
            b.dataset.type = 'group'; b.dataset.id = g.id; b.dataset.name = g.name;
            b.style.cssText = 'padding:4px 10px;border-radius:12px;border:1.5px solid #ddd;background:#fff;font-size:11px;cursor:pointer;color:#3b4a54;';
            b.textContent = '👥 ' + g.name;
            attachSourceBtn(b); container.appendChild(b);
          });
        } else if (cat === 'broadcast') {
          if (!allBroadcasts.length) {
            container.innerHTML = '<div style="font-size:11px;color:#aaa;padding:4px 0;">📢 Koi broadcast list nahi mili.<br><span style="font-size:10px;">WhatsApp mein broadcast list banao phir reload karo.</span></div>';
            return;
          }
          // Reload fresh broadcast data for accurate counts
          waRequest('GET_BROADCAST_LISTS').then(freshBc => {
            const freshList = freshBc.broadcasts || [];
            container.innerHTML = '';
            if (!freshList.length) {
              container.innerHTML = '<div style="font-size:11px;color:#aaa;padding:4px 0;">📢 Koi broadcast list nahi mili.<br><span style="font-size:10px;">WhatsApp mein broadcast list banao phir reload karo.</span></div>';
              return;
            }
            freshList.forEach(bc => {
              const b = document.createElement('button');
              b.dataset.type = 'broadcast'; b.dataset.id = bc.id; b.dataset.name = bc.name;
              b.dataset.count = bc.count;
              b.style.cssText = 'padding:4px 10px;border-radius:12px;border:1.5px solid #ddd;background:#fff;font-size:11px;cursor:pointer;color:#3b4a54;';
              const countColor = bc.count > 0 ? '#00a884' : '#aaa';
              b.innerHTML = `📢 ${bc.name} <span style="color:${countColor};font-weight:${bc.count>0?'600':'400'}">(${bc.count})</span>`;
              attachSourceBtn(b); container.appendChild(b);
            });
          }).catch(() => {});
          // Show loading state first
          allBroadcasts.forEach(bc => {
            const b = document.createElement('button');
            b.dataset.type = 'broadcast'; b.dataset.id = bc.id; b.dataset.name = bc.name;
            b.dataset.count = bc.count;
            b.style.cssText = 'padding:4px 10px;border-radius:12px;border:1.5px solid #ddd;background:#fff;font-size:11px;cursor:pointer;color:#3b4a54;';
            b.innerHTML = `📢 ${bc.name} <span style="color:#aaa">(${bc.count})</span>`;
            attachSourceBtn(b); container.appendChild(b);
          });
        } else if (cat === 'all') {
          const b = document.createElement('button');
          b.dataset.type = 'all'; b.dataset.id = 'all'; b.dataset.name = 'Sab Contacts';
          b.style.cssText = 'padding:4px 10px;border-radius:12px;border:1.5px solid #ddd;background:#fff;font-size:11px;cursor:pointer;color:#3b4a54;';
          b.textContent = '📋 Sab Contacts';
          attachSourceBtn(b); container.appendChild(b);
        }
      }

      function attachSourceBtn(btn) {
        btn.onclick = async () => {
          sourceDiv.querySelector('#wnum-bulk-source').querySelectorAll('button').forEach(b => {
            b.style.background = '#fff'; b.style.borderColor = '#ddd'; b.style.color = '#3b4a54';
          });
          btn.style.background = '#00a884'; btn.style.borderColor = '#00a884'; btn.style.color = '#fff';
          const infoEl = sourceDiv.querySelector('#wnum-bulk-selected-info');
          infoEl.textContent = '⏳ Contacts load ho rahe hain...';
          selectedContacts = [];
          try {
            const type = btn.dataset.type;
            if (type === 'all') {
              const result = await waRequest('GET_ALL_CONTACTS');
              selectedContacts = (result.contacts || []).filter(c => c.phone);
            } else if (type === 'label') {
              const labelId = btn.dataset.id;
              const ids = Object.entries(_contactLabels)
                .filter(([k,v]) => v.includes(labelId)).map(([k]) => k);
              if (ids.length) {
                const result = await waRequest('GET_ALL_CONTACTS');
                const allMap = {};
                (result.contacts || []).forEach(c => {
                  (c.aliases || [c.name, c.phone]).forEach(a => { if(a) allMap[a.trim()] = c; });
                });
                selectedContacts = ids.map(k => allMap[k.trim()] || { name: k, phone: '', isBusiness: false }).filter(c => c.phone || c.name);
              }
            } else if (type === 'group') {
              const result = await waRequest('GET_GROUP_CONTACTS', { groupId: btn.dataset.id });
              selectedContacts = (result.contacts || []).filter(c => c.phone);
            } else if (type === 'broadcast') {
              // Broadcast: reload fresh to get latest recipients
              const freshBc = await waRequest('GET_BROADCAST_LISTS');
              const freshList = (freshBc.broadcasts || []);
              const bc = freshList.find(b => b.id === btn.dataset.id);
              if (bc && bc.recipients && bc.recipients.length) {
                selectedContacts = bc.recipients.filter(c => c.phone);
              } else {
                // Fallback: GET_GROUP_CONTACTS try karo
                const result = await waRequest('GET_GROUP_CONTACTS', { groupId: btn.dataset.id });
                selectedContacts = (result.contacts || []).filter(c => c.phone);
              }
            }
          } catch(e) { selectedContacts = []; }
          infoEl.textContent = selectedContacts.length
            ? `✅ ${selectedContacts.length} contacts selected`
            : '⚠️ Koi contact nahi mila';
        };
      }

      // Category tab click
      sourceDiv.querySelector('#wnum-bulk-cats').querySelectorAll('button[data-cat]').forEach(catBtn => {
        catBtn.onclick = () => {
          sourceDiv.querySelector('#wnum-bulk-cats').querySelectorAll('button').forEach(b => {
            b.style.background = '#fff'; b.style.borderColor = '#ddd'; b.style.color = '#3b4a54'; b.style.fontWeight = '400';
          });
          catBtn.style.background = '#00a884'; catBtn.style.borderColor = '#00a884'; catBtn.style.color = '#fff'; catBtn.style.fontWeight = '600';
          renderSourceItems(catBtn.dataset.cat);
          selectedContacts = [];
          sourceDiv.querySelector('#wnum-bulk-selected-info').textContent = '';
        };
      });

      renderSourceItems('label'); // default

      // Insert variable buttons
      msgDiv.querySelector('#wnum-bulk-insert-name').onclick = () => {
        const ta = msgDiv.querySelector('#wnum-bulk-msg');
        const pos = ta.selectionStart;
        ta.value = ta.value.slice(0,pos) + '{name}' + ta.value.slice(pos);
        ta.focus(); ta.setSelectionRange(pos+6, pos+6);
      };
      msgDiv.querySelector('#wnum-bulk-insert-phone').onclick = () => {
        const ta = msgDiv.querySelector('#wnum-bulk-msg');
        const pos = ta.selectionStart;
        ta.value = ta.value.slice(0,pos) + '{phone}' + ta.value.slice(pos);
        ta.focus(); ta.setSelectionRange(pos+7, pos+7);
      };

      // Send button
      sendDiv.querySelector('#wnum-bulk-send-btn').onclick = async () => {
        if (isSending) return;
        const msg = msgDiv.querySelector('#wnum-bulk-msg').value.trim();
        if (!msg) { showToast('⚠️ Message likho pehle!'); return; }
        if (!selectedContacts.length) { showToast('⚠️ Pehle source select karo!'); return; }
        const minD = parseInt(ctrlDiv.querySelector('#wnum-bulk-delay-min').value) || 3;
        const maxD = parseInt(ctrlDiv.querySelector('#wnum-bulk-delay-max').value) || 8;
        const limit = parseInt(ctrlDiv.querySelector('#wnum-bulk-limit').value) || 50;
        const targets = selectedContacts.filter(c => c.phone).slice(0, limit);
        if (!targets.length) { showToast('⚠️ Phone number wale contacts nahi hain!'); return; }

        const confirmed = confirm(`📲 ${targets.length} contacts ko message bhejoge?

Message preview:
${msg.slice(0,100)}${msg.length>100?'...':''}

Delay: ${minD}-${maxD} sec

OK = Start, Cancel = Roko`);
        if (!confirmed) return;

        isSending = true;
        const progDiv = sendDiv.querySelector('#wnum-bulk-progress');
        const progText = sendDiv.querySelector('#wnum-bulk-prog-text');
        const progBar = sendDiv.querySelector('#wnum-bulk-prog-bar');
        const logEl = sendDiv.querySelector('#wnum-bulk-log');
        const sendBtn = sendDiv.querySelector('#wnum-bulk-send-btn');
        progDiv.style.display = 'block';
        sendBtn.textContent = '⏳ Bhej raha hoon... (Band karne ke liye reload karo)';
        sendBtn.style.opacity = '0.7';
        let sent = 0, failed = 0;

        for (let i = 0; i < targets.length; i++) {
          const c = targets[i];
          const finalMsg = msg.replace(/\{name\}/gi, c.name||'').replace(/\{phone\}/gi, c.phone||'');
          progText.textContent = `${i+1}/${targets.length} — ${c.name||c.phone} ko bhej raha hoon...`;
          progBar.style.width = ((i+1)/targets.length*100) + '%';
          try {
            const res = await chrome.runtime.sendMessage({ type: 'WPP_SEND_TEXT', number: c.phone, message: finalMsg });
            if (res && res.success) {
              sent++;
              logEl.innerHTML = `<div style="color:#00a884;">✅ ${c.name||c.phone}</div>` + logEl.innerHTML;
            } else {
              failed++;
              logEl.innerHTML = `<div style="color:#e74c3c;">❌ ${c.name||c.phone}: ${res?.reason||'failed'}</div>` + logEl.innerHTML;
            }
          } catch(e) {
            failed++;
            logEl.innerHTML = `<div style="color:#e74c3c;">❌ ${c.name||c.phone}: Error</div>` + logEl.innerHTML;
          }
          // Random delay
          const delay = (minD + Math.random()*(maxD-minD))*1000;
          await new Promise(r => setTimeout(r, delay));
        }
        isSending = false;
        progText.textContent = `✅ Done! Bheja: ${sent} | Failed: ${failed}`;
        sendBtn.textContent = '📲 Bulk Message Bhejo';
        sendBtn.style.opacity = '1';
        showToast(`✅ ${sent} messages bhej diye! ${failed} failed.`);
      };
    }

    // ─── REMINDER TAB ─────────────────────────────────────────────────────
    async function renderRemindTab() {
      panel.querySelector('#wnum-tab-hint').textContent = 'Due date set karo — Chrome notification aayegi';
      list.innerHTML = '';
      const REMIND_KEY = 'wnum_reminders';

      async function loadReminders() {
        const res = await chrome.storage.local.get(REMIND_KEY);
        return res[REMIND_KEY] || [];
      }
      async function saveReminders(arr) {
        await chrome.storage.local.set({ [REMIND_KEY]: arr });
      }

      // Add reminder form
      const formDiv = document.createElement('div');
      formDiv.style.cssText = 'padding:10px 14px;border-bottom:1px solid #f0f0f0;';
      formDiv.innerHTML = `
        <div style="font-size:12px;color:#667781;font-weight:600;margin-bottom:8px;">➕ Naya Reminder</div>
        <input id="wnum-rem-name" type="text" placeholder="Client ka naam (e.g. Pankaj Vekariya)"
          style="width:100%;box-sizing:border-box;padding:7px 10px;border:1.5px solid #ddd;border-radius:8px;font-size:12px;margin-bottom:6px;outline:none;">
        <input id="wnum-rem-phone" type="text" placeholder="Phone number (optional — direct message ke liye)"
          style="width:100%;box-sizing:border-box;padding:7px 10px;border:1.5px solid #ddd;border-radius:8px;font-size:12px;margin-bottom:6px;outline:none;">
        <input id="wnum-rem-note" type="text" placeholder="Note (e.g. ITR 2024-25 filing, PAN: ABCDE1234F)"
          style="width:100%;box-sizing:border-box;padding:7px 10px;border:1.5px solid #ddd;border-radius:8px;font-size:12px;margin-bottom:6px;outline:none;">
        <div style="display:flex;gap:8px;align-items:flex-end;">
          <div style="flex:1;">
            <div style="font-size:10px;color:#aaa;margin-bottom:3px;">Due Date:</div>
            <input id="wnum-rem-date" type="date"
              style="width:100%;box-sizing:border-box;padding:7px 8px;border:1.5px solid #ddd;border-radius:8px;font-size:12px;outline:none;">
          </div>
          <div style="flex:1;">
            <div style="font-size:10px;color:#aaa;margin-bottom:3px;">Alert (days before):</div>
            <select id="wnum-rem-days" style="width:100%;padding:7px 6px;border:1.5px solid #ddd;border-radius:8px;font-size:12px;outline:none;">
              <option value="1">1 din pehle</option>
              <option value="3" selected>3 din pehle</option>
              <option value="7">7 din pehle</option>
              <option value="15">15 din pehle</option>
              <option value="0">Due date pe</option>
            </select>
          </div>
        </div>
        <button id="wnum-rem-add-btn" style="width:100%;margin-top:8px;padding:9px;background:linear-gradient(135deg,#00a884,#008f72);
          color:#fff;border:none;border-radius:8px;font-size:12px;cursor:pointer;font-weight:600;">
          🔔 Reminder Add Karo
        </button>
      `;
      list.appendChild(formDiv);

      // Reminders list
      const listDiv = document.createElement('div');
      listDiv.id = 'wnum-rem-list';
      listDiv.style.cssText = 'padding:0;';
      list.appendChild(listDiv);

      async function refreshReminderList() {
        const reminders = await loadReminders();
        listDiv.innerHTML = '';
        if (!reminders.length) {
          listDiv.innerHTML = '<div style="padding:16px;text-align:center;color:#aaa;font-size:12px;">Koi reminder nahi hai<br><span style="font-size:20px;">🔔</span></div>';
          return;
        }
        const today = new Date(); today.setHours(0,0,0,0);
        reminders.sort((a,b) => new Date(a.dueDate) - new Date(b.dueDate)).forEach((r,i) => {
          const due = new Date(r.dueDate); due.setHours(0,0,0,0);
          const diff = Math.round((due-today)/(1000*60*60*24));
          let statusColor = '#667781', statusText = `${diff} din baaki`;
          if (diff < 0) { statusColor = '#e74c3c'; statusText = `${Math.abs(diff)} din overdue!`; }
          else if (diff === 0) { statusColor = '#e67e22'; statusText = 'Aaj due hai!'; }
          else if (diff <= r.alertDays) { statusColor = '#e67e22'; statusText = `⚠️ ${diff} din baaki`; }

          const item = document.createElement('div');
          item.style.cssText = 'padding:10px 14px;border-bottom:1px solid #f5f5f5;display:flex;justify-content:space-between;align-items:center;';
          item.innerHTML = `
            <div style="flex:1;min-width:0;">
              <div style="font-size:12px;font-weight:600;color:#3b4a54;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${r.name}</div>
              <div style="font-size:10px;color:#667781;margin-top:1px;">${r.note||''}</div>
              <div style="font-size:10px;margin-top:2px;">
                <span style="color:${statusColor};font-weight:600;">${statusText}</span>
                <span style="color:#aaa;margin-left:6px;">📅 ${new Date(r.dueDate).toLocaleDateString('en-IN')}</span>
              </div>
            </div>
            <div style="display:flex;gap:4px;margin-left:8px;">
              ${r.phone ? `<button data-action="msg" data-idx="${i}" title="Message bhejo"
                style="padding:4px 7px;border-radius:6px;border:none;background:#e8f5f1;color:#00a884;font-size:11px;cursor:pointer;">💬</button>` : ''}
              <button data-action="del" data-idx="${i}" title="Delete"
                style="padding:4px 7px;border-radius:6px;border:none;background:#fdecea;color:#e74c3c;font-size:11px;cursor:pointer;">🗑️</button>
            </div>
          `;
          listDiv.appendChild(item);
        });

        // Button handlers
        listDiv.querySelectorAll('button[data-action]').forEach(btn => {
          btn.onclick = async () => {
            const rems = await loadReminders();
            const idx = parseInt(btn.dataset.idx);
            if (btn.dataset.action === 'del') {
              rems.splice(idx,1);
              await saveReminders(rems);
              refreshReminderList();
              showToast('🗑️ Reminder delete ho gaya!');
            } else if (btn.dataset.action === 'msg') {
              const r = rems[idx];
              if (!r.phone) return;
              const msgText = `Namaste ${r.name} ji,
${r.note ? r.note + "\n" : ''}📅 Due date: ${new Date(r.dueDate).toLocaleDateString('en-IN')}

Please contact karein.`;
              try {
                await chrome.runtime.sendMessage({ type:'WPP_SEND_TEXT', number: r.phone, message: msgText });
                showToast(`✅ ${r.name} ko reminder message bheja!`);
              } catch(e) { showToast('❌ Message send nahi hua.'); }
            }
          };
        });
      }

      // Add reminder button
      formDiv.querySelector('#wnum-rem-add-btn').onclick = async () => {
        const name = formDiv.querySelector('#wnum-rem-name').value.trim();
        const phone = formDiv.querySelector('#wnum-rem-phone').value.trim().replace(/\D/g,'');
        const note = formDiv.querySelector('#wnum-rem-note').value.trim();
        const dueDate = formDiv.querySelector('#wnum-rem-date').value;
        const alertDays = parseInt(formDiv.querySelector('#wnum-rem-days').value);
        if (!name) { showToast('⚠️ Naam likhna zaroori hai!'); return; }
        if (!dueDate) { showToast('⚠️ Due date select karo!'); return; }
        const rems = await loadReminders();
        rems.push({ id: Date.now().toString(36), name, phone, note, dueDate, alertDays, createdAt: new Date().toISOString() });
        await saveReminders(rems);
        // Schedule check alarm
        await chrome.runtime.sendMessage({ type:'SETUP_REMINDER_ALARM' }).catch(()=>{});
        formDiv.querySelector('#wnum-rem-name').value = '';
        formDiv.querySelector('#wnum-rem-phone').value = '';
        formDiv.querySelector('#wnum-rem-note').value = '';
        formDiv.querySelector('#wnum-rem-date').value = '';
        showToast('✅ Reminder save ho gaya!');
        refreshReminderList();
      };

      refreshReminderList();
    }

    renderGroupTab(); // Default tab

    document.body.appendChild(panel);
    panel.querySelector('#wnum-gp-close').onclick = () => panel.remove();
    panel.querySelector('#wnum-gp-all').onclick = async () => {
      // Check which tab is active
      const groupTabActive = panel.querySelector('#wnum-tab-group')?.style.background === '#00a884' || panel.querySelector('#wnum-tab-group')?.style.background.includes('00a884');
      const labelTabActive = panel.querySelector('#wnum-tab-label')?.style.background?.includes('00a884');
      const allTabActive = panel.querySelector('#wnum-tab-all')?.style.background?.includes('00a884');
      if (labelTabActive) {
        // Download all labeled contacts
        panel.remove();
        const allLabeled = {};
        Object.entries(_contactLabels).forEach(([k,v]) => { if(v.length) allLabeled[k] = v; });
        const entries = Object.entries(allLabeled);
        if (!entries.length) { showToast('⚠️ Koi labeled contact nahi mila.'); return; }
        const lbls = await getLabels();
        const headers = ['#','Contact','Labels'];
        const rows = entries.map(([k,ids],i) => {
          const names = ids.map(id => { const l = lbls.find(x=>x.id===id); return l ? l.name : id; }).join(';');
          return [i+1, '"' + k.replace(/"/g,'""') + '"', '"' + names + '"'];
        });
        const csv = [headers.join(','), ...rows.map(r=>r.join(','))].join('\n');
        const blob = new Blob(['﻿'+csv],{type:'text/csv;charset=utf-8;'});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href=url; a.download='all_labeled_contacts_' + Date.now() + '.csv';
        a.click(); URL.revokeObjectURL(url);
        showToast('✅ ' + entries.length + ' labeled contacts download ho gaye!');
        return;
      }
      if (allTabActive) {
        // All tab mein already download button hai - wahan se download karo
        const dlBtn = panel.querySelector('#wnum-all-dl-btn');
        if (dlBtn) { dlBtn.click(); return; }
        panel.remove();
        downloadContacts();
        return;
      }
      panel.remove();
      showToast(`⏳ ${groups.length} groups ke contacts download ho rahe hain...`);
      const allContacts = [];
      let done = 0;
      for (const g of groups) {
        if (!g.id) continue;
        const result = await waRequest("GET_GROUP_CONTACTS", { groupId: g.id });
        if (result.contacts && result.contacts.length) {
          result.contacts.forEach(c => {
            allContacts.push({ ...c, index: allContacts.length + 1, group: g.name });
          });
          done++;
        }
      }
      if (!allContacts.length) { showToast('⚠️ Koi contact nahi mila.'); return; }
      const headers = ['#','Name','Phone','Business','Group'];
      const rows = allContacts.map(c => [c.index,
        `"${(c.name||'').replace(/"/g,'""')}"`, c.phone,
        c.isBusiness?'Yes':'No', `"${(c.group||'').replace(/"/g,'""')}"`]);
      const csv = [headers.join(','), ...rows.map(r=>r.join(','))].join('\n');
      const blob = new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8;'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href=url; a.download=`all_groups_contacts_${Date.now()}.csv`;
      a.click(); URL.revokeObjectURL(url);
      showToast(`✅ ${allContacts.length} contacts (${done} groups) download ho gaye!`);
    };
  }

    function extractAllContacts() {
    const pane = document.querySelector("#pane-side,[data-testid='chat-list']");
    if (!pane) return [];
    const contacts = []; const seen = new Set();
    const rows = pane.querySelectorAll(
      '[data-testid="cell-frame-container"],[role="row"]'
    );
    rows.forEach(row => {
      const titleEl =
        row.querySelector('[data-testid="cell-frame-title"] span') ||
        row.querySelector('[data-testid="cell-frame-title"]')       ||
        row.querySelector('span[title]')                            ||
        row.querySelector('span[dir="auto"] > span');
      if (!titleEl) return;
      const name = titleEl.textContent.trim();
      if (!name || seen.has(name)) return;
      seen.add(name);

      const isBiz =
        !!row.querySelector('[data-testid="business-chat-indicator"]') ||
        !!row.querySelector('[data-icon="verified-business"]')         ||
        !!row.querySelector('[data-icon="business-chat"]');
      const hasUnread = !!row.querySelector('[data-testid="icon-unread-count"]');
      const badge = row.querySelector('[data-testid="icon-unread-count"]');
      const unread = badge ? badge.textContent.trim() : "0";
      const isPhone = isPhoneNumber(name.replace(/\s/g, ""));
      const lastMsg = getLastMessage(row);

      contacts.push({
        name:    isPhone ? "" : name,
        phone:   isPhone ? normalizeNumber(name) : "",
        type:    isBiz   ? "Business" : "Individual",
        lastMsg: lastMsg,
        unread:  unread,
        time:    new Date().toISOString(),
      });
    });
    return contacts;
  }

  async function downloadContacts() {
    showToast("⏳ Saare contacts fetch ho rahe hain...");
    let contacts = [];

    // Method 1: WPP.contact.list() — saare contacts (virtual scroll bypass)
    try {
      if (window.WPP && window.WPP.contact && window.WPP.contact.list) {
        const wppContacts = await window.WPP.contact.list();
        if (wppContacts && wppContacts.length > 0) {
          contacts = wppContacts.map(c => ({
            name:    c.formattedName || c.name || c.pushname || "",
            phone:   c.id ? (c.id._serialized || c.id.user || "") : "",
            type:    c.isBusiness ? "Business" : "Individual",
            lastMsg: "",
            unread:  "0",
            time:    new Date().toISOString(),
          })).filter(c => c.phone && !c.phone.includes("broadcast") && !c.phone.includes("status"));
        }
      }
    } catch(e) { console.warn("[WA Manager] WPP contact.list failed:", e); }

    // Method 2: window.Store.Contact.getModelsArray() — direct store access
    if (!contacts.length) {
      try {
        const store = window.Store || window.WPP?.whatsapp;
        const contactStore = store?.ContactStore || store?.ContactCollection;
        if (contactStore && contactStore.getModelsArray) {
          const models = contactStore.getModelsArray();
          contacts = models.map(c => ({
            name:    c.formattedName || c.name || c.pushname || "",
            phone:   c.id ? (c.id._serialized || c.id.user || c.id || "") : "",
            type:    c.isBusiness ? "Business" : "Individual",
            lastMsg: "",
            unread:  "0",
            time:    new Date().toISOString(),
          })).filter(c => c.phone && !String(c.phone).includes("broadcast") && !String(c.phone).includes("status"));
        }
      } catch(e) { console.warn("[WA Manager] Store.ContactStore failed:", e); }
    }

    // Method 3: DOM scan fallback (limited to visible chats)
    if (!contacts.length) {
      contacts = extractAllContacts();
    }

    if (!contacts.length) {
      showToast("⚠️ Koi contact nahi mila. WhatsApp Web reload karein.");
      return;
    }

    const headers = ["Name","Phone","Type","Scanned At"];
    const rows = contacts.map(c => [
      `"${(c.name||"").replace(/"/g,'""')}"`,
      `"${(c.phone||"").replace(/"/g,'""')}"`,
      c.type,
      c.time,
    ]);
    const csv = [headers.join(","), ...rows.map(r=>r.join(","))].join("\n");
    const blob = new Blob(["\uFEFF"+csv], { type:"text/csv;charset=utf-8;" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href = url; a.download = `wa_contacts_${Date.now()}.csv`;
    a.click(); URL.revokeObjectURL(url);
    showToast(`✅ ${contacts.length} contacts ka CSV download hua!`);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // ORIGINAL: scanChatList + sendMessage + observer (unchanged)
  // ══════════════════════════════════════════════════════════════════════════

  function extractNumberFromTitle(titleEl) {
    if (!titleEl) return null;
    const text = titleEl.textContent.trim();
    if (isPhoneNumber(text)) return normalizeNumber(text);
    return null;
  }

  function getLastMessage(chatRow) {
    const selectors = [
      '[data-testid="last-msg-status"] ~ span span',
      '.copyable-text span span',
      '[data-testid="conversation-panel-body"] span span',
      'span[dir="ltr"] > span',
      'span[dir="auto"]'
    ];
    for (const sel of selectors) {
      const el = chatRow.querySelector(sel);
      if (el && el.textContent.trim()) return el.textContent.trim().slice(0,120);
    }
    return "";
  }

  function scanChatList() {
    const chatList =
      document.querySelector('[data-testid="chat-list"]') ||
      document.querySelector('#pane-side [role="grid"]')  ||
      document.querySelector('#pane-side');
    if (!chatList) return;

    chatList.querySelectorAll('[role="row"],[data-testid="cell-frame-container"]')
      .forEach(row => {
        const titleEl =
          row.querySelector('[data-testid="cell-frame-title"] span') ||
          row.querySelector('[data-testid="cell-frame-title"]')      ||
          row.querySelector('span[dir="auto"] > span')               ||
          row.querySelector('span[title]');
        if (!titleEl) return;
        const number = extractNumberFromTitle(titleEl);
        if (!number || knownNumbers.has(number)) return;
        knownNumbers.add(number);

        const payload = {
          number,
          lastMessage: getLastMessage(row),
          dateTime:    new Date().toISOString(),
          status:      "New", tags:"", notes:"",
          country:     detectCountryCode(number),
          isIndian:    isIndianNumber(number),
          blacklisted: false,
        };
        chrome.runtime.sendMessage({ type:"NEW_UNSAVED_NUMBER", data:payload });
        showFloatingBadge(number);
      });
  }

  function showFloatingBadge(number) {
    const badge = document.createElement("div");
    badge.className = "wnum-badge";
    badge.innerHTML = `<span>📱</span><span>New unsaved: <b>${number}</b></span>`;
    document.body.appendChild(badge);
    setTimeout(() => badge.classList.add("wnum-badge--show"), 50);
    setTimeout(() => {
      badge.classList.remove("wnum-badge--show");
      setTimeout(() => badge.remove(), 400);
    }, 3500);
  }

  /* ─────────────────────────────────────────────────────────────────────
     FULL SCAN — poori chat list scroll karke saare unsaved numbers capture
     ───────────────────────────────────────────────────────────────────── */
  async function fullScanAllChats(sendResponse) {
    // 1. Find the scrollable chat list container
    const scrollEl =
      document.querySelector('#pane-side [data-testid="chat-list"]')?.parentElement ||
      document.querySelector('#pane-side [role="grid"]')?.parentElement ||
      document.querySelector('#pane-side .copyable-area')  ||
      document.querySelector('#pane-side');

    const chatPane =
      document.querySelector('[data-testid="chat-list"]') ||
      document.querySelector('#pane-side [role="grid"]')  ||
      document.querySelector('#pane-side');

    if (!scrollEl && !chatPane) {
      sendResponse({ ok: false, reason: "Chat list nahi mili. WhatsApp Web kholein." });
      return;
    }

    const container = scrollEl || chatPane;

    // 2. Scroll to top first
    container.scrollTop = 0;
    await sleep(600);

    const STEP       = 300;   // px per scroll step
    const STEP_DELAY = 350;   // ms between steps (DOM render time)
    const MAX_SAME   = 6;     // stop if scroll pos doesn't change X times

    let lastTop     = -1;
    let sameCount   = 0;
    let stepsDone   = 0;
    let foundBefore = 0;

    // Count how many we already have
    const { numbers: existingNums } = await new Promise(r =>
      chrome.runtime.sendMessage({ type: "GET_ALL_NUMBERS" }, res => r(res || {}))
    );
    foundBefore = (existingNums || []).length;

    // Show on-page toast
    showToastFull("🔍 Full Scan shuru... scroll ho rahi hai");

    // 3. Scroll loop
    while (sameCount < MAX_SAME) {
      // Scan current visible rows
      scanChatList();

      // Report progress
      const curTop = container.scrollTop;
      const total  = container.scrollHeight;
      const pct    = total > 0 ? Math.min(100, Math.round((curTop / total) * 100)) : 0;
      chrome.runtime.sendMessage({
        type: "FULL_SCAN_PROGRESS",
        percent: pct,
        scrolled: curTop,
        total:    total,
      });

      // Scroll down
      container.scrollTop += STEP;
      await sleep(STEP_DELAY);
      stepsDone++;

      // Check if we've stopped moving
      const newTop = container.scrollTop;
      if (newTop === lastTop) {
        sameCount++;
      } else {
        sameCount = 0;
        lastTop   = newTop;
      }
    }

    // 4. Final scan at bottom
    scanChatList();
    await sleep(500);

    // 5. Scroll back to top
    container.scrollTop = 0;

    // 6. Compute result
    const { numbers: newNums } = await new Promise(r =>
      chrome.runtime.sendMessage({ type: "GET_ALL_NUMBERS" }, res => r(res || {}))
    );
    const totalFound = (newNums || []).length;
    const newlyAdded = totalFound - foundBefore;

    showToastFull(`✅ Scan complete! ${newlyAdded} naye unsaved numbers mile (Total: ${totalFound})`);

    sendResponse({
      ok:         true,
      total:      totalFound,
      newlyAdded: newlyAdded,
      steps:      stepsDone,
    });
  }

  /* small in-page toast for full scan feedback */
  function showToastFull(text) {
    let t = document.getElementById("wnum-full-scan-toast");
    if (!t) {
      t = document.createElement("div");
      t.id = "wnum-full-scan-toast";
      t.style.cssText = [
        "position:fixed","bottom:80px","left:50%","transform:translateX(-50%)",
        "background:#1f2937","color:#f9fafb","font-size:13px","font-weight:600",
        "padding:10px 20px","border-radius:24px","z-index:999999",
        "box-shadow:0 4px 20px rgba(0,0,0,.4)","pointer-events:none",
        "transition:opacity .3s","max-width:380px","text-align:center",
      ].join(";");
      document.body.appendChild(t);
    }
    t.textContent = text;
    t.style.opacity = "1";
    clearTimeout(t._timer);
    t._timer = setTimeout(() => { t.style.opacity = "0"; }, 4000);
  }

  async function loadKnownNumbers() {
    return new Promise(resolve => {
      chrome.runtime.sendMessage({ type:"GET_ALL_NUMBERS" }, res => {
        if (res && res.numbers) res.numbers.forEach(n => knownNumbers.add(n.number));
        resolve();
      });
    });
  }

  async function sendMessageNoReload(number, message, retryCount = 0) {
    const clean = normalizeNumber(number.toString());

    // ── Method 1: WPP.chat.sendTextMessage (MAIN world via background.js) ──
    try {
      const wppResult = await new Promise((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("WPP_SEND_TEXT timeout")), 12000);
        chrome.runtime.sendMessage({
          type:    "WPP_SEND_TEXT",
          number:  clean,
          message: message,
        }, (response) => {
          clearTimeout(timer);
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else resolve(response);
        });
      });
      if (wppResult && wppResult.success) {
        console.log("[WA Manager] Text sent via WPP:", wppResult);
        return { success: true, number, method: "WPP_TEXT" };
      }
      console.warn("[WA Manager] WPP_SEND_TEXT failed, DOM fallback:", wppResult?.reason);
    } catch (e) {
      console.warn("[WA Manager] WPP_SEND_TEXT error, DOM fallback:", e.message);
    }

    // ── Method 2: wa.me URL fallback (DOM inject) ──
    let anchor = document.getElementById("wamessager-rar");
    if (!anchor) {
      anchor = document.createElement("a"); anchor.id = "wamessager-rar";
      document.body.appendChild(anchor);
    }
    anchor.setAttribute("href",
      `https://wa.me/${clean}?text=${encodeURIComponent(message.replace(/ /gm,"\u00a0"))}`
    );
    anchor.click();
    const sendBtn = await waitForSendBtn(8000);
    if (sendBtn === "NOT_ON_WA") {
      return { success: false, not_on_wa: true, reason: "Number WhatsApp par registered nahi hai" };
    }
    if (!sendBtn) {
      if (retryCount >= 2) throw new Error("Send button nahi mila");
      await sleep(4000);
      return sendMessageNoReload(number, message, retryCount+1);
    }
    await sleep(2000 + Math.floor(Math.random()*1500));
    await clickSendBtn(sendBtn);
    await sleep(1500);
    return { success:true, number };
  }

  function checkNotOnWhatsAppPopup() {
    // Detect WhatsApp popup: "The number isn't on WhatsApp."
    const selectors = [
      '[role="dialog"]',
      '[data-testid="popup-contents"]',
      '.x1n2onr6 div',
      'div[class*="popup"]',
    ];
    for (const sel of selectors) {
      const els = document.querySelectorAll(sel);
      for (const el of els) {
        const txt = (el.textContent || "").toLowerCase();
        if (
          txt.includes("isn't on whatsapp") ||
          txt.includes("is not on whatsapp") ||
          txt.includes("isn\u2019t on whatsapp") ||
          txt.includes("not registered on whatsapp")
        ) {
          // Auto-dismiss the popup
          const okBtn = el.querySelector("button") ||
            document.querySelector('[data-testid="popup-contents"] button');
          if (okBtn) { try { okBtn.click(); } catch(e){} }
          return true;
        }
      }
    }
    // Broad fallback scan
    const allBtns = Array.from(document.querySelectorAll("button"));
    const bodyTxt = (document.body ? document.body.innerText || "" : "").toLowerCase();
    if (bodyTxt.includes("isn't on whatsapp") || bodyTxt.includes("isn\u2019t on whatsapp")) {
      for (const btn of allBtns) {
        const t = (btn.textContent || "").trim().toLowerCase();
        if (t === "ok" || t === "okay") {
          try { btn.click(); } catch(e) {}
          break;
        }
      }
      // Also try to close attachment preview if visible
      setTimeout(() => closeAttachmentPreviewIfOpen(), 500);
      return true;
    }
    return false;
  }

  // Close attachment/image preview screen if it's open (appears when number not on WA during file send)
  function closeAttachmentPreviewIfOpen() {
    // The preview screen has a close button (X) with data-testid="media-editor-close" or similar
    const closeSelectors = [
      '[data-testid="media-editor-close"]',
      'button[aria-label="Close"]',
      'span[data-icon="x-viewer"]',
      '[data-icon="x"]',
    ];
    for (const sel of closeSelectors) {
      const btn = document.querySelector(sel);
      if (btn) {
        // Only click if we're on a preview screen (look for preview indicators)
        const hasPreview =
          document.querySelector('[data-testid="media-editor-canvas"]') ||
          document.querySelector('[data-testid="media-upload-preview"]') ||
          document.querySelector('.x1c4vz4f canvas') ||
          document.querySelector('img[data-testid]');
        if (hasPreview) {
          try { btn.click(); } catch(e) {}
          return true;
        }
      }
    }
    return false;
  }

  async function waitForSendBtn(timeoutMs) {
    const start = Date.now();
    while (Date.now()-start < timeoutMs) {
      // Check "not on WhatsApp" popup BEFORE checking send button
      if (checkNotOnWhatsAppPopup()) return "NOT_ON_WA";
      const btn =
        document.querySelector("span[data-icon='send']") ||
        document.querySelector("button[aria-label='Send']") ||
        document.querySelector("[data-testid='send']");
      if (btn) return btn;
      await new Promise(r => setTimeout(r,300));
    }
    if (checkNotOnWhatsAppPopup()) return "NOT_ON_WA";
    return null;
  }

  async function clickSendBtn(element) {
    if (!element) return;
    try { element.click(); } catch(e){}
    await new Promise(r => setTimeout(r,200));
    try {
      const ev = document.createEvent("MouseEvents");
      ev.initEvent("mouseover",true,true); element.dispatchEvent(ev);
      ev.initEvent("mousedown",true,true); element.dispatchEvent(ev);
      ev.initEvent("mouseup",  true,true); element.dispatchEvent(ev);
      ev.initEvent("click",    true,true); element.dispatchEvent(ev);
    } catch(e){}
  }

  // ─── Attachment / File Sending ────────────────────────────────────────────
  async function sendFileAttachment(number, options = {}) {
    const clean    = normalizeNumber(number.toString());
    const caption  = options.caption  || "";
    const filename = options.filename || "file";
    const fileType = options.type     || "auto-detect";
    const mime     = options.fileMime || "application/octet-stream";

    if (!options.fileBase64) {
      return { success: false, reason: "No file data received" };
    }

    // --- Method 1: WPP via background.js (SheetWA wppconnect method) ---
    // content.js ISOLATED world mein run hota hai isliye window.WPP seedha
    // access nahi hota. Background.js chrome.scripting.executeScript se
    // MAIN world mein WPP.chat.sendFileMessage call karta hai.
    try {
      const wppResult = await new Promise((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("WPP timeout")), 12000);
        chrome.runtime.sendMessage({
          type:       "WPP_SEND_FILE",
          number,
          fileBase64: options.fileBase64,
          fileMime:   mime,
          filename,
          caption,
          fileType,
        }, (response) => {
          clearTimeout(timer);
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else resolve(response);
        });
      });
      if (wppResult && wppResult.success) {
        console.log("[WA Manager] File sent via WPP (SheetWA method):", wppResult);
        return { success: true, number, method: wppResult.method || "WPP_MAIN" };
      }
      console.warn("[WA Manager] WPP method failed, DOM fallback pe ja raha hoon:", wppResult?.reason);
    } catch (e) {
      console.warn("[WA Manager] WPP message error, DOM fallback:", e.message);
    }

    // base64 → File (DOM fallback ke liye)
    const byteChars = atob(options.fileBase64);
    const bytes = new Uint8Array(byteChars.length);
    for (let i = 0; i < byteChars.length; i++) bytes[i] = byteChars.charCodeAt(i);
    const file = new File([bytes], filename, { type: mime });

    // --- Method 2: DOM fallback ---
    const chatOpened = await openChatOnly(number);
    if (chatOpened && chatOpened.not_on_wa) {
      return { success: false, not_on_wa: true, reason: "Number WhatsApp par registered nahi hai" };
    }
    if (!chatOpened.success) return { success: false, reason: "Chat nahi khul saka" };
    await sleep(1500);

    try {
      // Attach button dhundho
      const attachBtn =
        document.querySelector('[data-testid="attach-menu-plus"]') ||
        document.querySelector('[data-icon="attach-menu-plus"]')   ||
        document.querySelector('[data-testid="clip"]')             ||
        document.querySelector('[data-icon="clip"]');

      if (attachBtn) {
        attachBtn.click();
        await sleep(700);

        // File input dhundho
        const fileInput = document.querySelector('input[type="file"]');
        if (fileInput) {
          const dt = new DataTransfer();
          dt.items.add(file);
          Object.defineProperty(fileInput, "files", { value: dt.files, writable: false });
          fileInput.dispatchEvent(new Event("change", { bubbles: true }));
          await sleep(2000);

          // Caption
          if (caption) {
            const captionBox =
              document.querySelector('[data-testid="media-caption-input-container"] [contenteditable]') ||
              document.querySelector('[data-testid="caption-input"]')                                   ||
              document.querySelector('div[contenteditable="true"][data-tab="10"]');
            if (captionBox) {
              captionBox.focus();
              await sleep(200);
              const cdt = new DataTransfer();
              cdt.setData("text/plain", caption);
              captionBox.dispatchEvent(new ClipboardEvent("paste", { clipboardData: cdt, bubbles: true, cancelable: true }));
              await sleep(600);
            }
          }

          // Send button
          const sendBtn =
            document.querySelector('[data-testid="send"]')      ||
            document.querySelector('button[aria-label="Send"]') ||
            document.querySelector('[data-icon="send"]');
          if (sendBtn) {
            sendBtn.click();
            await sleep(800);
            return { success: true, number, method: "DOM" };
          }
        }
      }

      // Last resort: clipboard paste
      const box = getComposeBox();
      if (box) {
        box.focus();
        await sleep(200);
        const cdt = new DataTransfer();
        cdt.items.add(file);
        box.dispatchEvent(new ClipboardEvent("paste", { clipboardData: cdt, bubbles: true, cancelable: true }));
        await sleep(1500);
        const sendBtn =
          document.querySelector('[data-testid="send"]')      ||
          document.querySelector('button[aria-label="Send"]') ||
          document.querySelector('[data-icon="send"]');
        if (sendBtn) { sendBtn.click(); await sleep(600); return { success: true, number, method: "clipboard" }; }
      }

      return { success: false, reason: "Attach/send button nahi mila" };
    } catch (e) {
      return { success: false, reason: e.message };
    }
  }
  function getComposeBox() {
    return (
      document.querySelector('[data-testid="conversation-compose-box-input"]') ||
      document.querySelector('div[contenteditable="true"][data-tab="10"]')     ||
      document.querySelector('div[contenteditable="true"][role="textbox"]')    ||
      document.querySelector('footer [contenteditable="true"]')
    );
  }

  async function typeAndSend(text) {
    const box = getComposeBox();
    if (!box) return { success:false, reason:'Compose box nahi mila' };
    await sleep(150 + Math.floor(Math.random()*450));
    box.focus();
    await sleep(200 + Math.floor(Math.random()*200));
    box.innerHTML = '';
    box.dispatchEvent(new Event('input',{bubbles:true}));
    await sleep(150);
    const dt = new DataTransfer(); dt.setData('text/plain', text);
    box.dispatchEvent(new ClipboardEvent('paste',{clipboardData:dt,bubbles:true,cancelable:true}));
    const readDelay = Math.min(3000, 400+text.length*18+Math.floor(Math.random()*600));
    await sleep(readDelay);
    const checkText = (box.textContent||box.innerText||'').trim();
    if (!checkText) return { success:false, reason:'Text type nahi hua' };
    if (Math.random()<0.30) await sleep(500+Math.floor(Math.random()*1500));
    const sendBtn =
      document.querySelector('[data-testid="send"]')        ||
      document.querySelector('button[aria-label="Send"]')   ||
      document.querySelector('[data-icon="send"]');
    if (sendBtn) { sendBtn.click(); await sleep(400+Math.floor(Math.random()*300)); return {success:true}; }
    box.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',keyCode:13,bubbles:true}));
    await sleep(400+Math.floor(Math.random()*300));
    return { success:true };
  }

  function startObserver() {
    if (observer) return;
    observer = new MutationObserver(() => {
      clearTimeout(scanTimer);
      scanTimer = setTimeout(scanChatList, 600);

      // Label bar auto-rebuild: WA SPA route change ke baad bar gayab ho jaata hai
      clearTimeout(observer._lbTimer);
      observer._lbTimer = setTimeout(() => {
        const bar = document.getElementById('wnum-label-bar');
        const pane = document.querySelector('#pane-side');
        if (!bar && pane) {
          buildLabelBar();
        } else if (bar && pane && !pane.contains(bar)) {
          bar.remove(); window._wnumBarBuilding = false;
          buildLabelBar();
        }
        if (pane) refreshAllRowDots();
      }, 800);
    });
    observer.observe(document.body, { childList:true, subtree:true });
  }

  async function openChatOnly(number, retryCount = 0) {
    const clean = normalizeNumber(number.toString());
    let anchor = document.getElementById("wamessager-rar");
    if (!anchor) {
      anchor = document.createElement("a"); anchor.id="wamessager-rar";
      document.body.appendChild(anchor);
    }
    anchor.setAttribute("href", `https://wa.me/${clean}?text=${encodeURIComponent("\u00a0")}`);
    anchor.click();
    const sendBtn = await waitForSendBtn(8000);
    // NOT_ON_WA — number WhatsApp par registered nahi hai
    if (sendBtn === "NOT_ON_WA") {
      return { success: false, not_on_wa: true, reason: "Number WhatsApp par registered nahi hai" };
    }
    if (!sendBtn) {
      if (retryCount>=2) return {success:false};
      await sleep(3000);
      return openChatOnly(number, retryCount+1);
    }
    await sleep(500);
    const box = getComposeBox();
    if (box) { box.focus(); box.innerHTML=""; box.dispatchEvent(new Event("input",{bubbles:true})); }
    return {success:true};
  }

  // ─── Message listener ─────────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === "OPEN_CHAT") {
      openChatOnly(msg.number).then(r=>sendResponse(r)).catch(()=>sendResponse({ok:false}));
      return true;
    }
    if (msg.type === "SEND_MESSAGE") {
      sendMessageNoReload(msg.number, msg.message)
        .then(r=>sendResponse(r))
        .catch(e=>sendResponse({success:false, error:e.message}));
      return true;
    }
    if (msg.type === "SEND_FILE") {
      sendFileAttachment(msg.number, {
        fileBase64: msg.fileBase64 || "",
        fileMime:   msg.fileMime   || "application/octet-stream",
        caption:    msg.caption    || "",
        filename:   msg.filename   || "file",
        type:       msg.fileType   || "document",
      })
        .then(r=>sendResponse(r))
        .catch(e=>sendResponse({success:false, error:e.message}));
      return true;
    }
    if (msg.type === "RESCAN") {
      scanChatList();
      sendResponse({ok:true});
    }

    if (msg.type === "FULL_SCAN") {
      fullScanAllChats(sendResponse);
      return true; // async response
    }
    if (msg.type === "REFRESH_QR") {
      refreshQRPanel();
      sendResponse({ok:true});
    }
    // ── Resolve label contacts: name-keys → phone numbers via MAIN world ──
    if (msg.type === "GET_LABEL_CONTACTS") {
      (async () => {
        const labelId = msg.labelId;
        // Get contactLabels from storage
        chrome.storage.local.get("wnum_contact_labels", async (res) => {
          const contactLabels = res["wnum_contact_labels"] || {};
          // Collect keys (phone numbers or names) for this label
          const keys = Object.entries(contactLabels)
            .filter(([, ids]) => ids.includes(labelId))
            .map(([k]) => k.trim());

          if (!keys.length) { sendResponse({ contacts: [] }); return; }

          // Separate number-keys from name-keys
          const resolvedContacts = [];
          const nameKeys = [];

          keys.forEach(key => {
            const cleaned = key.replace(/[\s\-().+]/g, "").replace(/\D/g, "");
            if (cleaned.length >= 7) {
              // It's a phone number — add directly
              let num = cleaned;
              if (num.length === 10 && /^[6-9]/.test(num)) num = "91" + num;
              resolvedContacts.push({ number: num, name: "", fromLabel: true });
            } else {
              nameKeys.push(key);
            }
          });

          if (!nameKeys.length) { sendResponse({ contacts: resolvedContacts }); return; }

          // Resolve name-keys via GET_ALL_CONTACTS (MAIN world bridge)
          try {
            const result = await waRequest("GET_ALL_CONTACTS");
            if (result.contacts && result.contacts.length) {
              const nameMap = {};
              result.contacts.forEach(c => {
                (c.aliases || [c.name, c.phone]).forEach(alias => {
                  if (alias && alias.trim()) nameMap[alias.trim().toLowerCase()] = c;
                });
              });
              nameKeys.forEach(name => {
                const info = nameMap[name.toLowerCase()];
                if (info && info.phone) {
                  let num = info.phone.replace(/\D/g, "");
                  if (num.length === 10 && /^[6-9]/.test(num)) num = "91" + num;
                  resolvedContacts.push({ number: num, name: info.name || name, fromLabel: true });
                } else {
                  // Couldn't resolve — include key as name hint for debugging
                  resolvedContacts.push({ number: "", name: name, fromLabel: true, unresolved: true });
                }
              });
            }
          } catch(e) {
            console.warn("[WA Manager] GET_LABEL_CONTACTS: GET_ALL_CONTACTS failed:", e);
          }

          sendResponse({ contacts: resolvedContacts });
        });
      })();
      return true; // async
    }
  });

  // ══════════════════════════════════════════════════════════════════════════
  // INIT
  // ══════════════════════════════════════════════════════════════════════════
  async function init() {
    injectStyles();
    await loadKnownNumbers();
    await loadContactLabels();
    setTimeout(refreshAllRowDots, 2000); // After WA renders rows
    scanChatList();
    startObserver();
    setInterval(scanChatList, SCAN_INTERVAL_MS);

    // Build label bar — tries multiple DOM selectors internally
    // Retry a few times since WA SPA may not have rendered the chat list yet
    buildLabelBar();
    let lbRetry = 0;
    const lbInterval = setInterval(() => {
      if (document.getElementById("wnum-label-bar") || lbRetry++ > 10) {
        clearInterval(lbInterval);
        return;
      }
      buildLabelBar();
    }, 1000);
    watchNativeTabs();

    // Attach right-click context menu for label assignment
    attachContactLabelContextMenu();
    let ctxRetry = 0;
    const ctxInterval = setInterval(() => {
      const pane = document.querySelector('#pane-side');
      if ((pane && pane._wnumCtxAttached) || ctxRetry++ > 15) { clearInterval(ctxInterval); return; }
      attachContactLabelContextMenu();
    }, 1000);

    // Watch for footer → build quick reply panel (single observer, debounced)
    watchForFooter();

    // ── REPLY DETECTION: incoming messages → campaign replied mark ──
    // ── Reply Detection: 3 methods for reliability ──────────────────────
    // Method 1: WPP.ev (MAIN world — via postMessage bridge)
    (function attachReplyDetectorViaMain(retries) {
      if (retries <= 0) return;
      try {
        // Ask group-extractor.js (MAIN world) to subscribe to WPP.ev
        window.postMessage({ source: 'wnum-isolated', action: 'SUBSCRIBE_REPLIES' }, '*');
      } catch(e) {}
      // Also try direct WPP.ev (works if content.js runs in MAIN world)
      try {
        if (window.WPP && window.WPP.ev) {
          window.WPP.ev.on('chat.new_message', function(wmsg) {
            try {
              if (wmsg.fromMe) return;
              var rawNum = String(wmsg.chatId || (wmsg.id && wmsg.id.remote) || wmsg.from || '');
              var num = rawNum.replace(/@.*$/, '').replace(/\D/g, '');
              if (!num) return;
              chrome.runtime.sendMessage({ type: 'MARK_CAMPAIGN_REPLIED', number: num });
            } catch(e) {}
          });
          console.log('[WA Manager] Reply detector attached via WPP.ev');
          return;
        }
      } catch(e) {}
      setTimeout(function() { attachReplyDetectorViaMain(retries - 1); }, 2000);
    })(15);

    // Listen for reply events posted from MAIN world (group-extractor bridge)
    window.addEventListener('message', function(event) {
      if (!event.data || event.data.source !== 'wnum-main') return;
      if (event.data.action === 'INCOMING_MESSAGE') {
        try {
          var num = (event.data.number || '').replace(/\D/g, '');
          if (num) chrome.runtime.sendMessage({ type: 'MARK_CAMPAIGN_REPLIED', number: num });
        } catch(e) {}
      }
    });

    // Method 2: Robust DOM-based reply detector
    (function attachDOMReplyDetector() {
      var _seenMsgIds = new Set();

      // Get phone number of currently open chat via multiple methods
      function getOpenChatNumber() {
        try {
          // Method A: WPP.chat.getActive (MAIN world — ask via postMessage)
          // We'll use a synchronous fallback chain instead

          // Method B: data-id on message rows — format is "false_919876543210@c.us_MSGID"
          const anyMsg = document.querySelector(
            '[data-id*="@c.us"], [data-id*="@g.us"]'
          );
          if (anyMsg) {
            const dataId = anyMsg.getAttribute('data-id') || '';
            const match = dataId.match(/_(\d{10,15})@c\.us/);
            if (match) return match[1];
          }

          // Method C: URL hash contains chat ID on some WA versions
          const hash = window.location.hash || '';
          const hashMatch = hash.match(/(\d{10,15})/);
          if (hashMatch) return hashMatch[1];

          // Method D: Chat header link/phone
          const headerLink = document.querySelector(
            '[data-testid="conversation-header"] a[href*="tel:"],' +
            '[data-testid="conversation-header"] [title*="+"]'
          );
          if (headerLink) {
            const raw = headerLink.getAttribute('href') || headerLink.getAttribute('title') || '';
            const m = raw.replace(/[^\d]/g,'').match(/(\d{10,15})/);
            if (m) return m[1];
          }
        } catch(e) {}
        return null;
      }

      // Watch conversation panel for new incoming messages
      var _convObserver = null;
      var _currentChatNum = null;

      function onNewNode(mutations) {
        for (const mut of mutations) {
          for (const node of mut.addedNodes) {
            if (!node || node.nodeType !== 1) continue;

            // ── Find data-id element (self or descendant) ──
            // data-id format: "false_919876543210@c.us_MSGID" (incoming individual)
            //                 "true_919876543210@c.us_MSGID"  (outgoing — skip)
            //                 "false_XXXXX@g.us_MSGID"        (group — skip)
            const msgEl = (node.matches?.('[data-id]')) ? node : node.querySelector?.('[data-id]');
            if (!msgEl) continue;

            const msgId = msgEl.getAttribute('data-id') || '';
            if (!msgId) continue;

            // Avoid double-counting the same message
            if (_seenMsgIds.has(msgId)) continue;
            _seenMsgIds.add(msgId);
            // Keep set size bounded (memory safety)
            if (_seenMsgIds.size > 2000) {
              const first = _seenMsgIds.values().next().value;
              _seenMsgIds.delete(first);
            }

            // Skip outgoing messages (data-id starts with "true_")
            if (msgId.startsWith('true_')) continue;

            // Only individual chats — @c.us  (skip @g.us group messages)
            if (!msgId.includes('@c.us')) continue;

            // Extract phone number: false_919876543210@c.us_MSGID
            const m = msgId.match(/_(\d{7,15})@c\.us/);
            if (m) {
              var num = m[1];
              console.log('[WA Manager] Incoming reply detected (DOM) from:', num);
              chrome.runtime.sendMessage({ type: 'MARK_CAMPAIGN_REPLIED', number: num });
              continue;
            }

            // Fallback: use currently open chat number
            if (!_currentChatNum) _currentChatNum = getOpenChatNumber();
            if (_currentChatNum) {
              console.log('[WA Manager] Incoming reply detected (fallback) from:', _currentChatNum);
              chrome.runtime.sendMessage({ type: 'MARK_CAMPAIGN_REPLIED', number: _currentChatNum });
            }
          }
        }
      }

      function attachConvObserver() {
        // Prefer specific conversation panel; fall back to #main (entire right pane)
        const panel =
          document.querySelector('[data-testid="conversation-panel-messages"]') ||
          document.querySelector('[data-testid="msg-container"]') ||
          document.querySelector('[aria-label="Message list"]') ||
          document.querySelector('#main div[role="application"]') ||
          document.getElementById('main');

        if (panel && panel !== _convObserver?._panel) {
          if (_convObserver) _convObserver.disconnect();
          _convObserver = new MutationObserver(onNewNode);
          _convObserver._panel = panel;
          _convObserver.observe(panel, { childList: true, subtree: true });
          _currentChatNum = getOpenChatNumber();
          console.log('[WA Manager] DOM reply observer attached on:', panel.id || panel.getAttribute('data-testid') || 'panel');
        }
      }

      // Re-attach when chat changes
      setInterval(() => {
        attachConvObserver();
        _currentChatNum = getOpenChatNumber();
      }, 2000);

      attachConvObserver();
    })();

    // Re-init label bar if WA navigates (SPA route change)
    let labelDebounce = null;
    document.addEventListener("click", () => {
      clearTimeout(labelDebounce);
      labelDebounce = setTimeout(() => {
        if (!document.getElementById("wnum-label-bar")) buildLabelBar();
        attachContactLabelContextMenu();
        // Reposition QR panel after chat switch
        if (qrPanelEl) {
          const box = document.querySelector('[data-testid="conversation-compose-box-input"]') ||
                      document.querySelector('div[contenteditable="true"][data-tab="10"]');
          if (box) {
            qrPanelEl.style.display = "flex";
            positionQRPanel();
          } else {
            qrPanelEl.style.display = "none";
          }
        } else {
          buildQRPanel().then(() => setTimeout(positionQRPanel, 200));
        }
      }, 600);
    });

    // Floating Group Download Button — always visible bottom-left of chat pane
    buildGroupFloatingBtn();
    console.log("[WA Number Manager v2] Initialized — Labels ✓ Contact-Labels ✓ Quick Replies ✓ Download ✓ Groups ✓");
  }

  // ── Auth Gate ─────────────────────────────────────────────────────────────
  // content.js ISOLATED world mein run hota hai — Auth object available nahi.
  // chrome.storage se session directly check karte hain.
  let _initDone = false;

  async function checkAuthAndInit() {
    if (_initDone) return; // already initialized — double-call block karo

    try {
      const data = await chrome.storage.local.get(['wa_subscription_session']);
      const session = data['wa_subscription_session'] || null;

      if (!session) {
        console.log('[WA Manager] Not logged in — init blocked.');
        return;
      }

      // Session expiry check
      if (Date.now() > session.sessionExpires) {
        console.log('[WA Manager] Session expired — init blocked.');
        await chrome.storage.local.remove(['wa_subscription_session']);
        return;
      }

      // Subscription expiry check
      if (session.expiry) {
        const expiry = new Date(session.expiry);
        expiry.setHours(23, 59, 59, 999);
        if (Date.now() > expiry.getTime()) {
          console.log('[WA Manager] Subscription expired — init blocked.');
          await chrome.storage.local.remove(['wa_subscription_session']);
          return;
        }
      }

      // Auth valid hai — init karo
      _initDone = true;
      console.log('[WA Manager] Auth valid — initializing...');
      init();

    } catch (err) {
      console.error('[WA Manager] Auth check error:', err);
    }
  }

  function waitForApp() {
    const app = document.querySelector('#app,[data-testid="chat-list"],#pane-side');
    if (app) { checkAuthAndInit(); }
    else { setTimeout(waitForApp, 1000); }
  }

  // Popup login ke baad content script ko init karne ka message sunna
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === 'AUTH_LOGIN_SUCCESS' && !_initDone) {
      console.log('[WA Manager] Login success message mila — initializing...');
      const app = document.querySelector('#app,[data-testid="chat-list"],#pane-side');
      if (app) {
        checkAuthAndInit();
      } else {
        waitForApp();
      }
      sendResponse({ ok: true });
      return true;
    }
  });

  waitForApp();
})();
