/**
 * dashboard.js — WhatsApp Number Manager Dashboard Logic
 * NEW FEATURES: Google Sheets Live Data, Cascading Filters, Preview, Log
 */

"use strict";

// ─── Helpers ─────────────────────────────────────────────────────────────
function msg(type, extra = {}) {
  return new Promise((res) =>
    chrome.runtime.sendMessage({ type, ...extra }, (r) => res(r || {}))
  );
}

function toast(text, duration = 2800) {
  const el = document.getElementById("toast");
  el.textContent = text;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), duration);
}

function fmtDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

function countryFlag(code) {
  const flags = { IN:"🇮🇳", US:"🇺🇸", GB:"🇬🇧", AE:"🇦🇪", PK:"🇵🇰", Unknown:"🌐" };
  return flags[code] || "🌐";
}

function statusClass(n) {
  if (n.blacklisted) return "status-blacklisted";
  const s = (n.status || "New").toLowerCase().replace(" ", "-");
  return `status-${s}`;
}

function statusLabel(n) {
  if (n.blacklisted) return "Blacklisted";
  return n.status || "New";
}

function escHtml(s) {
  return String(s || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}

// ─── App State ────────────────────────────────────────────────────────────
let allNumbers      = [];
let templates       = [];
let settings        = {};
let schedule        = {};
let selectedNumbers = new Set();
let editTarget      = null;
let templateEditId  = null;

// ─── Google Sheets State ──────────────────────────────────────────────────
let gsRawData      = [];   // parsed CSV rows (array of objects)
let gsHeaders      = [];   // ALL column names from sheet
let gsAllColumns   = [];   // non-number columns (for filters + variables)
let gsMapping      = { number:"" };  // only number column required
let gsMappedData   = [];   // after mapping applied (all columns included)
let gsFiltered     = [];   // after filters applied
let gsSelected     = new Set(); // selected phone numbers
let gsSentCount    = 0;
let gsFailedCount  = 0;
let gsSheetUrl     = "";
let gsSheetId      = "";   // extracted sheet ID
let gsSheetTabs    = [];   // [{name, gid}] detected tabs
let gsActiveGid    = "";   // current active gid

// ─── Multi-Sheet Tabs State ────────────────────────────────────────────────
// Each entry: { id, name, url, sheetId, gid, mapping, rawData, headers, sheetTabs, activeGid }
let msSheets       = [];   // all sheet tabs
let msActiveIdx    = 0;    // currently active sheet tab index

// Save current GS state into the active msSheet slot
function msSaveCurrentToSlot() {
  if (!msSheets.length) return;
  const s = msSheets[msActiveIdx];
  if (!s) return;
  s.url       = gsSheetUrl;
  s.sheetId   = gsSheetId;
  s.gid       = gsActiveGid;
  s.mapping   = { ...gsMapping };
  s.rawData   = gsRawData.slice();
  s.headers   = gsHeaders.slice();
  s.sheetTabs = gsSheetTabs.slice();
  s.activeGid = gsActiveGid;
}

// Load a slot into the active GS state
function msLoadSlot(idx) {
  const s = msSheets[idx];
  if (!s) return;
  gsSheetUrl  = s.url       || "";
  gsSheetId   = s.sheetId   || "";
  gsActiveGid = s.activeGid || "";
  gsMapping   = s.mapping   ? { ...s.mapping } : { number:"" };
  gsRawData   = s.rawData   ? s.rawData.slice() : [];
  gsHeaders   = s.headers   ? s.headers.slice() : [];
  gsSheetTabs = s.sheetTabs ? s.sheetTabs.slice() : [];
  gsMappedData = [];
  gsFiltered   = [];
  gsSelected   = new Set();
}

// Render the tab bar at top of Google Sheets section
function msRenderTabBar() {
  const list = document.getElementById("ms-tabs-list");
  if (!list) return;
  list.innerHTML = "";

  msSheets.forEach((s, i) => {
    const isActive = i === msActiveIdx;
    const tab = document.createElement("div");
    tab.dataset.msIdx = i;
    tab.dataset.msRemove = "0";
    tab.style.cssText = [
      "display:flex;align-items:center;gap:5px;",
      "padding:6px 12px 8px;",
      "border-radius:8px 8px 0 0;",
      "border:1.5px solid " + (isActive ? "var(--green)" : "var(--border)") + ";",
      "border-bottom:none;",
      "cursor:pointer;font-size:13px;font-weight:" + (isActive ? "700" : "500") + ";",
      "white-space:nowrap;user-select:none;",
      "position:relative;top:2px;",
      "background:" + (isActive ? "var(--bg)" : "var(--bg2)") + ";",
      "color:" + (isActive ? "var(--green)" : "var(--text2)") + ";",
      "transition:all 0.15s;"
    ].join("");

    // Name label
    const nameSpan = document.createElement("span");
    nameSpan.dataset.msPart = "name";
    nameSpan.textContent = s.name;
    nameSpan.style.cssText = "pointer-events:none;";
    tab.appendChild(nameSpan);

    // ✕ remove button — only if >1 tab
    if (msSheets.length > 1) {
      const x = document.createElement("span");
      x.dataset.msPart = "remove";
      x.textContent = "✕";
      x.title = "Tab hatao";
      x.style.cssText = "font-size:10px;opacity:0.45;padding:0 2px;line-height:1;pointer-events:all;";
      tab.appendChild(x);
    }

    list.appendChild(tab);
  });

  // Single delegated click handler on the list — no closure bugs
  list.onclick = (e) => {
    const tab = e.target.closest("[data-ms-idx]");
    if (!tab) return;
    const idx = parseInt(tab.dataset.msIdx, 10);

    // ✕ remove clicked
    if (e.target.dataset.msPart === "remove") {
      const name = msSheets[idx] ? msSheets[idx].name : "Tab";
      if (!confirm('"' + name + '" tab remove karein?')) return;
      msSheets.splice(idx, 1);
      if (msActiveIdx >= msSheets.length) msActiveIdx = msSheets.length - 1;
      msLoadSlot(msActiveIdx);
      msRenderTabBar();
      msRefreshUI();
      msSaveAllSheets();
      return;
    }

    // Same tab clicked — no-op
    if (idx === msActiveIdx) return;

    // Switch tab
    msSaveCurrentToSlot();
    msActiveIdx = idx;
    msLoadSlot(idx);
    msRenderTabBar();
    msRefreshUI();
    msSaveAllSheets();
  };

  // Double-click to rename
  list.ondblclick = (e) => {
    const tab = e.target.closest("[data-ms-idx]");
    if (!tab) return;
    if (e.target.dataset.msPart === "remove") return;
    const idx = parseInt(tab.dataset.msIdx, 10);
    const s = msSheets[idx];
    if (!s) return;

    const nameSpan = tab.querySelector("[data-ms-part='name']");
    if (!nameSpan) return;

    const inp = document.createElement("input");
    inp.value = s.name;
    inp.style.cssText = "width:80px;font-size:12px;border:none;outline:none;background:transparent;color:inherit;font-weight:inherit;";
    nameSpan.replaceWith(inp);
    inp.focus(); inp.select();

    const done = () => {
      const v = inp.value.trim() || s.name;
      s.name = v;
      msRenderTabBar();
      msSaveAllSheets();
      if (idx === msActiveIdx) {
        const badge = document.getElementById("ms-active-sheet-name");
        if (badge) badge.textContent = "— " + v;
      }
    };
    inp.addEventListener("blur", done);
    inp.addEventListener("keydown", e2 => { if (e2.key === "Enter") inp.blur(); });
  };
}

// Refresh all the UI cards based on newly loaded slot
function msRefreshUI() {
  // Update URL input
  const urlInput = document.getElementById("gs-url");
  if (urlInput) urlInput.value = gsSheetUrl || "";

  // Active sheet name badge
  const badge = document.getElementById("ms-active-sheet-name");
  if (badge) badge.textContent = msSheets[msActiveIdx] ? "— " + msSheets[msActiveIdx].name : "";

  // Hide all cards first
  ["gs-mapping-card","gs-filter-card","gs-table-container","gs-compose-card","gs-tab-card"].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = "none";
  });

  const countEl = document.getElementById("gs-count");
  if (countEl) countEl.style.display = "none";

  if (!gsSheetUrl) {
    showGsStatus("", "");
    return;
  }

  showGsStatus(`✅ ${gsRawData.length} rows loaded`, "success");
  const countE = document.getElementById("gs-count");
  if (countE) { countE.textContent = gsRawData.length; countE.style.display = "inline"; }

  populateMappingSelects(gsHeaders);
  document.getElementById("gs-mapping-card").style.display = "block";

  if (gsMapping.number && gsHeaders.includes(gsMapping.number)) {
    document.getElementById("map-number").value = gsMapping.number;
    applyGsMapping();
    buildCascadingFilters();
    applyGsFilters();
    document.getElementById("gs-filter-card").style.display = "block";
    document.getElementById("gs-table-container").style.display = "block";
    document.getElementById("gs-compose-card").style.display = "block";
    updateComposeVarsHint();
  }

  if (gsSheetTabs.length > 0) {
    document.getElementById("gs-tab-card").style.display = "block";
    renderSavedTabs();
  }
}

// Save all sheets to storage
function msSaveAllSheets() {
  msSaveCurrentToSlot();
  chrome.storage.local.set({ msSheets, msActiveIdx });
}

// Init multi-sheet system
function msInit() {
  // Load from storage
  chrome.storage.local.get(["msSheets","msActiveIdx"], (data) => {
    if (data.msSheets && data.msSheets.length > 0) {
      msSheets    = data.msSheets;
      msActiveIdx = data.msActiveIdx || 0;
      if (msActiveIdx >= msSheets.length) msActiveIdx = 0;
      msLoadSlot(msActiveIdx);
      msRenderTabBar();
      // Restore UI
      if (gsSheetUrl) {
        // If we have data, show it
        if (gsRawData.length > 0) {
          msRefreshUI();
        } else {
          // Try to fetch fresh data
          fetchGoogleSheet(buildCsvUrl(gsSheetId, gsActiveGid)).then(csvText => {
            const { headers, rows } = parseCSVText(csvText);
            gsRawData = rows; gsHeaders = headers;
            msSaveCurrentToSlot();
            msRefreshUI();
          }).catch(() => { msRefreshUI(); });
        }
      } else {
        msRenderTabBar();
      }
    } else {
      // First time — create Sheet 1
      msSheets    = [{ id: Date.now(), name: "Sheet 1", url:"", sheetId:"", gid:"", mapping:{number:""}, rawData:[], headers:[], sheetTabs:[], activeGid:"" }];
      msActiveIdx = 0;
      msRenderTabBar();
    }
  });

  // + button to add new sheet tab
  document.getElementById("ms-btn-add-sheet").addEventListener("click", () => {
    msSaveCurrentToSlot();
    const newSheet = { id: Date.now(), name: `Sheet ${msSheets.length + 1}`, url:"", sheetId:"", gid:"", mapping:{number:""}, rawData:[], headers:[], sheetTabs:[], activeGid:"" };
    msSheets.push(newSheet);
    msActiveIdx = msSheets.length - 1;
    msLoadSlot(msActiveIdx);
    msRenderTabBar();
    msRefreshUI();
    msSaveAllSheets();
    toast(`"${newSheet.name}" tab add hua! URL paste karo aur Connect karo.`);
  });
}

// ─── Tab Navigation ───────────────────────────────────────────────────────
function initTabs() {
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.addEventListener("click", () => {
      document.querySelectorAll(".nav-item").forEach(n => n.classList.remove("active"));
      document.querySelectorAll(".tab-pane").forEach(p => p.classList.remove("active"));
      item.classList.add("active");
      document.getElementById(`tab-${item.dataset.tab}`).classList.add("active");
      // Refresh sheet options every time Scheduler tab is opened
      if (item.dataset.tab === "schedule") {
        populateScheduleSheetTabs();
        loadSendLog();
      }
      // Load message stats when Settings tab is opened
      if (item.dataset.tab === "settings") {
        loadMessageStats();
      }
    });
  });
}

// ─── Numbers Tab ─────────────────────────────────────────────────────────
function updateStats(numbers) {
  const today = new Date().toDateString();
  // Stats cards removed — sirf nav-count update karo
  const navCount = document.getElementById("nav-count");
  if (navCount) navCount.textContent = numbers.length;
  // Agar koi purani ID exist karti ho toh safely update karo
  const safe = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
  safe("s-total",       numbers.length);
  safe("s-today",       numbers.filter(n => new Date(n.dateTime).toDateString() === today).length);
  safe("s-messaged",    numbers.filter(n => n.status === "Messaged").length);
  safe("s-blacklisted", numbers.filter(n => n.blacklisted).length);
}

function getFilteredNumbers() {
  const q       = document.getElementById("search-input").value.toLowerCase().trim();
  const status  = document.getElementById("filter-status").value;
  const country = document.getElementById("filter-country").value;

  return allNumbers.filter(n => {
    const matchQ = !q ||
      n.number.includes(q) ||
      (n.lastMessage || "").toLowerCase().includes(q) ||
      (n.tags || "").toLowerCase().includes(q) ||
      (n.notes || "").toLowerCase().includes(q);
    const matchStatus  = !status  || (status === "Blacklisted" ? n.blacklisted : n.status === status);
    const matchCountry = !country || n.country === country;
    return matchQ && matchStatus && matchCountry;
  });
}

function renderTable() {
  const tbody  = document.getElementById("table-body");
  const filtered = getFilteredNumbers();

  if (filtered.length === 0) {
    tbody.innerHTML = `
      <tr class="empty-row"><td colspan="8">
        <div class="table-empty">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 1.27h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.91a16 16 0 0 0 6.1 6.1l1-1.02a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
          <p>No numbers found. Open WhatsApp Web to start detecting unsaved numbers.</p>
        </div>
      </td></tr>`;
    return;
  }

  tbody.innerHTML = filtered.map(n => `
    <tr data-num="${escHtml(n.number)}" class="${selectedNumbers.has(n.number) ? "selected" : ""}">
      <td><input type="checkbox" class="row-check" data-num="${escHtml(n.number)}" ${selectedNumbers.has(n.number) ? "checked" : ""} /></td>
      <td class="phone-cell">
        <a href="#" class="phone-link" data-num="${escHtml(n.number)}" title="Open chat (no reload)">${escHtml(n.number)}</a>
      </td>
      <td class="msg-preview" title="${escHtml(n.lastMessage)}">${escHtml(n.lastMessage || "—")}</td>
      <td class="date-cell">${fmtDate(n.dateTime)}</td>
      <td>${countryFlag(n.country)} ${n.country || "?"}</td>
      <td class="inline-edit-cell" data-field="status" data-num="${escHtml(n.number)}">
        <select class="inline-status-select" data-num="${escHtml(n.number)}" title="Click to change status" style="background:transparent;border:none;cursor:pointer;font-size:12px;font-weight:600;padding:2px 4px;border-radius:6px;outline:none;width:100%">
          <option value="New" ${(n.status||"New")==="New"?"selected":""}>🆕 New</option>
          <option value="Messaged" ${n.status==="Messaged"?"selected":""}>✅ Messaged</option>
          <option value="Replied" ${n.status==="Replied"?"selected":""}>💬 Replied</option>
          <option value="Interested" ${n.status==="Interested"?"selected":""}>🔥 Interested</option>
          <option value="Not Interested" ${n.status==="Not Interested"?"selected":""}>❌ Not Interested</option>
          <option value="Blacklisted" ${n.blacklisted?"selected":""}>🚫 Blacklisted</option>
        </select>
      </td>
      <td class="inline-edit-cell" data-field="tags" data-num="${escHtml(n.number)}">
        <span class="inline-editable-text" data-num="${escHtml(n.number)}" data-field="tags" title="Click to edit tags" contenteditable="true" spellcheck="false" style="display:inline-block;min-width:40px;max-width:120px;outline:none;border-radius:4px;padding:2px 4px;cursor:text">${escHtml(n.tags || "")}</span>
      </td>
      <td>
        <div class="action-btns">
          <button class="act-btn" data-action="chat" data-num="${escHtml(n.number)}" title="Open Chat">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
          </button>
          <button class="act-btn" data-action="edit" data-num="${escHtml(n.number)}" title="Edit (full form)">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
          </button>
          <button class="act-btn blacklist" data-action="blacklist" data-num="${escHtml(n.number)}" title="${n.blacklisted ? "Unblacklist" : "Blacklist"}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>
          </button>
          <button class="act-btn delete" data-action="delete" data-num="${escHtml(n.number)}" title="Delete">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
          </button>
        </div>
      </td>
    </tr>
  `).join("");

  tbody.querySelectorAll("[data-action]").forEach(btn => {
    btn.addEventListener("click", async (e) => {
      e.stopPropagation();
      const action = btn.dataset.action;
      const num    = btn.dataset.num;
      const record = allNumbers.find(n => n.number === num);

      if (action === "chat") {
        // Pehle existing WhatsApp Web tab dhundho
        const waTabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
        if (waTabs.length > 0) {
          // Existing tab mein bina reload ke chat kholo
          await chrome.tabs.update(waTabs[0].id, { active: true });
          chrome.tabs.sendMessage(waTabs[0].id, { type: "OPEN_CHAT", number: num });
        } else {
          // Agar WA tab nahi hai toh naya tab kholo
          chrome.tabs.create({ url: `https://web.whatsapp.com/send?phone=${num}` });
        }
      }
      if (action === "edit") openEditModal(record);
      if (action === "blacklist") {
        await msg("BLACKLIST_NUMBER", { number: num });
        await refreshNumbers();
        toast(record?.blacklisted ? "Number unblacklisted ✅" : "Number blacklisted 🚫");
      }
      if (action === "delete") {
        if (confirm(`Delete ${num}?`)) {
          await msg("DELETE_NUMBER", { number: num });
          selectedNumbers.delete(num);
          await refreshNumbers();
          toast("Number deleted.");
        }
      }
    });
  });

  tbody.querySelectorAll(".row-check").forEach(cb => {
    cb.addEventListener("change", () => {
      if (cb.checked) selectedNumbers.add(cb.dataset.num);
      else selectedNumbers.delete(cb.dataset.num);
      updateSelectionUI();
    });
  });

  // Phone number link pe click → bina reload ke existing WA tab mein chat kholo
  tbody.querySelectorAll(".phone-link").forEach(link => {
    link.addEventListener("click", async (e) => {
      e.preventDefault();
      e.stopPropagation();
      const num = link.dataset.num;
      const waTabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
      if (waTabs.length > 0) {
        await chrome.tabs.update(waTabs[0].id, { active: true });
        chrome.tabs.sendMessage(waTabs[0].id, { type: "OPEN_CHAT", number: num });
      } else {
        chrome.tabs.create({ url: `https://web.whatsapp.com/send?phone=${num}` });
      }
    });
  });

  // ── Inline Status Select → auto-save + GS sync ─────────────────────────
  tbody.querySelectorAll(".inline-status-select").forEach(sel => {
    sel.addEventListener("change", async () => {
      const num = sel.dataset.num;
      const newStatus = sel.value;
      const isBlacklisted = newStatus === "Blacklisted";

      // Visual feedback
      sel.style.opacity = "0.5";

      await msg("UPDATE_NUMBER", { data: {
        number: num,
        status: isBlacklisted ? "New" : newStatus,
        blacklisted: isBlacklisted,
      }});

      // GS Sync agar active hai
      try {
        const scriptUrl = await getScriptUrl(gsActiveGid);
        if (scriptUrl && gsSheetId) {
          const { tabConfigs } = await loadSyncConfig();
          const cfg = tabConfigs[gsActiveGid] || {};
          const numColName = cfg.numCol || gsMapping.number || "";
          if (numColName) {
            const updateData = {};
            // Status column mapping dhundho
            const statusColName = cfg.statusCol || gsMapping.status || "STATUS";
            updateData[statusColName] = newStatus;
            await syncUpdateInSheet(gsSheetId, gsActiveGid, scriptUrl, num, updateData, numColName);
            toast(`✅ ${num} → ${newStatus} (Sheet updated)`);
          } else {
            toast(`✅ ${num} → ${newStatus} (local)`);
          }
        } else {
          toast(`✅ ${num} → ${newStatus}`);
        }
      } catch(e) {
        toast(`✅ ${num} → ${newStatus} (Sheet sync failed: ${e.message})`);
      }

      sel.style.opacity = "1";
      await refreshNumbers();
    });
  });

  // ── Inline Tags contenteditable → blur pe auto-save + GS sync ──────────
  tbody.querySelectorAll(".inline-editable-text").forEach(span => {
    let originalVal = span.textContent;

    span.addEventListener("focus", () => {
      originalVal = span.textContent;
      span.style.background = "var(--bg2)";
      span.style.border = "1px solid var(--accent, #25d366)";
    });

    span.addEventListener("blur", async () => {
      span.style.background = "";
      span.style.border = "";
      const num = span.dataset.num;
      const field = span.dataset.field;
      const newVal = span.textContent.trim();

      if (newVal === originalVal) return; // kuch badla nahi

      span.style.opacity = "0.5";
      await msg("UPDATE_NUMBER", { data: { number: num, [field]: newVal }});

      // GS Sync
      try {
        const scriptUrl = await getScriptUrl(gsActiveGid);
        if (scriptUrl && gsSheetId) {
          const { tabConfigs } = await loadSyncConfig();
          const cfg = tabConfigs[gsActiveGid] || {};
          const numColName = cfg.numCol || gsMapping.number || "";
          if (numColName) {
            const colName = cfg[field + "Col"] || gsMapping[field] || field.toUpperCase();
            const updateData = { [colName]: newVal };
            await syncUpdateInSheet(gsSheetId, gsActiveGid, scriptUrl, num, updateData, numColName);
            toast(`✅ Tags saved → Sheet updated`);
          } else {
            toast(`✅ Tags saved (local)`);
          }
        } else {
          toast(`✅ Tags saved`);
        }
      } catch(e) {
        toast(`✅ Tags saved (Sheet sync: ${e.message})`);
      }

      span.style.opacity = "1";
      // allNumbers local update (no re-render to keep focus)
      const rec = allNumbers.find(n => n.number === num);
      if (rec) rec[field] = newVal;
    });

    // Enter key pe blur karo
    span.addEventListener("keydown", e => {
      if (e.key === "Enter") { e.preventDefault(); span.blur(); }
      if (e.key === "Escape") { span.textContent = originalVal; span.blur(); }
    });
  });
}

function updateSelectionUI() {
  const count = selectedNumbers.size;
  document.getElementById("sel-count").textContent = count;
  document.getElementById("btn-bulk-msg").disabled = count === 0;
  document.querySelectorAll("#table-body tr[data-num]").forEach(row => {
    row.classList.toggle("selected", selectedNumbers.has(row.dataset.num));
  });
}

async function refreshNumbers() {
  const res = await msg("GET_ALL_NUMBERS");
  allNumbers = res.numbers || [];
  updateStats(allNumbers);
  renderTable();
}

function initNumbersTab() {
  document.getElementById("search-input").addEventListener("input", renderTable);
  document.getElementById("filter-status").addEventListener("change", renderTable);
  document.getElementById("filter-country").addEventListener("change", renderTable);

  document.getElementById("select-all").addEventListener("change", function () {
    const filtered = getFilteredNumbers();
    if (this.checked) filtered.forEach(n => selectedNumbers.add(n.number));
    else filtered.forEach(n => selectedNumbers.delete(n.number));
    updateSelectionUI();
    renderTable();
  });

  document.getElementById("btn-bulk-msg").addEventListener("click", () => {
    document.getElementById("bulk-count").textContent = selectedNumbers.size;
    document.getElementById("bulk-modal").classList.add("open");
  });

  document.getElementById("btn-export-csv").addEventListener("click", () => exportCSV(allNumbers));
  document.getElementById("btn-export-mobile").addEventListener("click", () => exportMobileDashboard());

  document.getElementById("btn-clear-all").addEventListener("click", async () => {
    if (!confirm("Delete ALL stored numbers? This cannot be undone.")) return;
    await msg("CLEAR_ALL");
    allNumbers = [];
    selectedNumbers.clear();
    updateStats([]);
    renderTable();
    toast("All numbers cleared.");
  });

  document.getElementById("btn-import").addEventListener("click", () => {
    document.getElementById("csv-file-input").click();
  });
  document.getElementById("csv-file-input").addEventListener("change", handleCSVImport);
}

// ─── CSV Export ───────────────────────────────────────────────────────────
function exportCSV(numbers) {
  if (!numbers.length) { toast("No numbers to export."); return; }
  const headers = ["Number","Last Message","Date & Time","Status","Country","Tags","Notes","Blacklisted"];
  const rows = numbers.map(n => [
    n.number,
    `"${(n.lastMessage||"").replace(/"/g,'""')}"`,
    n.dateTime,
    n.status||"New",
    n.country||"",
    n.tags||"",
    `"${(n.notes||"").replace(/"/g,'""')}"`,
    n.blacklisted?"Yes":"No",
  ]);
  const csv = [headers,...rows].map(r=>r.join(",")).join("\n");
  const blob = new Blob([csv], {type:"text/csv"});
  const url  = URL.createObjectURL(blob);
  const a    = Object.assign(document.createElement("a"), {href:url, download:`wa_numbers_${Date.now()}.csv`});
  a.click();
  URL.revokeObjectURL(url);
  toast(`Exported ${numbers.length} numbers 📥`);
}

// ─── Mobile Dashboard Export ──────────────────────────────────────────────
async function exportMobileDashboard() {
  // SCRIPT_URL + sheetId se live dashboard URL banao
  const storageData = await new Promise(res =>
    chrome.storage.local.get(["msSheets","msActiveIdx","gsSheetUrl","gsSheetId","SCRIPT_URL"], res)
  );

  const scriptUrl  = storageData.SCRIPT_URL || "";
  const savedGsUrl = storageData.gsSheetUrl || "";
  const sheetId    = storageData.gsSheetId  || (savedGsUrl ? extractSheetId(savedGsUrl) : "");

  // Fallback: msSheets se pehli valid sheet
  let finalSheetId = sheetId;
  if (!finalSheetId && storageData.msSheets && storageData.msSheets.length > 0) {
    const s = storageData.msSheets[0];
    finalSheetId = s.sheetId || (s.url ? extractSheetId(s.url) : "");
  }

  if (!scriptUrl) {
    toast("⚠️ Script URL configure nahi hai. Settings → Script URL daalo.");
    return;
  }
  if (!finalSheetId) {
    toast("⚠️ Sheet ID nahi mila. Google Sheets tab mein URL connect karo.");
    return;
  }

  const dashUrl = `${scriptUrl}?action=dashboard&sheetId=${encodeURIComponent(finalSheetId)}`;

  // Clipboard mein copy karo
  try {
    await navigator.clipboard.writeText(dashUrl);
    toast("📋 Live Dashboard URL copy ho gayi! Mobile par paste karo.");
  } catch(e) {
    // Fallback: prompt
    prompt("Ye URL copy karo aur mobile par open karo:", dashUrl);
  }

  // Ek popup bhi dikhao
  showDashboardUrlPopup(dashUrl);
}

function showDashboardUrlPopup(url) {
  // Remove old if exists
  const old = document.getElementById("mobile-dash-popup");
  if (old) old.remove();

  const overlay = document.createElement("div");
  overlay.id = "mobile-dash-popup";
  overlay.style.cssText = "position:fixed;inset:0;background:#0008;z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px";

  overlay.innerHTML = `
    <div style="background:#1e293b;border-radius:16px;padding:24px;max-width:440px;width:100%;border:1px solid #334155;box-shadow:0 20px 60px #000a">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px">
        <span style="font-size:28px">📱</span>
        <div>
          <div style="font-weight:700;font-size:16px;color:#e2e8f0">Live Mobile Dashboard</div>
          <div style="font-size:12px;color:#22c55e;margin-top:2px">● Real-time Google Sheet data</div>
        </div>
      </div>
      <div style="background:#0f172a;border-radius:8px;padding:12px;font-size:11px;color:#94a3b8;word-break:break-all;border:1px solid #334155;margin-bottom:14px;max-height:60px;overflow:auto">${url}</div>
      <div style="display:flex;flex-direction:column;gap:8px">
        <button id="mdb-copy" style="background:#25D366;color:#fff;border:none;border-radius:8px;padding:11px;font-weight:700;font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px">
          📋 URL Copy Karo (Mobile par paste karo)
        </button>
        <button id="mdb-open" style="background:#1e40af;color:#fff;border:none;border-radius:8px;padding:11px;font-weight:700;font-size:14px;cursor:pointer">
          🌐 Isi PC par open karo (test ke liye)
        </button>
        <button id="mdb-wa" style="background:#075E54;color:#fff;border:none;border-radius:8px;padding:11px;font-weight:700;font-size:14px;cursor:pointer">
          💬 WhatsApp par bhejo (apne number par)
        </button>
        <button id="mdb-close" style="background:transparent;color:#64748b;border:1px solid #334155;border-radius:8px;padding:9px;font-size:13px;cursor:pointer">
          Close
        </button>
      </div>
      <div style="margin-top:12px;font-size:11px;color:#475569;text-align:center">
        ✅ PWA — Mobile par "Add to Home Screen" se install ho jayega<br>
        🔄 Refresh button se latest data milega
      </div>
    </div>
  `;

  document.body.appendChild(overlay);

  document.getElementById("mdb-copy").onclick = async () => {
    try { await navigator.clipboard.writeText(url); document.getElementById("mdb-copy").textContent = "✅ Copied!"; }
    catch(e) { prompt("URL copy karo:", url); }
  };
  document.getElementById("mdb-open").onclick = () => window.open(url, "_blank");
  document.getElementById("mdb-wa").onclick = () => {
    const waMsg = encodeURIComponent("📱 WA Dashboard: " + url);
    window.open("https://wa.me/?text=" + waMsg, "_blank");
  };
  document.getElementById("mdb-close").onclick = () => overlay.remove();
  overlay.addEventListener("click", e => { if (e.target === overlay) overlay.remove(); });
}




// ─── CSV Import ───────────────────────────────────────────────────────────
async function handleCSVImport(e) {
  const file = e.target.files[0];
  if (!file) return;
  const text = await file.text();
  const lines = text.split("\n").slice(1).filter(Boolean);
  const imported = [];

  lines.forEach(line => {
    const cols = line.split(",");
    const number = (cols[0]||"").trim().replace(/^"|"$/g,"");
    if (!number || !/^\+?\d{7,15}$/.test(number.replace(/[\s\-()]/g,""))) return;
    imported.push({
      number,
      lastMessage: (cols[1]||"").replace(/^"|"$/g,""),
      dateTime: cols[2] || new Date().toISOString(),
      status: cols[3] || "New",
      country: cols[4] || "Unknown",
      tags: cols[5] || "",
      notes: (cols[6]||"").replace(/^"|"$/g,""),
      blacklisted: cols[7]==="Yes",
    });
  });

  if (!imported.length) { toast("No valid numbers found in CSV."); return; }
  const res = await msg("IMPORT_NUMBERS", { numbers: imported });
  await refreshNumbers();
  toast(`Imported ${res.imported} new numbers ✅`);
  e.target.value = "";
}

// ─── Edit Modal ───────────────────────────────────────────────────────────
function openEditModal(record) {
  editTarget = record;
  document.getElementById("edit-number").value = record.number;
  document.getElementById("edit-status").value  = record.status || "New";
  document.getElementById("edit-tags").value    = record.tags || "";
  document.getElementById("edit-notes").value   = record.notes || "";
  document.getElementById("edit-modal").classList.add("open");
}

function initEditModal() {
  const close = () => document.getElementById("edit-modal").classList.remove("open");
  document.getElementById("edit-modal-close").addEventListener("click", close);
  document.getElementById("edit-modal-cancel").addEventListener("click", close);
  document.getElementById("edit-modal").addEventListener("click", e => { if(e.target===e.currentTarget) close(); });

  document.getElementById("edit-modal-save").addEventListener("click", async () => {
    if (!editTarget) return;
    await msg("UPDATE_NUMBER", { data: {
      number: editTarget.number,
      status: document.getElementById("edit-status").value,
      tags:   document.getElementById("edit-tags").value,
      notes:  document.getElementById("edit-notes").value,
    }});
    await refreshNumbers();
    close();
    toast("Number updated ✅");
  });
}

// ─── Bulk Modal ───────────────────────────────────────────────────────────
function initBulkModal() {
  const close = () => document.getElementById("bulk-modal").classList.remove("open");
  document.getElementById("bulk-modal-close").addEventListener("click", close);
  document.getElementById("bulk-modal-cancel").addEventListener("click", close);
  document.getElementById("bulk-modal").addEventListener("click", e => { if(e.target===e.currentTarget) close(); });

  document.getElementById("bulk-modal-send").addEventListener("click", async () => {
    const text = document.getElementById("bulk-msg-text").value.trim();
    if (!text) { toast("Please enter a message."); return; }
    const targets = [...selectedNumbers];
    close();
    await sendMessagesToNumbers(targets, text, {}, "unsaved");
  });
}

// ─── Attachment helpers (global, called from HTML onclick) ────────────────
function clearMsgAttachment() {
  window._msgAttachFile  = null;
  window._msgAttachFiles = [];
  document.getElementById("msg-attach-input").value = "";
  document.getElementById("msg-attach-placeholder").style.display = "flex";
  document.getElementById("msg-attach-preview").style.display = "none";
  document.getElementById("msg-attach-caption-group").style.display = "none";
  document.getElementById("msg-attach-box").style.borderColor = "#d1d5db";
}

function clearSchedAttachment() {
  window._schedAttachFile  = null;
  window._schedAttachFiles = [];
  document.getElementById("sched-attach-input").value = "";
  document.getElementById("sched-attach-placeholder").style.display = "flex";
  document.getElementById("sched-attach-preview").style.display = "none";
  document.getElementById("sched-attach-caption-group").style.display = "none";
  document.getElementById("sched-attach-box").style.borderColor = "#d1d5db";
}

function initMessagingTab() {
  const chipSelect = document.getElementById("chip-select");
  const picker     = document.getElementById("number-picker");

  // Messaging tab download report button
  const msgDlBtn = document.getElementById("btn-download-msg-report");
  if (msgDlBtn) {
    msgDlBtn.addEventListener("click", async () => {
      const res = await msg("GET_SEND_LOG");
      const log = (res.log || []).filter(e =>
        e.source === "manual" || e.source === "unsaved" || e.source === "saved" || !e.source
      );
      const date = new Date().toLocaleDateString("en-IN").replace(/\//g, "-");
      if (log.length) {
        downloadReportCSV(log, `WA_Messaging_Report_${date}.csv`);
      } else {
        downloadLiveLogCSV("send-log", `WA_Messaging_Report_${date}.csv`);
      }
      toast("✅ Messaging Report download ho rahi hai!");
    });
  }

  chipSelect.addEventListener("click", () => {
    picker.style.display = picker.style.display === "none" ? "block" : "none";
    renderPicker();
  });

  document.getElementById("msg-template-select").addEventListener("change", function () {
    const t = templates.find(t => t.id === this.value);
    if (t) document.getElementById("msg-text").value = t.text;
    updateCharCount();
  });

  document.getElementById("msg-text").addEventListener("input", updateCharCount);

  document.getElementById("btn-send-msgs").addEventListener("click", async () => {
    const text = document.getElementById("msg-text").value.trim();
    if (!text) { toast("Please enter a message."); return; }
    const chips = document.querySelectorAll(".chip");
    const targets = [...chips].map(c => c.dataset.num);
    if (!targets.length) { toast("Please select at least one number."); return; }
    await sendMessagesToNumbers(targets, text, {}, "saved");
  });

  // ── Attachment box click → open file picker ──
  document.getElementById("msg-attach-box").addEventListener("click", () => {
    document.getElementById("msg-attach-input").click();
  });

  // ── Clear button ──
  document.getElementById("msg-attach-clear").addEventListener("click", (e) => {
    e.stopPropagation();
    clearMsgAttachment();
  });

  // ── File selected (multiple files supported) ──
  document.getElementById("msg-attach-input").addEventListener("change", function () {
    const files = Array.from(this.files);
    if (!files.length) return;
    window._msgAttachFiles = files;  // store array
    document.getElementById("msg-attach-placeholder").style.display = "none";
    const preview = document.getElementById("msg-attach-preview");
    preview.style.display = "flex";
    if (files.length === 1) {
      const file = files[0];
      document.getElementById("msg-attach-name").textContent =
        file.name + " (" + (file.size > 1024*1024
          ? (file.size/1024/1024).toFixed(1) + "MB"
          : Math.round(file.size/1024) + "KB") + ")";
    } else {
      const totalSize = files.reduce((s, f) => s + f.size, 0);
      document.getElementById("msg-attach-name").textContent =
        files.length + " files selected (" + (totalSize > 1024*1024
          ? (totalSize/1024/1024).toFixed(1) + "MB"
          : Math.round(totalSize/1024) + "KB") + ")";
    }
    document.getElementById("msg-attach-caption-group").style.display = "block";
    document.getElementById("msg-attach-box").style.borderColor = "#16a34a";
  });
}

function updateCharCount() {
  document.getElementById("msg-char").textContent = document.getElementById("msg-text").value.length;
}

function renderPicker() {
  const picker = document.getElementById("number-picker");
  picker.innerHTML = allNumbers.filter(n => !n.blacklisted).map(n => `
    <div class="picker-item">
      <input type="checkbox" class="picker-check" data-num="${escHtml(n.number)}" />
      <span>${escHtml(n.number)}</span>
      <span style="color:var(--text2);font-size:11px;margin-left:auto">${n.status||"New"}</span>
    </div>
  `).join("");
  picker.querySelectorAll(".picker-check").forEach(cb => {
    cb.addEventListener("change", () => updateChips());
  });
}

function updateChips() {
  const chipSelect = document.getElementById("chip-select");
  const checked    = document.querySelectorAll(".picker-check:checked");
  chipSelect.innerHTML = "";
  if (checked.length === 0) {
    chipSelect.innerHTML = `<div class="chip-placeholder">Click to select numbers...</div>`;
    return;
  }
  checked.forEach(cb => {
    const chip = document.createElement("div");
    chip.className = "chip";
    chip.dataset.num = cb.dataset.num;
    chip.innerHTML = `${escHtml(cb.dataset.num)} <button>×</button>`;
    chip.querySelector("button").addEventListener("click", (e) => {
      e.stopPropagation();
      const matchCb = document.querySelector(`.picker-check[data-num="${cb.dataset.num}"]`);
      if (matchCb) matchCb.checked = false;
      chip.remove();
      if (!chipSelect.querySelectorAll(".chip").length)
        chipSelect.innerHTML = `<div class="chip-placeholder">Click to select numbers...</div>`;
    });
    chipSelect.appendChild(chip);
  });
}

async function sendMessagesToNumbers(targets, text, extraDataMap = {}, source = "manual") {
  const log = document.getElementById("send-log");
  const minD = Number(document.getElementById("delay-min")?.value || 3) * 1000;
  const maxD = Number(document.getElementById("delay-max")?.value || 8) * 1000;

  log.querySelector(".log-empty")?.remove();

  const tabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
  if (!tabs.length) { toast("Please open WhatsApp Web first!"); return; }

  const waTab = tabs[0];
  toast(`Sending to ${targets.length} numbers...`);

  for (const number of targets) {
    const extra = extraDataMap[number] || {};
    const finalMsg = applyVariables(text, number, extra);

    try {
      const delay = minD + Math.random() * (maxD - minD);
      await new Promise(r => setTimeout(r, delay));

      // ── Attachment bhejo agar selected hai ──
      const attachFiles = window._msgAttachFiles && window._msgAttachFiles.length
        ? window._msgAttachFiles
        : (window._msgAttachFile ? [window._msgAttachFile] : []);

      if (attachFiles.length > 0) {
        // Send each file; first file gets the caption/message, rest get empty caption
        let fileNotOnWA = false;
        for (let fi = 0; fi < attachFiles.length; fi++) {
          const attachFile = attachFiles[fi];
          const fileCaption = fi === 0 ? finalMsg : "";  // sirf pehle file ka caption
          const base64Data = await new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload  = () => resolve(reader.result.split(",")[1]);
            reader.onerror = reject;
            reader.readAsDataURL(attachFile);
          });
          const fileResult = await new Promise((resolve) => {
            chrome.tabs.sendMessage(waTab.id, {
              type:      "SEND_FILE",
              number,
              fileBase64: base64Data,
              fileMime:   attachFile.type || "application/octet-stream",
              caption:    fileCaption,
              filename:   attachFile.name,
              fileType:   attachFile.type.startsWith("image/") ? "image"
                        : attachFile.type === "application/pdf"  ? "document"
                        : attachFile.type.startsWith("video/")   ? "video"
                        : attachFile.type.startsWith("audio/")   ? "audio"
                        : "document",
            }, (resp) => resolve(resp || { success: true }));
          });
          // not_on_wa check — pehli file pe hi detect ho jaata hai
          if (fileResult && fileResult.not_on_wa) {
            fileNotOnWA = true;
            break;
          }
          if (fi < attachFiles.length - 1) await new Promise(r => setTimeout(r, 800)); // gap between files
        }
        if (fileNotOnWA) {
          addLogEntry(log, number, false, extra.name || "", "Not on WhatsApp ⚠️ Skipped");
          const _nowFileSkip = new Date();
          await msg("APPEND_SEND_LOG", { entry: {
            time: _nowFileSkip.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }),
            date: _nowFileSkip.toLocaleDateString("en-IN"),
            number, name: extra.name || "",
            status: "not_on_wa",
            error: "Number WhatsApp par registered nahi hai",
            source,
          }});
          continue;
        }
        await new Promise(r => setTimeout(r, 800));
      } else {
        // Sirf text message (koi attachment nahi)
        const result = await new Promise((resolve, reject) => {
          chrome.tabs.sendMessage(waTab.id, { type: "SEND_MESSAGE", number, message: finalMsg }, (response) => {
            if (chrome.runtime.lastError) {
              const errMsg = chrome.runtime.lastError.message || "";
              if (errMsg.includes("message channel closed") || errMsg.includes("Receiving end does not exist"))
                resolve({ success: true });
              else reject(new Error(errMsg));
            } else {
              resolve(response || { success: true });
            }
          });
        });
        // Check not_on_wa before checking generic failure
        if (result && result.not_on_wa) {
          addLogEntry(log, number, false, extra.name || "", "Not on WhatsApp ⚠️ Skipped");
          const _nowSkip = new Date();
          await msg("APPEND_SEND_LOG", { entry: {
            time: _nowSkip.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }),
            date: _nowSkip.toLocaleDateString("en-IN"),
            number,
            name: extra.name || "",
            status: "not_on_wa",
            error: "Number WhatsApp par registered nahi hai",
            source,
          }});
          continue;
        }
        if (result && result.success === false) throw new Error(result.error || "Send failed");
      }

      await msg("UPDATE_NUMBER", { data: { number, status: "Messaged" } });
      await refreshNumbers();
      addLogEntry(log, number, true, extra.name || "");
      // Persist to send log
      const _now = new Date();
      await msg("APPEND_SEND_LOG", { entry: {
        time: _now.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }),
        date: _now.toLocaleDateString("en-IN"),
        number,
        name: extra.name || "",
        status: "sent",
        source,
      }});

    } catch (err) {
      addLogEntry(log, number, false, extra.name || "", err.message);
      const _now2 = new Date();
      await msg("APPEND_SEND_LOG", { entry: {
        time: _now2.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }),
        date: _now2.toLocaleDateString("en-IN"),
        number,
        name: extra.name || "",
        status: "failed",
        error: err.message,
        source,
      }});
    }
  }
  toast(`Done sending messages ✅`);
}

function applyVariables(text, number, extra = {}) {
  const now = new Date();
  let result = text;

  // Dynamic column variables: {ColumnName} → value from that column
  // Replace ALL {SomeVar} patterns from extra object first (case-sensitive from sheet headers)
  if (extra && typeof extra === "object") {
    Object.entries(extra).forEach(([key, val]) => {
      if (key === "number" || key === "_raw") return;
      const regex = new RegExp(`\\{${key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\}`, "gi");
      result = result.replace(regex, val || "");
    });
  }

  // Built-in variables (also kept for legacy)
  result = result
    .replace(/\{NUMBER\}/gi, number)
    .replace(/\{DATE\}/gi,   now.toLocaleDateString())
    // Legacy fixed variables
    .replace(/\{NAME\}/gi,   extra.name || extra.Name || number)
    .replace(/\{CITY\}/gi,   extra.city || extra.City || "")
    // Double-brace legacy
    .replace(/\{\{name\}\}/gi,   extra.name || extra.Name || number)
    .replace(/\{\{number\}\}/gi, number)
    .replace(/\{\{date\}\}/gi,   now.toLocaleDateString());

  return result;
}

function addLogEntry(log, number, success, name = "", errMsg = "") {
  const entry = document.createElement("div");
  entry.className = "log-entry";
  const time = new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit",second:"2-digit"});
  const label = name ? `${escHtml(name)} (${escHtml(number)})` : escHtml(number);
  const isNotOnWA = !success && errMsg.includes("Not on WhatsApp");
  const icon  = success ? "✓" : (isNotOnWA ? "⚠️" : "✗");
  const cls   = success ? "log-ok" : (isNotOnWA ? "log-warn" : "log-fail");
  const statusTxt = success ? "Sent ✅" : (isNotOnWA ? "<span style='color:#f59e0b;font-weight:600'>Not on WhatsApp ⚠️ Skipped</span>" : "Failed: "+escHtml(errMsg));
  entry.innerHTML = `
    <span class="${cls}">${icon}</span>
    <span class="log-num">${label}</span>
    <span style="color:var(--text2);font-size:12px">${statusTxt}</span>
    <span class="log-time">${time}</span>
  `;
  log.prepend(entry);
}

// ─── GOOGLE SHEETS TAB ────────────────────────────────────────────────────

// Helper: extract sheet ID from any Google Sheets URL
function extractSheetId(url) {
  const m = url.match(/\/spreadsheets\/d\/([a-zA-Z0-9_-]+)/);
  return m ? m[1] : "";
}

// Helper: build CSV URL from sheetId + optional gid
function buildCsvUrl(sheetId, gid = "") {
  let url = `https://docs.google.com/spreadsheets/d/${sheetId}/pub?output=csv`;
  if (gid) url += `&gid=${gid}`;
  return url;
}

// Fetch sheet tabs from pubhtml page
async function fetchSheetTabs(sheetId) {
  try {
    const htmlUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/pubhtml`;
    const resp = await fetch(htmlUrl);
    if (!resp.ok) return [{ name: "Sheet1 (default)", gid: "0" }];
    const html = await resp.text();
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");

    const tabs = [];
    const seen = new Set();

    // Method 1: ol#sheet-menu li elements (most common pubhtml structure)
    doc.querySelectorAll("ol#sheet-menu li, ul#sheet-menu li").forEach(el => {
      const a = el.querySelector("a");
      const name = (a ? a.textContent : el.textContent).trim();
      // gid can be in data-id, id, or onclick attribute
      const idAttr = el.getAttribute("id") || "";
      const dataId = el.getAttribute("data-id") || "";
      const onclk  = el.getAttribute("onclick") || (a ? a.getAttribute("onclick") || "" : "");

      let gid = dataId;
      if (!gid) {
        const m = idAttr.match(/(\d+)$/) || onclk.match(/gid[=:]\s*['"]*(\d+)/);
        if (m) gid = m[1];
      }
      if (gid && !seen.has(gid) && name) {
        seen.add(gid);
        tabs.push({ name, gid });
      }
    });

    // Method 2: any li with id ending in digits (older pubhtml format)
    if (tabs.length === 0) {
      doc.querySelectorAll("li[id]").forEach(el => {
        const idVal = el.getAttribute("id") || "";
        const m = idVal.match(/(\d+)$/);
        if (m && !seen.has(m[1])) {
          const name = el.textContent.trim().replace(/\s+/g, " ");
          if (name) {
            seen.add(m[1]);
            tabs.push({ name, gid: m[1] });
          }
        }
      });
    }

    // Method 3: scan raw HTML for gid patterns in sheet nav links
    if (tabs.length === 0) {
      const gidNameRegex = /gid=(\d+)[^"]*"[^>]*>([^<]+)</g;
      let m;
      while ((m = gidNameRegex.exec(html)) !== null) {
        const [, gid, name] = m;
        const cleanName = name.trim();
        if (cleanName && !seen.has(gid)) {
          seen.add(gid);
          tabs.push({ name: cleanName, gid });
        }
      }
    }

    // Method 4: extract gid= from all anchor hrefs in nav area
    if (tabs.length === 0) {
      doc.querySelectorAll("a[href*='gid=']").forEach(a => {
        const m = a.href.match(/[?&]gid=(\d+)/);
        if (m && !seen.has(m[1])) {
          seen.add(m[1]);
          const name = a.textContent.trim() || `Tab ${tabs.length + 1}`;
          tabs.push({ name, gid: m[1] });
        }
      });
    }

    if (tabs.length === 0) {
      tabs.push({ name: "Sheet1 (default)", gid: "0" });
    }

    return tabs;
  } catch (e) {
    return [{ name: "Sheet1 (default)", gid: "0" }];
  }
}

// Render tab selector buttons
function renderTabSelector(tabs, activeGid) {
  const container = document.getElementById("gs-tab-buttons");
  const autoSection = document.getElementById("gs-tab-auto-section");

  if (tabs.length > 1) {
    autoSection.style.display = "block";
    container.innerHTML = "";
    tabs.forEach(tab => {
      const btn = document.createElement("button");
      btn.className = "gs-tab-btn" + (tab.gid === activeGid ? " active" : "");
      btn.textContent = tab.name;
      btn.dataset.gid = tab.gid;
      btn.addEventListener("click", () => loadTabByGid(tab.gid, tab.name));
      container.appendChild(btn);
    });
  } else {
    autoSection.style.display = "none";
  }
}

// Load sheet data by GID
async function loadTabByGid(gid, tabName = "") {
  if (!gsSheetId) { toast("Pehle sheet URL connect karo!"); return; }
  gsActiveGid = gid;
  const url = buildCsvUrl(gsSheetId, gid);
  showGsStatus(`⏳ Tab "${tabName || gid}" load ho rahi hai...`, "info");

  try {
    const csvText = await fetchGoogleSheet(url);
    const { headers, rows } = parseCSVText(csvText);
    if (!headers.length) throw new Error("Tab empty hai ya format galat hai");

    gsRawData = rows;
    gsHeaders = headers;

    // Update GID input field
    document.getElementById("gs-manual-gid").value = gid;

    // Re-render saved tabs to update active highlight + badge
    if (typeof renderSavedTabs === "function") renderSavedTabs();

    showGsStatus(`✅ Tab loaded: ${rows.length} rows, ${headers.length} columns`, "success");
    populateMappingSelects(headers);
    document.getElementById("gs-mapping-card").style.display = "block";
    document.getElementById("gs-count").textContent = rows.length;
    document.getElementById("gs-count").style.display = "inline";

    // If mapping already set, re-apply
    if (gsMapping.number && headers.includes(gsMapping.number)) {
      applyGsMapping();
      buildCascadingFilters();
      applyGsFilters();
    }

    toast(`"${tabName || gid}" loaded: ${rows.length} rows ✅`);
  } catch (err) {
    showGsStatus("❌ Error: " + err.message, "error");
    toast("Tab load failed: " + err.message);
  }
}

function parseCSVText(text) {
  const lines = text.trim().split("\n");
  if (!lines.length) return { headers: [], rows: [] };

  const parseRow = (line) => {
    const result = [];
    let cur = "", inQ = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (c === '"' && !inQ) { inQ = true; continue; }
      if (c === '"' && inQ && line[i+1] === '"') { cur += '"'; i++; continue; }
      if (c === '"' && inQ) { inQ = false; continue; }
      if (c === ',' && !inQ) { result.push(cur.trim()); cur = ""; continue; }
      cur += c;
    }
    result.push(cur.trim());
    return result;
  };

  const headers = parseRow(lines[0]);
  const rows = lines.slice(1).filter(l => l.trim()).map(line => {
    const vals = parseRow(line);
    const obj = {};
    headers.forEach((h, i) => { obj[h] = vals[i] || ""; });
    return obj;
  });

  return { headers, rows };
}

// v6.0: _checkSheetAccess removed — sheet block system nahi hai

async function fetchGoogleSheet(url) {
  try {
    const resp = await fetch(url);
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const text = await resp.text();
    return text;
  } catch (e) {
    throw new Error("Sheet fetch failed: " + e.message);
  }
}

// Populate ONLY number column selector + show all other cols as variables
function populateMappingSelects(headers) {
  const sel = document.getElementById("map-number");
  const prev = sel.value;
  sel.innerHTML = `<option value="">— Select Column —</option>`;
  headers.forEach(h => {
    sel.insertAdjacentHTML("beforeend", `<option value="${escHtml(h)}">${escHtml(h)}</option>`);
  });

  // Auto-detect number column
  const keywords = ["number","phone","mobile","contact","whatsapp","num","no","tel","mob"];
  const match = headers.find(h => keywords.some(k => h.toLowerCase().replace(/\s+/g,"").includes(k)));
  sel.value = prev && headers.includes(prev) ? prev : (match || "");

  // Show variable chips for all columns
  updateVariableChips(headers, sel.value);

  // On number column change, refresh variable chips
  sel.onchange = () => updateVariableChips(headers, sel.value);
}

function updateVariableChips(headers, numCol) {
  const otherCols = headers.filter(h => h !== numCol);
  const box   = document.getElementById("gs-vars-box");
  const chips = document.getElementById("gs-vars-chips");

  if (!otherCols.length) { box.style.display = "none"; return; }

  box.style.display = "block";
  chips.innerHTML = "";

  const allVars = [
    { label: "{NUMBER}", tip: "Phone number" },
    { label: "{DATE}", tip: "Aaj ki date" },
    ...otherCols.map(col => ({ label: `{${col}}`, tip: col }))
  ];

  // Mapping section chips (clipboard copy)
  allVars.forEach(v => chips.appendChild(makeVarChip(v.label, v.tip, "copy")));

  // Compose section chips (click to insert into textarea)
  updateComposeInsertChips(allVars);
}

function updateComposeInsertChips(allVars) {
  const composeChips = document.getElementById("gs-compose-var-chips");
  if (!composeChips) return;
  composeChips.innerHTML = "";

  const label = document.createElement("span");
  label.style.cssText = "font-size:11px;color:var(--text2);align-self:center;white-space:nowrap;margin-right:4px";
  label.textContent = "Insert:";
  composeChips.appendChild(label);

  allVars.forEach(v => {
    const chip = document.createElement("span");
    chip.className = "gs-var-chip";
    chip.textContent = v.label;
    chip.title = `Click to insert ${v.label} into message`;
    chip.style.cursor = "pointer";
    chip.addEventListener("click", () => {
      const ta = document.getElementById("gs-msg-text");
      const start = ta.selectionStart;
      const end   = ta.selectionEnd;
      const val   = ta.value;
      ta.value = val.slice(0, start) + v.label + val.slice(end);
      ta.selectionStart = ta.selectionEnd = start + v.label.length;
      ta.focus();
      document.getElementById("gs-msg-char").textContent = ta.value.length;
      updateGsPreview();

      // Flash feedback
      chip.classList.add("copied");
      const orig = chip.textContent;
      chip.textContent = "✓";
      setTimeout(() => { chip.classList.remove("copied"); chip.textContent = orig; }, 700);
    });
    composeChips.appendChild(chip);
  });
}

function makeVarChip(label, tip, mode = "copy") {
  const chip = document.createElement("span");
  chip.className = "gs-var-chip";
  chip.textContent = label;
  chip.title = mode === "copy" ? `Copy: ${label} — ${tip}` : `Insert: ${label}`;
  chip.addEventListener("click", () => {
    navigator.clipboard.writeText(label).catch(() => {});
    chip.classList.add("copied");
    chip.textContent = "✓ Copied!";
    setTimeout(() => { chip.classList.remove("copied"); chip.textContent = label; }, 1200);
  });
  return chip;
}

function applyGsMapping() {
  const numCol = document.getElementById("map-number").value;
  if (!numCol) { toast("Number column select karo!"); return false; }

  gsMapping = { number: numCol };
  gsAllColumns = gsHeaders.filter(h => h !== numCol);

  gsMappedData = gsRawData
    .map(row => {
      const entry = {
        number: (row[numCol] || "").replace(/[\s\-()+]/g, "").replace(/^0+/, ""),
        _raw: row,
      };
      // Keep every non-number column
      gsAllColumns.forEach(col => { entry[col] = row[col] || ""; });
      return entry;
    })
    .filter(r => {
      if (!r.number || !/^\d{7,15}$/.test(r.number.replace(/^\+/, ""))) return false;
      return true;
    });

  return true;
}

// Build cascading filters dynamically for ALL non-number columns
function buildCascadingFilters() {
  const container = document.getElementById("gs-dynamic-filters");
  container.innerHTML = "";

  gsAllColumns.forEach(col => {
    const uniqueVals = [...new Set(gsMappedData.map(r => r[col]).filter(Boolean))].sort();
    if (uniqueVals.length === 0) return;

    const group = document.createElement("div");
    group.className = "form-group";
    group.dataset.colGroup = col;

    const label = document.createElement("label");
    label.className = "gs-filter-col-label";
    label.textContent = col;

    const sel = document.createElement("select");
    sel.id = `gs-dyn-filter-${col.replace(/\s+/g, "_")}`;
    sel.dataset.col = col;
    sel.innerHTML = `<option value="">All ${escHtml(col)}</option>`;
    uniqueVals.forEach(v => {
      sel.insertAdjacentHTML("beforeend", `<option value="${escHtml(v)}">${escHtml(v)}</option>`);
    });
    sel.addEventListener("change", applyGsFilters);

    group.appendChild(label);
    group.appendChild(sel);
    container.appendChild(group);
  });
}

// True cascading: after each change, recalculate options for downstream filters
function refreshCascadingOptions() {
  const selects = [...document.querySelectorAll("#gs-dynamic-filters select[data-col]")];
  const q = (document.getElementById("gs-search")?.value || "").toLowerCase().trim();

  selects.forEach((sel, idx) => {
    const col = sel.dataset.col;
    const current = sel.value;

    // Build base data: apply only filters BEFORE this one (upstream filters)
    const upstreamFilters = selects.slice(0, idx).filter(s => s.value);
    const baseData = gsMappedData.filter(r => {
      for (const upSel of upstreamFilters) {
        if (r[upSel.dataset.col] !== upSel.value) return false;
      }
      if (q && !Object.values(r).some(v => String(v).toLowerCase().includes(q))) return false;
      return true;
    });

    const vals = [...new Set(baseData.map(r => r[col]).filter(Boolean))].sort();
    sel.innerHTML = `<option value="">All ${escHtml(col)}</option>`;
    vals.forEach(v => {
      sel.insertAdjacentHTML("beforeend",
        `<option value="${escHtml(v)}"${v === current ? " selected" : ""}>${escHtml(v)}</option>`
      );
    });

    // If previously selected value no longer available, clear it
    if (current && !vals.includes(current)) {
      sel.value = "";
    }
  });
}

function applyGsFilters() {
  const q = (document.getElementById("gs-search")?.value || "").toLowerCase().trim();
  const colFilters = {};
  document.querySelectorAll("#gs-dynamic-filters select[data-col]").forEach(sel => {
    if (sel.value) colFilters[sel.dataset.col] = sel.value;
  });

  gsFiltered = gsMappedData.filter(r => {
    for (const [col, val] of Object.entries(colFilters)) {
      if (r[col] !== val) return false;
    }
    if (q) {
      const allVals = [r.number, ...gsAllColumns.map(c => r[c] || "")];
      if (!allVals.some(v => v.toLowerCase().includes(q))) return false;
    }
    return true;
  });

  refreshCascadingOptions();
  renderGsTable();
  updateGsSelectionSummary();
  updateFilterSummaryBar(colFilters, q);
}

// Show active filter pills in the collapsed summary bar
function updateFilterSummaryBar(colFilters, q) {
  const activeCount = Object.keys(colFilters).length + (q ? 1 : 0);

  // Badge on title
  const badge = document.getElementById("gs-filter-active-count");
  if (badge) {
    if (activeCount > 0) {
      badge.textContent = `${activeCount} active`;
      badge.style.display = "inline";
    } else {
      badge.style.display = "none";
    }
  }

  // Active filter pills shown below summary when collapsed
  const pillsBox = document.getElementById("gs-filter-pills");
  if (!pillsBox) return;
  pillsBox.innerHTML = "";
  if (activeCount === 0) { pillsBox.style.display = "none"; return; }
  pillsBox.style.display = "flex";

  Object.entries(colFilters).forEach(([col, val]) => {
    const pill = document.createElement("span");
    pill.className = "gs-filter-pill";
    pill.innerHTML = `<strong>${escHtml(col)}:</strong> ${escHtml(val)}
      <span class="gs-pill-clear" data-col="${escHtml(col)}" title="Clear">✕</span>`;
    pillsBox.appendChild(pill);
  });
  if (q) {
    const pill = document.createElement("span");
    pill.className = "gs-filter-pill";
    pill.innerHTML = `<strong>Search:</strong> ${escHtml(q)}
      <span class="gs-pill-clear" data-search="1" title="Clear">✕</span>`;
    pillsBox.appendChild(pill);
  }

  // Clear individual pill
  pillsBox.querySelectorAll(".gs-pill-clear").forEach(x => {
    x.addEventListener("click", () => {
      if (x.dataset.search) {
        document.getElementById("gs-search").value = "";
      } else {
        const selId = `gs-dyn-filter-${x.dataset.col.replace(/\s+/g, "_")}`;
        const sel = document.getElementById(selId);
        if (sel) sel.value = "";
      }
      applyGsFilters();
    });
  });
}

// Dynamic table — shows all columns from sheet
function renderGsTable() {
  const head  = document.getElementById("gs-table-head");
  const tbody = document.getElementById("gs-table-body");
  document.getElementById("gs-filtered-count").textContent = gsFiltered.length;

  // Build dynamic header
  head.innerHTML = `<tr>
    <th><input type="checkbox" id="gs-check-all" /></th>
    <th>📱 ${escHtml(gsMapping.number || "Number")}</th>
    ${gsAllColumns.map(col => `<th>${escHtml(col)}</th>`).join("")}
    <th>Action</th>
  </tr>`;

  // Re-attach check-all listener
  document.getElementById("gs-check-all").addEventListener("change", function() {
    if (this.checked) gsFiltered.forEach(r => gsSelected.add(r.number));
    else gsFiltered.forEach(r => gsSelected.delete(r.number));
    renderGsTable();
    updateGsSelectionSummary();
  });

  if (!gsFiltered.length) {
    tbody.innerHTML = `<tr><td colspan="${gsAllColumns.length + 3}" style="text-align:center;padding:32px;color:var(--text2)">Koi contact nahi mila. Filters change karo.</td></tr>`;
    return;
  }

  tbody.innerHTML = gsFiltered.map(r => `
    <tr data-gsnum="${escHtml(r.number)}" class="${gsSelected.has(r.number) ? "selected" : ""}">
      <td><input type="checkbox" class="gs-row-check" data-num="${escHtml(r.number)}" ${gsSelected.has(r.number) ? "checked" : ""} /></td>
      <td class="phone-cell">${escHtml(r.number)}</td>
      ${gsAllColumns.map(col => `<td title="${escHtml(r[col] || "")}">${escHtml(r[col] ? (r[col].length > 30 ? r[col].slice(0,30)+"…" : r[col]) : "—")}</td>`).join("")}
      <td style="white-space:nowrap">
        <button class="btn btn-sm btn-secondary gs-chat-btn" data-num="${escHtml(r.number)}" title="WhatsApp Chat Kholo" style="margin-right:3px">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
        </button>
        <button class="btn btn-sm btn-secondary gs-edit-btn" data-num="${escHtml(r.number)}" title="Edit karke Sheet mein save karo" style="margin-right:3px">✏️</button>
        <button class="btn btn-sm btn-danger gs-delete-btn" data-num="${escHtml(r.number)}" title="Delete karke Sheet se bhi hatao">🗑️</button>
      </td>
    </tr>
  `).join("");

  tbody.querySelectorAll(".gs-row-check").forEach(cb => {
    cb.addEventListener("change", () => {
      if (cb.checked) gsSelected.add(cb.dataset.num);
      else gsSelected.delete(cb.dataset.num);
      const row = tbody.querySelector(`tr[data-gsnum="${cb.dataset.num}"]`);
      if (row) row.classList.toggle("selected", cb.checked);
      updateGsSelectionSummary();
    });
  });

  // Chat button
  tbody.querySelectorAll(".gs-chat-btn").forEach(btn => {
    btn.addEventListener("click", async (e) => {
      e.preventDefault(); e.stopPropagation();
      const num = btn.dataset.num;
      const waTabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
      if (waTabs.length > 0) {
        await chrome.tabs.update(waTabs[0].id, { active: true });
        chrome.tabs.sendMessage(waTabs[0].id, { type: "OPEN_CHAT", number: num });
      } else {
        chrome.tabs.create({ url: `https://web.whatsapp.com/send?phone=${num}` });
      }
    });
  });

  // ── ✏️ Edit button → modal open karo ──────────────────────────────────────
  tbody.querySelectorAll(".gs-edit-btn").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.preventDefault(); e.stopPropagation();
      const num = btn.dataset.num;
      const record = gsMappedData.find(r => r.number === num);
      if (record) openGsEditModal(record);
    });
  });

  // ── 🗑️ Delete button → extension + sheet dono se delete ──────────────────
  tbody.querySelectorAll(".gs-delete-btn").forEach(btn => {
    btn.addEventListener("click", async (e) => {
      e.preventDefault(); e.stopPropagation();
      const num = btn.dataset.num;
      if (!confirm(`"${num}" ko extension aur Google Sheet dono se delete karo?`)) return;
      btn.disabled = true; btn.textContent = "⏳";
      try {
        await gsDeleteRowAndSync(num);
        toast(`✅ ${num} delete ho gaya — extension + sheet dono se`);
      } catch(err) {
        toast("❌ Delete failed: " + err.message);
        btn.disabled = false; btn.textContent = "🗑️";
      }
    });
  });
}

// ─── GS Row Delete: extension + sheet dono se ────────────────────────────
async function gsDeleteRowAndSync(number) {
  // 1) Extension ka local data hatao
  gsMappedData = gsMappedData.filter(r => r.number !== number);
  gsRawData    = gsRawData.filter(r => {
    const n = (r[gsMapping.number] || "").replace(/[\s\-()+]/g, "").replace(/^0+/, "");
    return n !== number;
  });
  gsSelected.delete(number);
  applyGsFilters();
  updateGsSelectionSummary();

  // 2) Sheet se bhi delete karo
  try {
    const scriptUrl = await getScriptUrl(gsActiveGid);
    if (scriptUrl && gsSheetId) {
      const { tabConfigs } = await loadSyncConfig();
      const cfg = tabConfigs[gsActiveGid] || {};
      const numCol = cfg.numCol || gsMapping.number || "";
      await syncDeleteFromSheet(gsSheetId, gsActiveGid, scriptUrl, number, numCol);
    }
  } catch(e) {
    console.warn("[WA Sync] Sheet delete failed:", e.message);
    throw e;
  }
}

// ─── GS Edit Modal ────────────────────────────────────────────────────────
function openGsEditModal(record) {
  // Purana modal remove karo agar exist karta hai
  const old = document.getElementById("gs-edit-modal-overlay");
  if (old) old.remove();

  const numCol = gsMapping.number || "";
  const allCols = numCol ? [numCol, ...gsAllColumns] : gsAllColumns;

  const overlay = document.createElement("div");
  overlay.id = "gs-edit-modal-overlay";
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9999;display:flex;align-items:center;justify-content:center";

  // Raw data se values lo (original unmodified values)
  const rawRecord = record._raw || record;

  overlay.innerHTML = `
    <div style="background:var(--bg);border-radius:14px;padding:28px;width:420px;max-width:95vw;max-height:85vh;overflow-y:auto;box-shadow:0 8px 40px rgba(0,0,0,.3)">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px">
        <h3 style="margin:0;font-size:16px">✏️ Row Edit karo</h3>
        <button id="gs-edit-close" style="background:none;border:none;font-size:20px;cursor:pointer;color:var(--text2)">✕</button>
      </div>
      <div id="gs-edit-fields">
        ${allCols.map(col => `
          <div style="margin-bottom:12px">
            <label style="font-size:12px;font-weight:600;color:var(--text2);display:block;margin-bottom:4px">${escHtml(col)}</label>
            <input type="text" class="gs-edit-field" data-col="${escHtml(col)}"
              value="${escHtml((rawRecord[col] !== undefined && rawRecord[col] !== null) ? String(rawRecord[col]) : (record[col] || ""))}"
              style="width:100%;padding:8px 10px;border:1px solid var(--border);border-radius:8px;background:var(--bg2);color:var(--text);font-size:13px;box-sizing:border-box" />
          </div>
        `).join("")}
      </div>
      <div style="display:flex;gap:8px;margin-top:18px">
        <button id="gs-edit-save" class="btn btn-primary" style="flex:1">💾 Save &amp; Sheet Update karo</button>
        <button id="gs-edit-cancel" class="btn btn-secondary" style="flex:1">Cancel</button>
      </div>
      <div id="gs-edit-status" style="margin-top:10px;font-size:12px;text-align:center"></div>
    </div>
  `;

  document.body.appendChild(overlay);

  const close = () => overlay.remove();
  document.getElementById("gs-edit-close").onclick = close;
  document.getElementById("gs-edit-cancel").onclick = close;
  overlay.addEventListener("click", e => { if (e.target === overlay) close(); });

  document.getElementById("gs-edit-save").addEventListener("click", async () => {
    const saveBtn   = document.getElementById("gs-edit-save");
    const statusEl  = document.getElementById("gs-edit-status");
    saveBtn.disabled = true; saveBtn.textContent = "⏳ Saving...";

    // Naya data collect karo
    const newData = {};
    overlay.querySelectorAll(".gs-edit-field").forEach(inp => {
      newData[inp.dataset.col] = inp.value.trim();
    });

    const oldNumber = record.number;
    const newNumber = numCol ? (newData[numCol] || "").replace(/[\s\-()+]/g, "").replace(/^0+/, "") : oldNumber;

    try {
      // 1) Extension ka local data update karo
      const rawIdx = gsRawData.findIndex(r => {
        const n = (r[numCol] || "").replace(/[\s\-()+]/g, "").replace(/^0+/, "");
        return n === oldNumber;
      });
      if (rawIdx >= 0) {
        // Raw data update karo (original column names se)
        allCols.forEach(col => {
          if (newData[col] !== undefined) gsRawData[rawIdx][col] = newData[col];
        });
      }

      // Re-apply mapping aur filters
      if (gsMapping.number) {
        applyGsMapping();
        buildCascadingFilters();
        applyGsFilters();
      }

      // 2) Sheet mein update karo
      const scriptUrl = await getScriptUrl(gsActiveGid);
      if (!scriptUrl || !gsSheetId) {
        statusEl.style.color = "#f59e0b";
        statusEl.textContent = "⚠️ Extension update hua. Sheet Script URL missing — sheet update nahi hua.";
        saveBtn.disabled = false; saveBtn.textContent = "💾 Save & Sheet Update karo";
        return;
      }

      const { tabConfigs } = await loadSyncConfig();
      const cfg    = tabConfigs[gsActiveGid] || {};
      const numColName = cfg.numCol || gsMapping.number || "";

      await syncUpdateInSheet(gsSheetId, gsActiveGid, scriptUrl, oldNumber, newData, numColName);

      statusEl.style.color = "#10b981";
      statusEl.textContent = "✅ Extension + Sheet dono update ho gaye!";
      toast("✅ Row updated — extension + sheet dono mein");
      setTimeout(close, 1200);

    } catch(err) {
      statusEl.style.color = "#ef4444";
      statusEl.textContent = "❌ Error: " + err.message;
      saveBtn.disabled = false; saveBtn.textContent = "💾 Save & Sheet Update karo";
    }
  });
}

// ─── Add New Row Modal ────────────────────────────────────────────────────
function openGsAddModal() {
  const old = document.getElementById("gs-add-modal-overlay");
  if (old) old.remove();

  const numCol = gsMapping.number || "";
  const allCols = numCol ? [numCol, ...gsAllColumns] : gsAllColumns;
  if (allCols.length === 0) { toast("Pehle sheet connect karo aur mapping set karo"); return; }

  const overlay = document.createElement("div");
  overlay.id = "gs-add-modal-overlay";
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9999;display:flex;align-items:center;justify-content:center";

  overlay.innerHTML = `
    <div style="background:var(--bg);border-radius:14px;padding:28px;width:420px;max-width:95vw;max-height:85vh;overflow-y:auto;box-shadow:0 8px 40px rgba(0,0,0,.3)">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px">
        <h3 style="margin:0;font-size:16px">➕ Naya Contact Add karo</h3>
        <button id="gs-add-close" style="background:none;border:none;font-size:20px;cursor:pointer;color:var(--text2)">✕</button>
      </div>
      <div id="gs-add-fields">
        ${allCols.map(col => `
          <div style="margin-bottom:12px">
            <label style="font-size:12px;font-weight:600;color:var(--text2);display:block;margin-bottom:4px">${escHtml(col)}${col === numCol ? " <span style='color:#ef4444'>*</span>" : ""}</label>
            <input type="text" class="gs-add-field" data-col="${escHtml(col)}"
              placeholder="${col === numCol ? "Country code ke saath (e.g. 919876543210)" : ""}"
              style="width:100%;padding:8px 10px;border:1px solid var(--border);border-radius:8px;background:var(--bg2);color:var(--text);font-size:13px;box-sizing:border-box" />
          </div>
        `).join("")}
      </div>
      <div style="display:flex;gap:8px;margin-top:18px">
        <button id="gs-add-save" class="btn btn-primary" style="flex:1">➕ Add &amp; Sheet mein Save karo</button>
        <button id="gs-add-cancel" class="btn btn-secondary" style="flex:1">Cancel</button>
      </div>
      <div id="gs-add-status" style="margin-top:10px;font-size:12px;text-align:center"></div>
    </div>
  `;

  document.body.appendChild(overlay);

  const close = () => overlay.remove();
  document.getElementById("gs-add-close").onclick = close;
  document.getElementById("gs-add-cancel").onclick = close;
  overlay.addEventListener("click", e => { if (e.target === overlay) close(); });

  document.getElementById("gs-add-save").addEventListener("click", async () => {
    const saveBtn  = document.getElementById("gs-add-save");
    const statusEl = document.getElementById("gs-add-status");

    const newData = {};
    overlay.querySelectorAll(".gs-add-field").forEach(inp => {
      newData[inp.dataset.col] = inp.value.trim();
    });

    // Number validate karo
    const rawNum = numCol ? (newData[numCol] || "") : "";
    const cleanNum = rawNum.replace(/[\s\-()+]/g, "").replace(/^0+/, "");
    if (numCol && !cleanNum) {
      statusEl.style.color = "#ef4444";
      statusEl.textContent = "❌ Number zaroori hai!";
      return;
    }

    // Duplicate check
    if (gsMappedData.find(r => r.number === cleanNum)) {
      statusEl.style.color = "#f59e0b";
      statusEl.textContent = "⚠️ Yeh number pehle se exist karta hai!";
      return;
    }

    saveBtn.disabled = true; saveBtn.textContent = "⏳ Saving...";

    try {
      // 1) Extension mein add karo
      gsRawData.push({ ...newData });
      if (gsMapping.number) {
        applyGsMapping();
        buildCascadingFilters();
        applyGsFilters();
      }

      // 2) Sheet mein append karo
      const scriptUrl = await getScriptUrl(gsActiveGid);
      if (!scriptUrl || !gsSheetId) {
        statusEl.style.color = "#f59e0b";
        statusEl.textContent = "⚠️ Extension mein add hua. Sheet Script URL missing — sheet update nahi hua.";
        saveBtn.disabled = false; saveBtn.textContent = "➕ Add & Sheet mein Save karo";
        return;
      }

      const { tabConfigs } = await loadSyncConfig();
      const cfg = tabConfigs[gsActiveGid] || {};
      const numColName = cfg.numCol || gsMapping.number || "";

      await syncAppendToSheet(gsSheetId, gsActiveGid, scriptUrl, newData, numColName);

      statusEl.style.color = "#10b981";
      statusEl.textContent = "✅ Contact add ho gaya — extension + sheet dono mein!";
      toast("✅ Naya contact add hua — extension + sheet dono mein");
      setTimeout(close, 1200);

    } catch(err) {
      statusEl.style.color = "#ef4444";
      statusEl.textContent = "❌ Error: " + err.message;
      saveBtn.disabled = false; saveBtn.textContent = "➕ Add & Sheet mein Save karo";
    }
  });
}

function updateGsSelectionSummary() {
  const count = gsSelected.size;
  document.getElementById("gs-selected-count").textContent = count;
  document.getElementById("gs-send-total").textContent = count;
  document.getElementById("gs-send-btn-count").textContent = count;
  document.getElementById("gs-btn-send").disabled = count === 0;
}

// Live preview with dynamic variables from all columns
function updateGsPreview() {
  const text = document.getElementById("gs-msg-text").value;
  const previewBox  = document.getElementById("gs-preview-box");
  const previewInfo = document.getElementById("gs-preview-info");

  if (!text.trim()) {
    previewBox.innerHTML = `<div class="gs-preview-empty">Message likhne par yahan preview dikhega...</div>`;
    previewInfo.textContent = "";
    return;
  }

  let sample = gsFiltered.find(r => gsSelected.has(r.number)) || gsFiltered[0] || null;
  let previewText, infoText;

  if (sample) {
    previewText = applyVariables(text, sample.number, sample);
    const displayName = gsAllColumns.length > 0 ? (sample[gsAllColumns[0]] || sample.number) : sample.number;
    infoText = `Preview: ${displayName}`;
  } else {
    previewText = applyVariables(text, "+91XXXXXXXXXX", { Name: "Rahul", City: "Surat" });
    infoText = "Preview (sample data)";
  }

  previewBox.innerHTML = `<div class="gs-preview-bubble">${escHtml(previewText).replace(/\n/g,"<br>")}</div>`;
  previewInfo.textContent = infoText;
}

function updateComposeVarsHint() {
  const hint = document.getElementById("gs-compose-vars-hint");
  if (hint) hint.textContent = "";  // chips replace the hint now
  const allVars = [
    { label: "{NUMBER}", tip: "Phone number" },
    { label: "{DATE}", tip: "Aaj ki date" },
    ...gsAllColumns.map(c => ({ label: `{${c}}`, tip: c }))
  ];
  updateComposeInsertChips(allVars);
}

function showGsStatus(text, type = "info") {
  const el = document.getElementById("gs-status");
  el.style.display = "block";
  el.className = `gs-status gs-status-${type}`;
  el.textContent = text;
}

// Render saved tab buttons — module scope so loadTabByGid can call it
function renderSavedTabs() {
  const list     = document.getElementById("gs-saved-tabs-list");
  if (!list) return;
  const emptyMsg = document.getElementById("gs-tabs-empty-msg");
  const badge    = document.getElementById("gs-active-tab-badge");

  list.querySelectorAll(".gs-tab-btn").forEach(b => b.remove());

  if (gsSheetTabs.length === 0) {
    if (emptyMsg) emptyMsg.style.display = "inline";
    if (badge) badge.style.display = "none";
    return;
  }
  if (emptyMsg) emptyMsg.style.display = "none";

  gsSheetTabs.forEach(tab => {
    const btn = document.createElement("button");
    const isActive = tab.gid === gsActiveGid;
    btn.className = "gs-tab-btn" + (isActive ? " active" : "");
    btn.innerHTML = `<span>${escHtml(tab.name)}</span>
      <span style="font-size:10px;opacity:0.55;margin-left:4px">${tab.gid}</span>
      <span class="gs-tab-remove" data-gid="${escHtml(tab.gid)}" title="Remove">✕</span>`;
    btn.addEventListener("click", (e) => {
      if (e.target.classList.contains("gs-tab-remove")) return;
      loadTabByGid(tab.gid, tab.name).then(() => {
        chrome.storage.local.set({ gsActiveGid: tab.gid, gsSheetTabs });
      });
    });
    list.appendChild(btn);

    if (isActive && badge) {
      badge.textContent = tab.name;
      badge.style.display = "inline";
    }
  });

  list.querySelectorAll(".gs-tab-remove").forEach(x => {
    x.addEventListener("click", (e) => {
      e.stopPropagation();
      gsSheetTabs = gsSheetTabs.filter(t => t.gid !== x.dataset.gid);
      renderSavedTabs();
      chrome.storage.local.set({ gsSheetTabs });
    });
  });
}

function initGoogleSheetsTab() {
  // ── Save/Load helpers using chrome.storage.local ─────────────────────────
  function saveGsState() {
    chrome.storage.local.set({
      gsSheetUrl,
      gsSheetTabs,
      gsActiveGid,
      gsMapping,
      gsSheetId,
    });
    msSaveAllSheets();  // multi-sheet tabs sync

    // v6.0: updateSheetUrl removed — sheet block system nahi hai
  }

  // ── Auto-restore on open ─────────────────────────────────────────────────
  chrome.storage.local.get(["gsSheetUrl","gsSheetTabs","gsActiveGid","gsMapping","gsSheetId","wa_subscription_session","SCRIPT_URL"], async (data) => {
    if (!data.gsSheetUrl) return; // nothing saved

    // v6.0: sheet_block check removed

    // Restore state
    gsSheetUrl  = data.gsSheetUrl;
    gsSheetId   = data.gsSheetId || extractSheetId(gsSheetUrl);
    gsSheetTabs = data.gsSheetTabs || [];
    gsActiveGid = data.gsActiveGid || "";
    if (data.gsMapping) gsMapping = data.gsMapping;

    document.getElementById("gs-url").value = gsSheetUrl;

    // Show tab card with saved tabs
    if (gsSheetTabs.length > 0) {
      document.getElementById("gs-tab-card").style.display = "block";
      renderSavedTabs();
    }

    // Auto-load the last active tab data
    const gid  = gsActiveGid;
    const tab  = gsSheetTabs.find(t => t.gid === gid);
    const url  = buildCsvUrl(gsSheetId, gid);
    showGsStatus("⏳ Last session restore ho rahi hai...", "info");

    try {
      const csvText = await fetchGoogleSheet(url);
      const { headers, rows } = parseCSVText(csvText);
      if (!headers.length) throw new Error("empty");

      gsRawData = rows;
      gsHeaders = headers;

      showGsStatus(`✅ Auto-restored: ${rows.length} rows${tab ? " — " + tab.name : ""}`, "success");
      document.getElementById("gs-count").textContent = rows.length;
      document.getElementById("gs-count").style.display = "inline";

      populateMappingSelects(headers);
      document.getElementById("gs-mapping-card").style.display = "block";

      // Re-apply mapping if saved
      if (gsMapping.number && headers.includes(gsMapping.number)) {
        document.getElementById("map-number").value = gsMapping.number;
        applyGsMapping();
        buildCascadingFilters();
        applyGsFilters();
        document.getElementById("gs-filter-card").style.display = "block";
        document.getElementById("gs-table-container").style.display = "block";
        document.getElementById("gs-compose-card").style.display = "block";
        updateComposeVarsHint();
      }
    } catch(e) {
      showGsStatus("⚠️ Auto-restore failed — Connect button dabao", "error");
    }
  });

  // ── Connect button ──────────────────────────────────────────────────────
  document.getElementById("gs-btn-connect").addEventListener("click", async () => {
    const rawUrl = document.getElementById("gs-url").value.trim();
    if (!rawUrl) { toast("Sheet URL daalo!"); return; }
    if (!rawUrl.includes("docs.google.com")) {
      toast("Google Sheet URL hona chahiye");
      return;
    }

    gsSheetId = extractSheetId(rawUrl);
    if (!gsSheetId) { toast("Valid Google Sheet URL nahi hai"); return; }

    // ✅ Sheet Block Check — connect se pehle server verify karo
    // v6.0: sheet block check removed

    // Build proper CSV url (use existing gid if present in URL, else default)
    const existingGid = rawUrl.match(/[?&]gid=(\d+)/)?.[1] || "";
    gsActiveGid = existingGid;
    gsSheetUrl  = rawUrl.includes("output=csv") ? rawUrl : buildCsvUrl(gsSheetId, existingGid);

    showGsStatus("⏳ Sheet fetch ho rahi hai...", "info");

    try {
      const csvText = await fetchGoogleSheet(gsSheetUrl);
      const { headers, rows } = parseCSVText(csvText);
      if (!headers.length) throw new Error("Sheet empty hai ya format galat hai");

      gsRawData = rows;
      gsHeaders = headers;

      saveGsState();

      showGsStatus(`✅ Connected! ${rows.length} rows, ${headers.length} columns mili.`, "success");

      // Update active sheet tab name badge
      const _activeBadge = document.getElementById("ms-active-sheet-name");
      if (_activeBadge && msSheets[msActiveIdx]) {
        _activeBadge.textContent = "— " + msSheets[msActiveIdx].name;
      }
      populateMappingSelects(headers);

      document.getElementById("gs-mapping-card").style.display = "block";
      document.getElementById("gs-count").textContent = rows.length;
      document.getElementById("gs-count").style.display = "inline";

      // Fetch tabs in background
      showGsStatus(`✅ ${rows.length} rows. Sheet tabs detect ho rahi hain...`, "success");

      // Always show tab card (useful for manual GID entry with /e/ URLs)
      document.getElementById("gs-tab-card").style.display = "block";

      // Try to detect tabs (works for /d/ URLs, may not work for /e/ URLs)
      fetchSheetTabs(gsSheetId).then(tabs => {
        gsSheetTabs = tabs;
        if (tabs.length > 1) {
          renderTabSelector(tabs, gsActiveGid || "0");
          document.getElementById("gs-active-tab-name").textContent =
            tabs.find(t => t.gid === gsActiveGid)?.name || "Default";
          showGsStatus(`✅ ${rows.length} rows | ${tabs.length} tabs mili — neeche tab select karo`, "success");
        } else {
          // /e/ URL — tabs auto detect nahi hoti, show helper message
          document.getElementById("gs-active-tab-name").textContent = "Default Tab (GID: 0)";
          showGsStatus(`✅ ${rows.length} rows loaded. Agar multiple tabs hain toh neeche GID manually daalo.`, "success");
        }
      });

      toast(`Sheet connected! ${rows.length} rows.`);
    } catch (err) {
      showGsStatus("❌ Error: " + err.message, "error");
      toast("Sheet fetch failed: " + err.message);
    }
  });

  // ── Refresh ─────────────────────────────────────────────────────────────
  document.getElementById("gs-btn-refresh").addEventListener("click", async () => {
    if (!gsSheetUrl) { toast("Pehle sheet connect karo!"); return; }

    // v6.0: sheet block check removed

    showGsStatus("⏳ Refreshing...", "info");
    try {
      const csvText = await fetchGoogleSheet(gsSheetUrl);
      const { headers, rows } = parseCSVText(csvText);
      gsRawData = rows;
      gsHeaders = headers;
      if (gsMapping.number) {
        applyGsMapping();
        buildCascadingFilters();
        applyGsFilters();
      } else {
        populateMappingSelects(headers);
      }
      showGsStatus(`✅ Refreshed! ${rows.length} rows.`, "success");
      toast("Data refreshed ✅");
    } catch (err) {
      toast("Refresh failed: " + err.message);
    }
  });

  // ── Tab card collapsible ────────────────────────────────────────────────
  document.getElementById("gs-tab-card-title").addEventListener("click", () => {
    const body  = document.getElementById("gs-tab-card-body");
    const arrow = document.getElementById("gs-tab-card-arrow");
    const isOpen = body.style.display !== "none";
    body.style.display = isOpen ? "none" : "block";
    arrow.textContent  = isOpen ? "▶" : "▼";
  });

  // ── Add + Load tab ───────────────────────────────────────────────────────
  document.getElementById("gs-btn-add-tab").addEventListener("click", () => {
    const gid  = document.getElementById("gs-manual-gid").value.trim();
    const name = document.getElementById("gs-tab-name-input").value.trim() || `Tab (${gid})`;
    if (!gid) { toast("GID number daalo!"); return; }

    // Add to list if not already there
    if (!gsSheetTabs.find(t => t.gid === gid)) {
      gsSheetTabs.push({ name, gid });
      renderSavedTabs();
    }
    // Load the tab data
    loadTabByGid(gid, name).then(() => saveGsState());
  });

  // ── Apply Mapping ────────────────────────────────────────────────────────
  document.getElementById("gs-btn-apply-mapping").addEventListener("click", () => {
    if (!applyGsMapping()) return;

    saveGsState();

    buildCascadingFilters();
    applyGsFilters();
    updateComposeVarsHint();

    document.getElementById("gs-filter-card").style.display = "block";
    document.getElementById("gs-table-container").style.display = "block";
    document.getElementById("gs-compose-card").style.display = "block";

    toast(`${gsMappedData.length} valid contacts loaded ✅`);
  });

  // ── Collapsible Filter Card ───────────────────────────────────────────────
  document.getElementById("gs-filter-toggle").addEventListener("click", (e) => {
    // Don't toggle if clicking buttons inside summary
    if (e.target.tagName === "BUTTON") return;
    const body = document.getElementById("gs-filter-body");
    const arrow = document.getElementById("gs-filter-arrow");
    const isOpen = body.style.display !== "none";
    body.style.display = isOpen ? "none" : "block";
    arrow.textContent = isOpen ? "▶" : "▼";
  });

  document.getElementById("gs-collapse-filters").addEventListener("click", () => {
    document.getElementById("gs-filter-body").style.display = "none";
    document.getElementById("gs-filter-arrow").textContent = "▶";
  });

  document.getElementById("gs-clear-filters").addEventListener("click", () => {
    document.querySelectorAll("#gs-dynamic-filters select[data-col]").forEach(sel => sel.value = "");
    document.getElementById("gs-search").value = "";
    applyGsFilters();
    toast("Filters clear ho gaye ✅");
  });

  // ── Search ───────────────────────────────────────────────────────────────
  document.getElementById("gs-search").addEventListener("input", applyGsFilters);

  // ── Select All Filtered ──────────────────────────────────────────────────
  document.getElementById("gs-select-all-filtered").addEventListener("click", () => {
    gsFiltered.forEach(r => gsSelected.add(r.number));
    renderGsTable();
    updateGsSelectionSummary();
  });

  // ── Deselect All ─────────────────────────────────────────────────────────
  document.getElementById("gs-deselect-all").addEventListener("click", () => {
    gsSelected.clear();
    renderGsTable();
    updateGsSelectionSummary();
  });

  // ── ➕ Add Row button ─────────────────────────────────────────────────────
  document.getElementById("gs-btn-add-row").addEventListener("click", () => {
    openGsAddModal();
  });

  // ── ⬇️ Pull from Sheet button — sheet se latest data khicho ──────────────
  document.getElementById("gs-btn-pull-sheet").addEventListener("click", async () => {
    const btn = document.getElementById("gs-btn-pull-sheet");
    btn.disabled = true; btn.textContent = "⏳ Pulling...";
    try {
      const scriptUrl = await getScriptUrl(gsActiveGid);
      if (!scriptUrl || !gsSheetId) throw new Error("Script URL ya Sheet ID missing. Sync Settings mein configure karo.");

      // v6.0: sheet block check removed

      const result = await syncReadFromSheet(gsSheetId, gsActiveGid, scriptUrl);
      if (result.rows && result.rows.length > 0) {
        gsRawData = result.rows;
        if (gsMapping.number) {
          applyGsMapping();
          buildCascadingFilters();
          applyGsFilters();
        }
        toast(`✅ Sheet se ${result.rows.length} rows pull ho gayi`);
      } else {
        toast("Sheet mein koi data nahi mila");
      }
    } catch(err) {
      toast("❌ Pull failed: " + err.message);
    } finally {
      btn.disabled = false; btn.textContent = "⬇️ Pull from Sheet";
    }
  });


  document.getElementById("gs-template-select").addEventListener("change", function () {
    const t = templates.find(t => t.id === this.value);
    if (t) document.getElementById("gs-msg-text").value = t.text;
    updateGsPreview();
  });

  // ── Message text ─────────────────────────────────────────────────────────
  document.getElementById("gs-msg-text").addEventListener("input", () => {
    document.getElementById("gs-msg-char").textContent = document.getElementById("gs-msg-text").value.length;
    updateGsPreview();
  });

  // ── GS Attachment box ────────────────────────────────────────────────────
  window._gsAttachFile = null;

  function clearGsAttachment() {
    window._gsAttachFile  = null;
    window._gsAttachFiles = [];
    document.getElementById("gs-attach-input").value = "";
    document.getElementById("gs-attach-placeholder").style.display = "flex";
    document.getElementById("gs-attach-preview").style.display = "none";
    document.getElementById("gs-attach-caption-group").style.display = "none";
    document.getElementById("gs-attach-box").style.borderColor = "#d1d5db";
  }

  document.getElementById("gs-attach-box").addEventListener("click", () => {
    document.getElementById("gs-attach-input").click();
  });

  document.getElementById("gs-attach-clear").addEventListener("click", (e) => {
    e.stopPropagation();
    clearGsAttachment();
  });

  document.getElementById("gs-attach-input").addEventListener("change", function () {
    const files = Array.from(this.files);
    if (!files.length) return;
    window._gsAttachFiles = files;
    document.getElementById("gs-attach-placeholder").style.display = "none";
    const preview = document.getElementById("gs-attach-preview");
    preview.style.display = "flex";
    if (files.length === 1) {
      const file = files[0];
      document.getElementById("gs-attach-name").textContent =
        file.name + " (" + (file.size > 1024*1024
          ? (file.size/1024/1024).toFixed(1) + "MB"
          : Math.round(file.size/1024) + "KB") + ")";
    } else {
      const totalSize = files.reduce((s, f) => s + f.size, 0);
      document.getElementById("gs-attach-name").textContent =
        files.length + " files selected (" + (totalSize > 1024*1024
          ? (totalSize/1024/1024).toFixed(1) + "MB"
          : Math.round(totalSize/1024) + "KB") + ")";
    }
    document.getElementById("gs-attach-caption-group").style.display = "block";
    document.getElementById("gs-attach-box").style.borderColor = "#16a34a";
  });

  // ── Send button ──────────────────────────────────────────────────────────
  document.getElementById("gs-btn-send").addEventListener("click", async () => {
    const text = document.getElementById("gs-msg-text").value.trim();
    if (!text) { toast("Message likhna zaroori hai!"); return; }
    if (!gsSelected.size) { toast("Koi contact select nahi hai!"); return; }

    const targets = [...gsSelected];
    const extraMap = {};
    gsMappedData.forEach(r => { extraMap[r.number] = r; });

    const log = document.getElementById("gs-send-log");
    log.querySelector(".log-empty")?.remove();
    gsSentCount = 0; gsFailedCount = 0;
    document.getElementById("gs-send-sent").textContent = 0;
    document.getElementById("gs-send-failed").textContent = 0;

    const minD = Number(document.getElementById("gs-delay-min").value || 3) * 1000;
    const maxD = Number(document.getElementById("gs-delay-max").value || 8) * 1000;

    const tabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
    if (!tabs.length) { toast("WhatsApp Web pehle kholna hoga!"); return; }
    const waTab = tabs[0];

    toast(`${targets.length} contacts ko message bhej raha hoon...`);
    document.getElementById("gs-btn-send").disabled = true;

    for (const number of targets) {
      const extra = extraMap[number] || {};
      const finalMsg = applyVariables(text, number, extra);

      try {
        const delay = minD + Math.random() * (maxD - minD);
        await new Promise(r => setTimeout(r, delay));

        // ── Attachment agar select hai to text ko caption bana do ──
        const gsAttachFiles = window._gsAttachFiles && window._gsAttachFiles.length
          ? window._gsAttachFiles
          : (window._gsAttachFile ? [window._gsAttachFile] : []);

        if (gsAttachFiles.length > 0) {
          let gsFileNotOnWA = false;
          for (let fi = 0; fi < gsAttachFiles.length; fi++) {
            const gsAttachFile = gsAttachFiles[fi];
            const fileCaption = fi === 0 ? finalMsg : "";
            const base64Data = await new Promise((resolve, reject) => {
              const reader = new FileReader();
              reader.onload  = () => resolve(reader.result.split(",")[1]);
              reader.onerror = reject;
              reader.readAsDataURL(gsAttachFile);
            });
            const gsFileResult = await new Promise((resolve) => {
              chrome.tabs.sendMessage(waTab.id, {
                type:       "SEND_FILE",
                number,
                fileBase64: base64Data,
                fileMime:   gsAttachFile.type || "application/octet-stream",
                caption:    fileCaption,
                filename:   gsAttachFile.name,
                fileType:   gsAttachFile.type.startsWith("image/") ? "image"
                          : gsAttachFile.type === "application/pdf"  ? "document"
                          : gsAttachFile.type.startsWith("video/")   ? "video"
                          : gsAttachFile.type.startsWith("audio/")   ? "audio"
                          : "document",
              }, (resp) => resolve(resp || { success: true }));
            });
            if (gsFileResult && gsFileResult.not_on_wa) {
              gsFileNotOnWA = true;
              break;
            }
            if (fi < gsAttachFiles.length - 1) await new Promise(r => setTimeout(r, 800));
          }
          if (gsFileNotOnWA) {
            gsFailedCount++;
            document.getElementById("gs-send-failed").textContent = gsFailedCount;
            const displayNameSkipF = gsAllColumns.length > 0 ? (extra[gsAllColumns[0]] || "") : "";
            addGsLogEntry(log, number, false, displayNameSkipF, "Not on WhatsApp ⚠️ Skipped");
            const _gsSkipF = new Date();
            await msg("APPEND_SEND_LOG", { entry: {
              time: _gsSkipF.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }),
              date: _gsSkipF.toLocaleDateString("en-IN"),
              number, name: displayNameSkipF,
              status: "not_on_wa",
              error: "Number WhatsApp par registered nahi hai",
              source: "sheet",
            }});
            continue;
          }
          await new Promise(r => setTimeout(r, 800));
        } else {
          // Sirf text message
          const result = await new Promise((resolve, reject) => {
            chrome.tabs.sendMessage(waTab.id, { type: "SEND_MESSAGE", number, message: finalMsg }, (response) => {
              if (chrome.runtime.lastError) {
                const errMsg = chrome.runtime.lastError.message || "";
                if (errMsg.includes("message channel closed") || errMsg.includes("Receiving end does not exist"))
                  resolve({ success: true });
                else reject(new Error(errMsg));
              } else {
                resolve(response || { success: true });
              }
            });
          });
          // not_on_wa check for Google Sheets send
          if (result && result.not_on_wa) {
            gsFailedCount++;
            document.getElementById("gs-send-failed").textContent = gsFailedCount;
            const displayNameSkip = gsAllColumns.length > 0 ? (extra[gsAllColumns[0]] || "") : "";
            addGsLogEntry(log, number, false, displayNameSkip, "Not on WhatsApp ⚠️ Skipped");
            const _gsSkipNow = new Date();
            await msg("APPEND_SEND_LOG", { entry: {
              time: _gsSkipNow.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }),
              date: _gsSkipNow.toLocaleDateString("en-IN"),
              number,
              name: displayNameSkip,
              status: "not_on_wa",
              error: "Number WhatsApp par registered nahi hai",
              source: "sheet",
            }});
            continue;
          }
          if (result && result.success === false) throw new Error(result.error || "Send failed");
        }

        gsSentCount++;
        document.getElementById("gs-send-sent").textContent = gsSentCount;
        // Use first non-number column as display name
        const displayName = gsAllColumns.length > 0 ? (extra[gsAllColumns[0]] || "") : "";
        addGsLogEntry(log, number, true, displayName);
        // Persist to send log
        const _gsNow = new Date();
        await msg("APPEND_SEND_LOG", { entry: {
          time: _gsNow.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }),
          date: _gsNow.toLocaleDateString("en-IN"),
          number,
          name: displayName,
          status: "sent",
          source: "sheet",
        }});

      } catch (err) {
        gsFailedCount++;
        document.getElementById("gs-send-failed").textContent = gsFailedCount;
        addGsLogEntry(log, number, false, "", err.message);
        const _gsNow2 = new Date();
        await msg("APPEND_SEND_LOG", { entry: {
          time: _gsNow2.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }),
          date: _gsNow2.toLocaleDateString("en-IN"),
          number,
          name: "",
          status: "failed",
          error: err.message,
          source: "sheet",
        }});
      }
    }

    document.getElementById("gs-btn-send").disabled = false;
    toast(`Done! ✅ Sent: ${gsSentCount} | Failed: ${gsFailedCount}`);
  });

  // ── Clear log ────────────────────────────────────────────────────────────
  document.getElementById("btn-download-gs-report").addEventListener("click", async () => {
    // GS log div se entries lo + storage se bhi sheet entries lo
    const res = await msg("GET_SEND_LOG");
    const log = (res.log || []).filter(e => e.source === "sheet");
    const date = new Date().toLocaleDateString("en-IN").replace(/\//g, "-");
    if (log.length) {
      downloadReportCSV(log, `WA_GoogleSheets_Report_${date}.csv`);
    } else {
      // Fallback: live DOM se download
      downloadLiveLogCSV("gs-send-log", `WA_GoogleSheets_Report_${date}.csv`);
    }
    toast("✅ Google Sheets Report download ho rahi hai!");
  });

  document.getElementById("gs-clear-log").addEventListener("click", () => {
    const log = document.getElementById("gs-send-log");
    log.innerHTML = `<div class="log-empty">Koi message abhi tak nahi bheja.</div>`;
    gsSentCount = 0; gsFailedCount = 0;
    document.getElementById("gs-send-sent").textContent = 0;
    document.getElementById("gs-send-failed").textContent = 0;
  });
}

function addGsLogEntry(log, number, success, name = "", errMsg = "") {
  const entry = document.createElement("div");
  entry.className = "log-entry";
  const time = new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit",second:"2-digit"});
  const label = name ? `${escHtml(name)} (${escHtml(number)})` : escHtml(number);
  const isNotOnWA = !success && errMsg.includes("Not on WhatsApp");
  const icon = success ? "✓" : (isNotOnWA ? "⚠️" : "✗");
  const cls  = success ? "log-ok" : (isNotOnWA ? "log-warn" : "log-fail");
  const statusTxt = success ? "Sent ✅" : (isNotOnWA ? "<span style='color:#f59e0b;font-weight:600'>Not on WhatsApp ⚠️ Skipped</span>" : "Failed: "+escHtml(errMsg));
  entry.innerHTML = `
    <span class="${cls}">${icon}</span>
    <span class="log-num">${label}</span>
    <span style="color:var(--text2);font-size:12px">${statusTxt}</span>
    <span class="log-time">${time}</span>
  `;
  log.prepend(entry);
}


// ─── Templates Tab ────────────────────────────────────────────────────────
function renderTemplates() {
  const grid = document.getElementById("template-grid");
  grid.innerHTML = templates.map(t => `
    <div class="template-card" data-id="${t.id}">
      <div class="template-name">${escHtml(t.name)}</div>
      <div class="template-preview">${escHtml(t.text)}</div>
      <div class="template-actions">
        <button class="btn btn-sm btn-secondary tmpl-edit" data-id="${t.id}">Edit</button>
        <button class="btn btn-sm btn-danger tmpl-delete" data-id="${t.id}">Delete</button>
      </div>
    </div>
  `).join("");

  grid.querySelectorAll(".tmpl-edit").forEach(btn => {
    btn.addEventListener("click", () => {
      const t = templates.find(t => t.id === btn.dataset.id);
      openTemplateModal(t);
    });
  });
  grid.querySelectorAll(".tmpl-delete").forEach(btn => {
    btn.addEventListener("click", async () => {
      if (!confirm("Delete this template?")) return;
      templates = templates.filter(t => t.id !== btn.dataset.id);
      await msg("SAVE_TEMPLATES", { templates });
      renderTemplates();
      syncTemplateSelects();
      toast("Template deleted.");
    });
  });
}

function openTemplateModal(t = null) {
  templateEditId = t ? t.id : null;
  document.getElementById("modal-title").textContent = t ? "Edit Template" : "New Template";
  document.getElementById("tmpl-name").value = t ? t.name : "";
  document.getElementById("tmpl-text").value = t ? t.text : "";
  document.getElementById("template-modal").classList.add("open");
}

function initTemplatesTab() {
  document.getElementById("btn-add-template").addEventListener("click", () => openTemplateModal());

  const close = () => document.getElementById("template-modal").classList.remove("open");
  document.getElementById("modal-close").addEventListener("click", close);
  document.getElementById("modal-cancel").addEventListener("click", close);
  document.getElementById("template-modal").addEventListener("click", e => { if(e.target===e.currentTarget) close(); });

  document.getElementById("modal-save").addEventListener("click", async () => {
    const name = document.getElementById("tmpl-name").value.trim();
    const text = document.getElementById("tmpl-text").value.trim();
    if (!name || !text) { toast("Please fill in all fields."); return; }

    if (templateEditId) {
      const idx = templates.findIndex(t => t.id === templateEditId);
      if (idx >= 0) templates[idx] = { ...templates[idx], name, text };
    } else {
      templates.unshift({ id: "t" + Date.now(), name, text });
    }

    await msg("SAVE_TEMPLATES", { templates });
    renderTemplates();
    syncTemplateSelects();
    close();
    toast("Template saved ✅");
  });
}

function syncTemplateSelects() {
  const selects = [
    document.getElementById("msg-template-select"),
    document.getElementById("schedule-template"),
    document.getElementById("gs-template-select"),
    document.getElementById("bc-template-select"),
  ];
  selects.forEach(sel => {
    if (!sel) return;
    const curr = sel.value;
    sel.innerHTML = templates.map(t =>
      `<option value="${t.id}"${t.id===curr?" selected":""}>${escHtml(t.name)}</option>`
    ).join("");
    if (sel.id === "msg-template-select" || sel.id === "gs-template-select" || sel.id === "bc-template-select") {
      sel.insertAdjacentHTML("afterbegin", `<option value="">— Use Custom Message —</option>`);
    }
  });
}

// ─── Schedule Tab ─────────────────────────────────────────────────────────
function populateScheduleSheetTabs() {
  // Always read fresh from storage to get latest tabs
  chrome.storage.local.get(["gsSheetTabs", "gsActiveGid", "gsSheetId", "gsSheetUrl", "msSheets", "msActiveIdx"], (data) => {
    // Multi-sheet: build combined tab list from all configured sheets
    let tabs = [];
    if (data.msSheets && data.msSheets.length > 0) {
      data.msSheets.forEach(s => {
        if (s.sheetId) {
          tabs.push({ name: s.name, gid: s.activeGid || "0", sheetId: s.sheetId, msIdx: s.id });
        }
      });
    }
    if (tabs.length === 0) tabs = data.gsSheetTabs || gsSheetTabs || [];
    const sheetSel = document.getElementById("schedule-sheet-tab");
    const targetSel = document.getElementById("schedule-target");
    const sheetOption = document.getElementById("schedule-target-sheet");

    if (!sheetSel || !sheetOption) return;

    // Save current selection before clearing
    const prevGid = sheetSel.value || (schedule && schedule.sheetGid) || data.gsActiveGid || "";

    // Clear existing options
    sheetSel.innerHTML = "";

    if (tabs.length > 0) {
      // Show "Google Sheet numbers" option in Target dropdown
      sheetOption.style.display = "";
      tabs.forEach(tab => {
        const opt = document.createElement("option");
        opt.value = tab.gid;
        opt.textContent = tab.name || ("Sheet " + tab.gid);
        sheetSel.appendChild(opt);
      });
      // Restore previously saved tab selection
      if (prevGid) sheetSel.value = prevGid;

      // Store sheet metadata for background.js
      if (data.gsSheetId) {
        chrome.storage.local.set({
          scheduleSheetId: data.gsSheetId,
          scheduleSheetUrl: data.gsSheetUrl || ""
        });
      }
    } else {
      // No sheet loaded — hide the option and reset target if needed
      sheetOption.style.display = "none";
      const opt = document.createElement("option");
      opt.value = "";
      opt.textContent = "-- No sheet loaded --";
      sheetSel.appendChild(opt);
      if (targetSel && targetSel.value === "sheet") {
        targetSel.value = "all";
        toggleSheetTabSelector();
      }
    }
  });
}

function toggleSheetTabSelector() {
  const target = document.getElementById("schedule-target").value;
  const group = document.getElementById("schedule-sheet-select-group");
  group.style.display = target === "sheet" ? "block" : "none";

  if (target === "sheet") {
    // Show live count from gsSelected (in-memory) or from storage
    const infoBox  = document.getElementById("schedule-selected-info");
    const warnBox  = document.getElementById("schedule-no-selection-warn");
    const countEl  = document.getElementById("schedule-selected-count");

    const liveCount = (typeof gsSelected !== "undefined") ? gsSelected.size : 0;

    if (liveCount > 0) {
      countEl.textContent = liveCount;
      infoBox.style.display = "block";
      warnBox.style.display = "none";
    } else {
      // Check storage for previously saved selection
      chrome.storage.local.get(["scheduleSelectedNumbers"], (data) => {
        const saved = (data.scheduleSelectedNumbers || []).length;
        if (saved > 0) {
          countEl.textContent = saved;
          infoBox.style.display = "block";
          warnBox.style.display = "none";
        } else {
          infoBox.style.display = "none";
          warnBox.style.display = "block";
        }
      });
    }
  }
}

function initScheduleTab() {
  document.getElementById("schedule-enabled").addEventListener("change", function () {
    document.getElementById("schedule-form").style.opacity = this.checked ? "1" : "0.5";
    document.getElementById("sched-indicator").className = "status-indicator " + (this.checked ? "active" : "inactive");
    document.getElementById("sched-status-text").textContent = this.checked ? "Scheduler enabled" : "Scheduler disabled";
  });

  // Show/hide sheet tab selector when target changes
  document.getElementById("schedule-target").addEventListener("change", toggleSheetTabSelector);

  // ── Scheduler Attachment event listeners ──
  document.getElementById("sched-attach-box").addEventListener("click", () => {
    document.getElementById("sched-attach-input").click();
  });

  document.getElementById("sched-attach-clear").addEventListener("click", (e) => {
    e.stopPropagation();
    clearSchedAttachment();
  });

  document.getElementById("sched-attach-input").addEventListener("change", function () {
    const files = Array.from(this.files);
    if (!files.length) return;
    window._schedAttachFiles = files;
    document.getElementById("sched-attach-placeholder").style.display = "none";
    const preview = document.getElementById("sched-attach-preview");
    preview.style.display = "flex";
    if (files.length === 1) {
      const file = files[0];
      document.getElementById("sched-attach-name").textContent =
        file.name + " (" + (file.size > 1024*1024
          ? (file.size/1024/1024).toFixed(1) + "MB"
          : Math.round(file.size/1024) + "KB") + ")";
    } else {
      const totalSize = files.reduce((s, f) => s + f.size, 0);
      document.getElementById("sched-attach-name").textContent =
        files.length + " files selected (" + (totalSize > 1024*1024
          ? (totalSize/1024/1024).toFixed(1) + "MB"
          : Math.round(totalSize/1024) + "KB") + ")";
    }
    document.getElementById("sched-attach-caption-group").style.display = "block";
    document.getElementById("sched-attach-box").style.borderColor = "#16a34a";
  });

  document.getElementById("btn-save-schedule").addEventListener("click", async () => {
    const target = document.getElementById("schedule-target").value;
    const sheetGid = document.getElementById("schedule-sheet-tab").value;
    const saveBtn = document.getElementById("btn-save-schedule");

    if (target === "sheet") {
      // Validate: gsSelected must have numbers selected
      if (!gsSelected || gsSelected.size === 0) {
        toast("⚠️ Pehle Google Sheets tab mein numbers SELECT karo, phir Save karo!");
        return;
      }
      // Save full contact data (number + ALL columns) for background.js template replacement
      const selectedArr = [...gsSelected];
      // Build full contact objects: { number, ...allColumns }
      const selectedContacts = gsMappedData.filter(r => gsSelected.has(r.number));
      chrome.storage.local.get(["gsSheetId"], (data) => {
        if (data.gsSheetId) {
          const csvUrl = `https://docs.google.com/spreadsheets/d/${data.gsSheetId}/export?format=csv&gid=${sheetGid}`;
          chrome.storage.local.set({
            scheduleSheetCsvUrl: csvUrl,
            scheduleSheetGid: sheetGid,
            scheduleSelectedNumbers: selectedArr,
            scheduleContactData: selectedContacts   // ← full row data with ALL columns
          });
        }
      });
    }

    // Schedule save karne se pehle files ko base64 mein convert karo
    // (blob URL background service worker mein kaam nahi karta)
    const schedFiles = window._schedAttachFiles && window._schedAttachFiles.length
      ? window._schedAttachFiles
      : (window._schedAttachFile ? [window._schedAttachFile] : []);

    let schedAttachments = []; // array of {fileBase64, fileMime, fileFilename}
    for (const f of schedFiles) {
      const b64 = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload  = () => resolve(reader.result.split(",")[1]);
        reader.onerror = reject;
        reader.readAsDataURL(f);
      });
      schedAttachments.push({ fileBase64: b64, fileMime: f.type || "application/octet-stream", fileFilename: f.name });
    }
    // Backward-compat: keep single-file fields too (background.js uses these)
    const schedFileBase64   = schedAttachments.length ? schedAttachments[0].fileBase64 : "";
    const schedFileMime     = schedAttachments.length ? schedAttachments[0].fileMime   : "";
    const schedFileFilename = schedAttachments.length ? schedAttachments[0].fileFilename : "";

    await msg("SAVE_SCHEDULE", { schedule: {
      enabled:  document.getElementById("schedule-enabled").checked,
      time:     document.getElementById("schedule-time").value,
      template: document.getElementById("schedule-template").value,
      limit:    Number(document.getElementById("schedule-limit").value),
      target:   target,
      sheetGid: sheetGid,
      // ── Attachment fields (base64 stored, blob URL nahi) ──
      fileBase64:   schedFileBase64,
      fileMime:     schedFileMime,
      fileFilename: schedFileFilename,
      fileCaption:  "",
      fileType:     schedAttachments.length ? "auto-detect" : "",
      // ── Multiple attachments array ──
      attachments:  schedAttachments,
    }});

    // Disable button and show saved confirmation below it
    saveBtn.disabled = true;
    saveBtn.textContent = "✅ Saved";
    saveBtn.style.opacity = "0.7";
    saveBtn.style.cursor = "default";

    // Show saved message below the buttons
    let savedMsg = document.getElementById("schedule-saved-msg");
    if (!savedMsg) {
      savedMsg = document.createElement("div");
      savedMsg.id = "schedule-saved-msg";
      savedMsg.style.cssText = "margin-top:10px;padding:10px 14px;border-radius:8px;background:#f0fdf4;border:1px solid #bbf7d0;color:#166534;font-size:13px;font-weight:500;";
      document.querySelector(".form-actions").insertAdjacentElement("afterend", savedMsg);
    }
    const schedTime = document.getElementById("schedule-time").value;
    const numCount = target === "sheet" ? gsSelected.size : "sab";
    savedMsg.innerHTML = `✅ <strong>Schedule save ho gaya!</strong> — Har roz <strong>${schedTime}</strong> baje <strong>${numCount}</strong> numbers ko message jayega.`;
    savedMsg.style.display = "block";

    // Re-enable button after 3 seconds
    setTimeout(() => {
      saveBtn.disabled = false;
      saveBtn.textContent = "Save Schedule";
      saveBtn.style.opacity = "";
      saveBtn.style.cursor = "";
    }, 3000);

    toast(target === "sheet" ? `✅ Schedule + ${gsSelected.size} selected numbers saved!` : "Schedule saved ✅");
  });

  document.getElementById("btn-run-now").addEventListener("click", async () => {
    const runBtn = document.getElementById("btn-run-now");
    runBtn.disabled = true;
    runBtn.textContent = "⏳ Sending...";

    toast("⏳ Messages bheje ja rahe hain... WhatsApp Web mein dekho");
    await msg("MANUAL_SCHEDULED_SEND");

    // Live polling: update log every 2s for up to 60s while background is sending
    let pollCount = 0;
    const maxPolls = 30;
    const liveInterval = setInterval(async () => {
      await loadSendLog();
      pollCount++;
      if (pollCount >= maxPolls) {
        clearInterval(liveInterval);
        runBtn.disabled = false;
        runBtn.textContent = "Run Now";
        toast("✅ Sending complete!");
      }
    }, 2000);
  });

  document.getElementById("btn-clear-log").addEventListener("click", async () => {
    await msg("CLEAR_SEND_LOG");
    renderSendLog([]);
    toast("Log clear ho gaya ✅");
  });

  document.getElementById("btn-download-schedule-report").addEventListener("click", async () => {
    const res = await msg("GET_SEND_LOG");
    // Sirf scheduled source ki entries CSV mein
    const log = (res.log || []).filter(e => e.type === "summary" || e.source === "scheduled");
    if (!log.length) { toast("Koi Schedule log nahi hai download karne ke liye!"); return; }
    const date = new Date().toLocaleDateString("en-IN").replace(/\//g, "-");
    downloadReportCSV(log, `WA_Schedule_Report_${date}.csv`);
    toast("✅ Schedule Report download ho rahi hai!");
  });

  // Populate sheet tabs on init
  populateScheduleSheetTabs();
}

async function loadSendLog() {
  const res = await msg("GET_SEND_LOG");
  // Scheduler tab mein sirf "scheduled" source ke entries dikhao
  const filtered = (res.log || []).filter(e =>
    e.type === "summary" || e.source === "scheduled"
  );
  renderSendLog(filtered);
}

// ─── Download Report as CSV ────────────────────────────────────────────────
function downloadReportCSV(log, filename) {
  const rows = [["Date", "Time", "Name", "Number", "Status", "Source", "Error"]];
  log.forEach(entry => {
    if (entry.type === "summary") return;
    rows.push([
      entry.date || "",
      entry.time || "",
      entry.name || "",
      entry.number || "",
      entry.status || "",
      entry.source || "",
      entry.error || "",
    ]);
  });
  const csv = rows.map(r => r.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function downloadLiveLogCSV(logDivId, filename) {
  const logDiv = document.getElementById(logDivId);
  if (!logDiv) return;
  const entries = logDiv.querySelectorAll(".log-entry");
  if (!entries.length) { toast("Koi log nahi hai download karne ke liye!"); return; }
  const rows = [["Time", "Name / Number", "Status", "Error"]];
  entries.forEach(el => {
    const time = el.querySelector(".log-time")?.textContent?.trim() || "";
    const num = el.querySelector(".log-num")?.textContent?.trim() || "";
    const isOk = !!el.querySelector(".log-ok");
    const status = isOk ? "Sent" : "Failed";
    const allText = el.textContent || "";
    const errMatch = allText.match(/Failed: (.+)/);
    const error = errMatch ? errMatch[1].trim() : "";
    rows.push([time, num, status, error]);
  });
  const csv = rows.map(r => r.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function renderSendLog(log) {
  const emptyEl = document.getElementById("schedule-log-empty");
  const listEl  = document.getElementById("schedule-log-list");

  if (!log || log.length === 0) {
    emptyEl.style.display = "block";
    listEl.style.display  = "none";
    return;
  }

  emptyEl.style.display = "none";
  listEl.style.display  = "block";

  const sourceLabel = { scheduled: "⏰ Schedule", manual: "✍️ Manual", unsaved: "👤 Unsaved", saved: "💾 Saved", sheet: "📊 Sheet" };

  listEl.innerHTML = log.map(entry => {
    if (entry.type === "summary") {
      const failed = (entry.total || 0) - (entry.sent || 0);
      return `<div style="padding:10px 12px;margin:6px 0;border-radius:8px;background:#f0fdf4;border:1px solid #bbf7d0;font-size:13px">
        <strong>📊 Run Summary</strong> — ${entry.date ? entry.date + " " : ""}${entry.time}<br>
        <span style="color:#16a34a">✅ Sent: ${entry.sent || 0}</span> &nbsp;|&nbsp;
        <span style="color:#dc2626">❌ Failed: ${failed}</span> &nbsp;|&nbsp;
        Total: ${entry.total || 0}
      </div>`;
    }
    const isSent = entry.status === "sent";
    const icon   = isSent ? "✅" : "❌";
    const color  = isSent ? "#166534" : "#991b1b";
    const bg     = isSent ? "#f0fdf4" : "#fef2f2";
    const border = isSent ? "#bbf7d0" : "#fecaca";
    const nameStr = entry.name ? `<span style="font-weight:600">${escHtml(entry.name)}</span> — ` : "";
    const errStr  = entry.error ? `<br><span style="color:#dc2626;font-size:11px">Error: ${escHtml(entry.error)}</span>` : "";
    const srcBadge = entry.source ? `<span style="font-size:10px;background:#e0e7ff;color:#3730a3;border-radius:4px;padding:1px 5px;margin-left:4px">${sourceLabel[entry.source] || entry.source}</span>` : "";
    const dateStr = (entry.date || "") + (entry.date && entry.time ? " " : "") + (entry.time || "");
    return `<div style="padding:8px 12px;margin:4px 0;border-radius:8px;background:${bg};border:1px solid ${border};font-size:13px;color:${color}">
      ${icon} ${nameStr}${escHtml(entry.number || "")}${srcBadge}
      <span style="float:right;font-size:11px;color:#888">${dateStr}</span>
      ${errStr}
    </div>`;
  }).join("");
}

async function loadSchedule() {
  const res = await msg("GET_SCHEDULE");
  schedule = res.schedule || {};
  document.getElementById("schedule-enabled").checked = !!schedule.enabled;
  document.getElementById("schedule-time").value    = schedule.time || "09:00";
  document.getElementById("schedule-limit").value   = schedule.limit || 50;
  document.getElementById("schedule-target").value  = schedule.target || "all";

  const formEl = document.getElementById("schedule-form");
  formEl.style.opacity = schedule.enabled ? "1" : "0.5";
  document.getElementById("sched-indicator").className = "status-indicator " + (schedule.enabled ? "active" : "inactive");
  document.getElementById("sched-status-text").textContent = schedule.enabled
    ? `Scheduler active — sends at ${schedule.time || "09:00"} daily`
    : "Scheduler disabled";

  setTimeout(() => {
    const sel = document.getElementById("schedule-template");
    if (schedule.template) sel.value = schedule.template;
    // Restore sheet tab selection
    if (schedule.sheetGid) {
      const sheetSel = document.getElementById("schedule-sheet-tab");
      if (sheetSel) sheetSel.value = schedule.sheetGid;
    }
    toggleSheetTabSelector();
  }, 100);
}

// ─── Settings Tab ─────────────────────────────────────────────────────────
// ─── Message Send History Stats ──────────────────────────────────────────
async function loadMessageStats() {
  const res = await msg("GET_SEND_LOG");
  const log = (res.log || []).filter(e => e.type !== "summary" && e.status === "sent");

  const todayStr = new Date().toLocaleDateString("en-IN");

  const total      = log.length;
  const todayTotal = log.filter(e => e.date === todayStr).length;

  const unsaved      = log.filter(e => e.source === "unsaved" || (!e.source && e.status === "sent")).length;
  const unsavedToday = log.filter(e => (e.source === "unsaved" || !e.source) && e.date === todayStr).length;

  const saved      = log.filter(e => e.source === "saved").length;
  const savedToday = log.filter(e => e.source === "saved" && e.date === todayStr).length;

  const sheet      = log.filter(e => e.source === "sheet").length;
  const sheetToday = log.filter(e => e.source === "sheet" && e.date === todayStr).length;

  const scheduled      = log.filter(e => e.source === "scheduled").length;
  const scheduledToday = log.filter(e => e.source === "scheduled" && e.date === todayStr).length;

  const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
  set("stat-sent-total",       total);
  set("stat-sent-today",       todayTotal);
  set("stat-unsaved-total",    unsaved);
  set("stat-unsaved-today",    unsavedToday);
  set("stat-saved-total",      saved);
  set("stat-saved-today",      savedToday);
  set("stat-sheet-total",      sheet);
  set("stat-sheet-today",      sheetToday);
  set("stat-scheduled-total",  scheduled);
  set("stat-scheduled-today",  scheduledToday);
}

function initSettingsTab() {
  document.getElementById("btn-save-settings").addEventListener("click", async () => {
    const s = {
      darkMode:             document.getElementById("set-dark").checked,
      notificationsEnabled: document.getElementById("set-notifications").checked,
      autoDetect:           document.getElementById("set-autodetect").checked,
      dailyLimit:           Number(document.getElementById("set-daily-limit").value),
      minDelay:             Number(document.getElementById("set-min-delay").value),
      maxDelay:             Number(document.getElementById("set-max-delay").value),
    };
    await msg("SAVE_SETTINGS", { settings: s });
    applyDark(s.darkMode);
    toast("Settings saved ✅");
  });

  document.getElementById("set-dark").addEventListener("change", function () {
    applyDark(this.checked);
  });

  document.getElementById("btn-backup").addEventListener("click", async () => {
    const { numbers } = await msg("GET_ALL_NUMBERS");
    const tmpls = templates;
    const blob  = new Blob([JSON.stringify({ numbers, templates: tmpls, exportedAt: new Date().toISOString() }, null, 2)], { type: "application/json" });
    const a     = Object.assign(document.createElement("a"), { href: URL.createObjectURL(blob), download: `wa_backup_${Date.now()}.json` });
    a.click();
    toast("Backup downloaded ✅");
  });

  document.getElementById("btn-restore").addEventListener("click", () => {
    document.getElementById("restore-file").click();
  });
  document.getElementById("restore-file").addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const data = JSON.parse(await file.text());
    if (data.numbers) {
      await msg("IMPORT_NUMBERS", { numbers: data.numbers });
      await refreshNumbers();
    }
    if (data.templates) {
      templates = data.templates;
      await msg("SAVE_TEMPLATES", { templates });
      renderTemplates();
      syncTemplateSelects();
    }
    toast("Backup restored ✅");
    e.target.value = "";
  });

  // ── Script URL Save ──────────────────────────────────────────────────────
  document.getElementById("btn-save-script-url").addEventListener("click", async () => {
    const url    = document.getElementById("set-script-url").value.trim();
    const status = document.getElementById("set-script-url-status");
    if (!url) {
      status.style.color = "#ef4444";
      status.textContent = "❌ URL daalna zaroori hai";
      return;
    }
    if (!url.includes("script.google.com")) {
      status.style.color = "#f59e0b";
      status.textContent = "⚠️ Yeh Google Apps Script URL nahi lagta. Phir bhi save kar raha hoon...";
    }
    await chrome.storage.local.set({ SCRIPT_URL: url });
    status.style.color = "#10b981";
    status.textContent = "✅ Script URL save ho gaya! Ab Edit/Add/Delete sab sheet mein sync hoga.";
    toast("✅ Script URL saved!");
  });

  // ── Script URL Test ──────────────────────────────────────────────────────
  document.getElementById("btn-test-script-url").addEventListener("click", async () => {
    const url    = document.getElementById("set-script-url").value.trim();
    const status = document.getElementById("set-script-url-status");
    if (!url) { status.style.color = "#ef4444"; status.textContent = "❌ Pehle URL daalo"; return; }
    status.style.color = "#6366f1"; status.textContent = "⏳ Testing connection...";
    try {
      const resp = await fetch(`${url}?action=getAllTabs&sheetId=test&t=${Date.now()}`);
      const data = await resp.json();
      // getAllTabs sheetId missing error dega — but connection work kar raha hai
      if (data.ok === false && data.error && data.error.includes("sheetId")) {
        status.style.color = "#10b981";
        status.textContent = "✅ Connection successful! Script URL sahi hai.";
      } else if (data.ok) {
        status.style.color = "#10b981";
        status.textContent = "✅ Connection successful! Script URL sahi hai.";
      } else {
        status.style.color = "#10b981";
        status.textContent = "✅ Script respond kar raha hai. URL sahi lagta hai.";
      }
    } catch(e) {
      status.style.color = "#ef4444";
      status.textContent = "❌ Connection failed: " + e.message + " — URL check karo ya Apps Script redeploy karo.";
    }
  });
}

async function loadSettings() {
  const res = await msg("GET_SETTINGS");
  settings = res.settings || {};
  document.getElementById("set-dark").checked          = !!settings.darkMode;
  document.getElementById("set-notifications").checked = settings.notificationsEnabled !== false;
  document.getElementById("set-autodetect").checked    = settings.autoDetect !== false;
  document.getElementById("set-daily-limit").value     = settings.dailyLimit || 50;
  document.getElementById("set-min-delay").value       = settings.minDelay || 3;
  document.getElementById("set-max-delay").value       = settings.maxDelay || 8;
  applyDark(!!settings.darkMode);

  // Saved Script URL load karo Settings mein
  chrome.storage.local.get(["SCRIPT_URL"], (data) => {
    const urlEl = document.getElementById("set-script-url");
    if (urlEl && data.SCRIPT_URL) {
      urlEl.value = data.SCRIPT_URL;
      const status = document.getElementById("set-script-url-status");
      if (status) { status.style.color = "#10b981"; status.textContent = "✅ Script URL saved hai — sync ready"; }
    }
  });
}

function applyDark(on) {
  document.body.classList.toggle("dark", on);
}

function initDarkToggle() {
  document.getElementById("btn-dark-toggle").addEventListener("click", async () => {
    const isDark = document.body.classList.toggle("dark");
    await msg("SAVE_SETTINGS", { settings: { ...settings, darkMode: isDark } });
    document.getElementById("set-dark").checked = isDark;
  });
}

// ─── Init ─────────────────────────────────────────────────────────────────
async function init() {
  // ─── AUTH CHECK — Login verify karo, bina login dashboard nahi ───────────
  try {
    const authResult = await Auth.checkAuth();
    if (!authResult.loggedIn) {
      const overlay = document.getElementById('dashAuthOverlay');
      const msgEl   = document.getElementById('dashAuthMsg');
      if (overlay) {
        let reason = 'Dashboard access ke liye pehle extension popup se login karo.';
        if (authResult.reason === 'session_expired') {
          reason = '⏰ Aapka session expire ho gaya. Popup se dobara login karo.';
        } else if (authResult.reason === 'subscription_expired') {
          reason = '❌ Subscription expire ho gaya. Renew karo aur dobara login karo.';
        }
        if (msgEl) msgEl.textContent = reason;
        overlay.style.display = 'flex';
      }
      return; // init rok do — dashboard load mat karo
    }
  } catch(e) {
    // Auth check fail hua — block karo
    const overlay = document.getElementById('dashAuthOverlay');
    if (overlay) overlay.style.display = 'flex';
    return;
  }
  // ─── AUTH OK — aage proceed karo ─────────────────────────────────────────

  // Script URL ab Settings tab se manually set hota hai — config.js se nahi

  initTabs();
  initNumbersTab();
  initEditModal();
  initBulkModal();
  initMessagingTab();
  initTemplatesTab();
  initScheduleTab();
  initSettingsTab();
  initDarkToggle();
  initGoogleSheetsTab();
  msInit();  // multi-sheet tab bar
  initBroadcastTab();

  await loadSettings();

  const numRes = await msg("GET_ALL_NUMBERS");
  allNumbers = numRes.numbers || [];
  updateStats(allNumbers);
  renderTable();

  const tmplRes = await msg("GET_TEMPLATES");
  templates = tmplRes.templates || [];
  renderTemplates();
  syncTemplateSelects();

  await loadSchedule();
  await loadSendLog();

  setInterval(async () => {
    const r = await msg("GET_ALL_NUMBERS");
    allNumbers = r.numbers || [];
    updateStats(allNumbers);
    renderTable();
  }, 10000);
}

document.addEventListener("DOMContentLoaded", init);

// ═══════════════════════════════════════════════════════════════════════════
// ── BROADCAST & CAMPAIGN TAB ──────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════

let bcRunning = false;
let bcStop = false;

function initBroadcastTab() {
  // Sub-tab switching
  document.querySelectorAll(".bc-subtab").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".bc-subtab").forEach(b => {
        b.classList.remove("btn-primary");
        b.classList.add("btn-secondary");
        b.classList.remove("active");
      });
      btn.classList.add("btn-primary");
      btn.classList.remove("btn-secondary");
      btn.classList.add("active");
      document.querySelectorAll(".bc-pane").forEach(p => p.style.display = "none");
      const pane = document.getElementById("bc-pane-" + btn.dataset.bctab);
      if (pane) pane.style.display = "";

      if (btn.dataset.bctab === "campaigns") loadCampaignsTab();
      if (btn.dataset.bctab === "followup") loadFollowupTab();
      if (btn.dataset.bctab === "blacklist") loadBlacklistTab();
      if (btn.dataset.bctab === "smart-broadcast") refreshBroadcastLabelFilter();
    });
  });

  // ── Smart Broadcast ──
  const labelFilter = document.getElementById("bc-label-filter");
  labelFilter.addEventListener("change", bcUpdateContactCount);
  // Load WA labels dynamically on tab open
  refreshBroadcastLabelFilter();

  const bcMsg = document.getElementById("bc-message");
  bcMsg.addEventListener("input", () => {
    document.getElementById("bc-char").textContent = bcMsg.value.length;
    bcGetFilteredContacts().then(contacts => bcUpdatePreview(contacts));
  });

  document.getElementById("bc-template-select").addEventListener("change", function() {
    const t = templates.find(t => t.id === this.value);
    if (t) { bcMsg.value = t.text; bcMsg.dispatchEvent(new Event("input")); }
  });

  // Sync template select with global templates

  document.getElementById("btn-bc-send").addEventListener("click", startBroadcast);
  document.getElementById("btn-bc-stop").addEventListener("click", () => { bcStop = true; });
  document.getElementById("btn-bc-clear-log").addEventListener("click", () => {
    document.getElementById("bc-log").innerHTML = '<div class="log-empty">Log cleared</div>';
  });

  // ── Blacklist ──
  document.getElementById("btn-bl-add").addEventListener("click", async () => {
    const raw = document.getElementById("bl-number-input").value.trim();
    if (!raw) return;
    const nums = raw.split(",").map(n => n.trim()).filter(Boolean);
    await addToBlacklist(nums);
    document.getElementById("bl-number-input").value = "";
    loadBlacklistTab();
  });
  document.getElementById("btn-bl-bulk-add").addEventListener("click", async () => {
    const raw = document.getElementById("bl-bulk-input").value.trim();
    if (!raw) return;
    const nums = raw.split(/[\n,]+/).map(n => n.trim()).filter(Boolean);
    await addToBlacklist(nums);
    document.getElementById("bl-bulk-input").value = "";
    loadBlacklistTab();
  });
  document.getElementById("bl-file-input").addEventListener("change", async function() {
    if (!this.files[0]) return;
    const text = await this.files[0].text();
    const nums = text.split(/[\n,;]+/).map(n => n.trim()).filter(n => /\d{7,}/.test(n));
    await addToBlacklist(nums);
    this.value = "";
    loadBlacklistTab();
  });
  document.getElementById("btn-bl-clear-all").addEventListener("click", async () => {
    if (!confirm("Saari blacklist clear karo?")) return;
    await msg("SAVE_BROADCAST_BLACKLIST", { blacklist: [] });
    loadBlacklistTab();
  });
  document.getElementById("bl-search").addEventListener("input", function() {
    const q = this.value.toLowerCase();
    document.querySelectorAll(".bl-row").forEach(row => {
      row.style.display = row.dataset.number.includes(q) ? "" : "none";
    });
  });

  // ── Campaigns ──
  document.getElementById("btn-refresh-campaigns").addEventListener("click", loadCampaignsTab);

  // Auto-refresh campaigns tab every 10 seconds (reply status update ke liye)
  let _campaignAutoRefreshTimer = null;
  function startCampaignAutoRefresh() {
    stopCampaignAutoRefresh();
    _campaignAutoRefreshTimer = setInterval(() => {
      const tab = document.querySelector('[data-bctab="campaigns"].active, #bc-tab-campaigns.active');
      const listVisible = document.getElementById("campaign-list")?.style.display !== "none";
      if (listVisible) loadCampaignsTab();
    }, 10000);
  }
  function stopCampaignAutoRefresh() {
    clearInterval(_campaignAutoRefreshTimer);
  }
  // Start when campaigns tab is opened
  document.querySelectorAll('[data-bctab]').forEach(btn => {
    btn.addEventListener('click', () => {
      if (btn.dataset.bctab === 'campaigns') startCampaignAutoRefresh();
      else stopCampaignAutoRefresh();
    });
  });
  document.getElementById("btn-campaign-back").addEventListener("click", () => {
    document.getElementById("campaign-detail-card").style.display = "none";
    document.getElementById("campaign-list").style.display = "";
  });

  // ── Follow-up ──
  document.getElementById("btn-fu-save").addEventListener("click", saveFollowupSequence);
  document.getElementById("btn-fu-run-now").addEventListener("click", async () => {
    await msg("RUN_FOLLOWUP_NOW");
    toast("Follow-up sequences started ▶️");
  });
}

// ── Load WA custom labels from storage ──
async function loadBroadcastLabels() {
  return new Promise(resolve => {
    chrome.storage.local.get(["wnum_custom_labels", "wnum_contact_labels"], res => {
      const labels = (res.wnum_custom_labels || []).filter(l =>
        !["all","unread","business","personal"].includes(l.id)
      );
      const contactLabels = res.wnum_contact_labels || {};
      resolve({ labels, contactLabels });
    });
  });
}

async function refreshBroadcastLabelFilter() {
  const sel = document.getElementById("bc-label-filter");
  if (!sel) return;
  const curr = sel.value;
  const { labels } = await loadBroadcastLabels();

  sel.innerHTML = `<option value="">— Sab contacts (blacklist exclude) —</option>
    <option value="__Messaged">✅ Messaged</option>
    <option value="__Replied">💬 Replied</option>
    <option value="__Not_Replied">⏳ Not Replied</option>
    <option value="__New">🆕 New</option>` +
    (labels.length ? `<optgroup label="── WhatsApp Labels ──">` +
      labels.map(l => `<option value="lbl:${escHtml(l.id)}">${l.icon || "🏷️"} ${escHtml(l.name)}</option>`).join("") +
    `</optgroup>` : "");

  if (curr) sel.value = curr;
  bcUpdateContactCount();
}

async function bcGetFilteredContacts() {
  const filter = document.getElementById("bc-label-filter").value;
  const blRes = await msg("GET_BROADCAST_BLACKLIST");
  const broadcastBl = new Set((blRes.blacklist || []).map(b => b.number));
  let contacts = allNumbers.filter(n => !n.blacklisted && !broadcastBl.has(n.number));

  if (!filter) return contacts;

  if (filter === "__Messaged") return contacts.filter(n => n.status === "Messaged");
  if (filter === "__Replied")  return contacts.filter(n => n.replied === true);
  if (filter === "__Not_Replied") return contacts.filter(n => n.status === "Messaged" && n.replied !== true);
  if (filter === "__New") return contacts.filter(n => !n.status || n.status === "New");

  if (filter.startsWith("lbl:")) {
    const lblId = filter.slice(4);
    const { contactLabels } = await loadBroadcastLabels();

    // Build a set of normalized 10-digit numbers that have this label (unsaved numbers)
    const labeledNumbers = new Set();
    const labeledNames = new Set();

    Object.entries(contactLabels).forEach(([key, ids]) => {
      if (!ids.includes(lblId)) return;
      const cleaned = key.replace(/[\s\-().+]/g, "").replace(/\D/g, "");
      if (cleaned.length >= 7) {
        labeledNumbers.add(cleaned.slice(-10));
      } else {
        labeledNames.add(key.trim().toLowerCase());
      }
    });

    // Step 1: Filter allNumbers for unsaved contacts with matching number/name
    const fromUnsaved = contacts.filter(n => {
      const num10 = n.number.replace(/\D/g, "").slice(-10);
      if (labeledNumbers.has(num10)) return true;
      if (n.name && labeledNames.has(n.name.trim().toLowerCase())) return true;
      return false;
    });

    // Step 2: If there are name-keys, resolve them via GET_LABEL_CONTACTS
    // (these are saved contacts not in allNumbers)
    let fromSaved = [];
    if (labeledNames.size > 0) {
      try {
        const result = await msg("GET_LABEL_CONTACTS", { labelId: lblId });
        if (result.contacts && result.contacts.length) {
          // Only include resolved contacts (have a phone number) not already in fromUnsaved
          const existingNums = new Set(fromUnsaved.map(n => n.number.replace(/\D/g, "").slice(-10)));
          result.contacts.forEach(c => {
            if (!c.number || c.unresolved) return;
            const num10 = c.number.replace(/\D/g, "").slice(-10);
            if (existingNums.has(num10)) return; // already included
            if (broadcastBl.has(c.number)) return; // blacklisted
            existingNums.add(num10);
            fromSaved.push({
              number: c.number,
              name: c.name || "",
              fromLabel: true,
              status: "New",
            });
          });
        }
      } catch(e) {
        console.warn("[WA Manager] GET_LABEL_CONTACTS error:", e);
      }
    }

    return [...fromUnsaved, ...fromSaved];
  }
  return contacts;
}

async function bcUpdateContactCount() {
  const contacts = await bcGetFilteredContacts();
  document.getElementById("bc-contact-count").textContent = contacts.length + " contacts";
  const listEl = document.getElementById("bc-contact-list");
  if (contacts.length === 0) {
    listEl.innerHTML = "<span style='color:#ef4444'>Koi contact nahi mili. Filter change karo ya label assign karo.</span>";
  } else {
    listEl.innerHTML = contacts.slice(0, 10).map(n =>
      `<div style="padding:2px 0;border-bottom:1px solid var(--border,#e2e8f0)">${escHtml(n.name || n.number)} <span style="color:#94a3b8;font-size:11px">${n.name ? "· " + escHtml(n.number) : ""}</span></div>`
    ).join("") + (contacts.length > 10 ? `<div style="color:#94a3b8;padding-top:4px">...aur ${contacts.length - 10} contacts</div>` : "");
  }
  bcUpdatePreview(contacts);
  return contacts;
}

function bcUpdatePreview(contacts) {
  const list = contacts || allNumbers.filter(n => !n.blacklisted);
  const first = list[0];
  if (!first) { document.getElementById("bc-preview-name").textContent = ""; return; }
  const previewMsg = applyBcVars(document.getElementById("bc-message").value, first);
  document.getElementById("bc-preview-name").textContent = "Preview: " + previewMsg.substring(0, 40) + (previewMsg.length > 40 ? "…" : "");
}

function applyBcVars(text, contact) {
  return text
    .replace(/\{name\}/gi, contact.name || contact.number)
    .replace(/\{number\}/gi, contact.number)
    .replace(/\{amount\}/gi, contact.amount || "")
    .replace(/\{date\}/gi, new Date().toLocaleDateString("en-IN"));
}

function bcLog(entry) {
  const logEl = document.getElementById("bc-log");
  const isEmpty = logEl.querySelector(".log-empty");
  if (isEmpty) isEmpty.remove();
  const div = document.createElement("div");
  div.className = "log-item";
  div.style.cssText = "padding:6px 8px;border-bottom:1px solid var(--border,#e2e8f0);font-size:12px;display:flex;justify-content:space-between;align-items:center";
  div.innerHTML = `<span>${entry.icon || ""} ${escHtml(entry.name || entry.number)} <span style="color:#94a3b8;font-size:11px">${escHtml(entry.number || "")}</span></span><span style="color:${entry.ok ? "#16a34a" : "#ef4444"};font-size:11px">${entry.ok ? "✅ Sent" : "❌ Failed"}</span>`;
  logEl.prepend(div);
}

async function startBroadcast() {
  if (bcRunning) return;
  const text = document.getElementById("bc-message").value.trim();
  const campaignName = document.getElementById("bc-campaign-name").value.trim();
  const delayMin = parseInt(document.getElementById("bc-delay-min").value) || 4;
  const delayMax = parseInt(document.getElementById("bc-delay-max").value) || 10;

  if (!text) { toast("Message likhna zaroori hai ✍️"); return; }

  const contacts = await bcGetFilteredContacts();

  if (contacts.length === 0) { toast("Koi contact nahi mili! 😅"); return; }
  if (!confirm(`${contacts.length} contacts ko broadcast karo?`)) return;

  bcRunning = true;
  bcStop = false;
  document.getElementById("btn-bc-send").style.display = "none";
  document.getElementById("btn-bc-stop").style.display = "";
  const progressWrap = document.getElementById("bc-progress-bar-wrap");
  const progressBar = document.getElementById("bc-progress-bar");
  const progressText = document.getElementById("bc-progress-text");
  progressWrap.style.display = "";

  const campaignContacts = [];
  let sent = 0, failed = 0;

  for (let i = 0; i < contacts.length; i++) {
    if (bcStop) break;
    const contact = contacts[i];
    const finalMsg = applyBcVars(text, contact);
    const delay = (delayMin + Math.random() * (delayMax - delayMin)) * 1000;
    await new Promise(r => setTimeout(r, delay));

    progressText.textContent = `${i + 1}/${contacts.length} | ✅${sent} ❌${failed}`;
    progressBar.style.width = ((i + 1) / contacts.length * 100) + "%";

    try {
      const res = await msg("SEND_MESSAGE", { number: contact.number, message: finalMsg });
      const success = res && (res.success === true || res.ok === true);

      if (success) {
        bcLog({ number: contact.number, name: contact.name || "", ok: true });
        campaignContacts.push({ number: contact.number, name: contact.name || "", sentAt: new Date().toISOString(), status: "sent", replied: false });
        sent++;
      } else {
        const errMsg = (res && res.reason) || "Send failed";
        bcLog({ number: contact.number, name: contact.name || "", ok: false, error: errMsg });
        campaignContacts.push({ number: contact.number, name: contact.name || "", sentAt: new Date().toISOString(), status: "failed", replied: false });
        failed++;
      }
    } catch(e) {
      bcLog({ number: contact.number, name: contact.name || "", ok: false });
      campaignContacts.push({ number: contact.number, name: contact.name || "", sentAt: new Date().toISOString(), status: "failed", replied: false });
      failed++;
    }
  }

  // Save campaign
  if (campaignName && campaignContacts.length > 0) {
    await msg("UPSERT_CAMPAIGN", { name: campaignName, contacts: campaignContacts });
    toast(`Campaign "${campaignName}" saved 📊`);
  }

  toast(`Broadcast complete: ✅${sent} ❌${failed}`);
  bcRunning = false;
  document.getElementById("btn-bc-send").style.display = "";
  document.getElementById("btn-bc-stop").style.display = "none";
  progressText.textContent = `Complete ✅${sent} ❌${failed}`;
}

// ── Campaigns Tab ──
async function loadCampaignsTab() {
  const res = await msg("GET_CAMPAIGNS");
  const campaigns = res.campaigns || [];
  const listEl = document.getElementById("campaign-list");
  document.getElementById("campaign-detail-card").style.display = "none";
  listEl.style.display = "";
  document.getElementById("nav-campaign-count").style.display = campaigns.length ? "" : "none";
  document.getElementById("nav-campaign-count").textContent = campaigns.length;

  if (!campaigns.length) {
    listEl.innerHTML = '<div class="log-empty" style="padding:24px;text-align:center;color:var(--text2,#64748b)">Koi campaign nahi. Broadcast tab se ek start karo.</div>';
    return;
  }
  listEl.innerHTML = `<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px;padding:4px">` +
    campaigns.map(c => {
      const total = c.contacts.length;
      const sent = c.contacts.filter(x => x.status === "sent").length;
      const replied = c.contacts.filter(x => x.replied).length;
      const notReplied = sent - replied;
      const rate = sent > 0 ? Math.round(replied / sent * 100) : 0;
      return `<div class="card" style="cursor:pointer;transition:box-shadow .2s" onclick="showCampaignDetail(${JSON.stringify(c.name).replace(/</g,'&lt;')})" data-campaign="${escHtml(c.name)}">
        <div style="font-weight:700;font-size:14px;margin-bottom:8px;color:var(--text,#1e293b)">${escHtml(c.name)}</div>
        <div style="display:flex;gap:12px;flex-wrap:wrap;font-size:12px;margin-bottom:10px">
          <span style="color:#16a34a">✅ ${sent} sent</span>
          <span style="color:#3b82f6">💬 ${replied} replied</span>
          <span style="color:#f59e0b">⏳ ${notReplied} no reply</span>
        </div>
        <div style="background:var(--border,#e2e8f0);border-radius:99px;height:6px;overflow:hidden;margin-bottom:6px">
          <div style="height:6px;background:#3b82f6;width:${rate}%;border-radius:99px"></div>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:11px;color:#94a3b8">
          <span>${rate}% reply rate</span>
          <span>${new Date(c.createdAt).toLocaleDateString("en-IN")}</span>
        </div>
      </div>`;
    }).join("") + "</div>";

  // Also update fu campaign select
  const fuSel = document.getElementById("fu-campaign-select");
  if (fuSel) {
    fuSel.innerHTML = '<option value="">— Campaign choose karo —</option>' +
      campaigns.map(c => `<option value="${escHtml(c.name)}">${escHtml(c.name)} (${c.contacts.length})</option>`).join("");
  }
}

window.showCampaignDetail = async function(name) {
  const res = await msg("GET_CAMPAIGNS");
  const campaign = (res.campaigns || []).find(c => c.name === name);
  if (!campaign) return;

  document.getElementById("campaign-list").style.display = "none";
  const detailCard = document.getElementById("campaign-detail-card");
  detailCard.style.display = "";
  document.getElementById("campaign-detail-name").textContent = "📊 " + name;

  const total = campaign.contacts.length;
  const sent = campaign.contacts.filter(x => x.status === "sent").length;
  const replied = campaign.contacts.filter(x => x.replied).length;
  const failed = campaign.contacts.filter(x => x.status === "failed").length;

  document.getElementById("campaign-stats-grid").innerHTML = [
    { label: "Total", value: total, color: "#6366f1" },
    { label: "Sent ✅", value: sent, color: "#16a34a" },
    { label: "Replied 💬", value: replied, color: "#3b82f6" },
    { label: "Failed ❌", value: failed, color: "#ef4444" },
  ].map(s => `<div style="background:var(--bg2,#f8fafc);border-radius:8px;padding:12px;border:1px solid var(--border,#e2e8f0);text-align:center">
    <div style="font-size:20px;font-weight:700;color:${s.color}">${s.value}</div>
    <div style="font-size:11px;color:#94a3b8">${s.label}</div>
  </div>`).join("");

  const tableEl = document.getElementById("campaign-contacts-table");
  tableEl.innerHTML = `<table style="width:100%;border-collapse:collapse;font-size:12px">
    <thead><tr style="background:var(--bg2,#f8fafc)">
      <th style="padding:6px 8px;text-align:left;border-bottom:1px solid var(--border,#e2e8f0)">Number</th>
      <th style="padding:6px 8px;text-align:left;border-bottom:1px solid var(--border,#e2e8f0)">Name</th>
      <th style="padding:6px 8px;text-align:left;border-bottom:1px solid var(--border,#e2e8f0)">Status</th>
      <th style="padding:6px 8px;text-align:left;border-bottom:1px solid var(--border,#e2e8f0)">Replied?</th>
      <th style="padding:6px 8px;text-align:left;border-bottom:1px solid var(--border,#e2e8f0)">Sent At</th>
      <th style="padding:6px 8px;text-align:center;border-bottom:1px solid var(--border,#e2e8f0)">Action</th>
    </tr></thead>
    <tbody>${campaign.contacts.map(c => `<tr style="border-bottom:1px solid var(--border,#e2e8f0)">
      <td style="padding:5px 8px">${escHtml(c.number)}</td>
      <td style="padding:5px 8px">${escHtml(c.name || "—")}</td>
      <td style="padding:5px 8px"><span style="color:${c.status === "sent" ? "#16a34a" : "#ef4444"}">${c.status === "sent" ? "✅ Sent" : "❌ Failed"}</span></td>
      <td style="padding:5px 8px">
        <label style="display:flex;align-items:center;gap:4px;cursor:pointer">
          <input type="checkbox" ${c.replied ? "checked" : ""} onchange="toggleCampaignReply(${JSON.stringify(name)}, ${JSON.stringify(c.number)}, this.checked)" />
          <span style="color:${c.replied ? "#3b82f6" : "#94a3b8"}">${c.replied ? "Yes" : "No"}</span>
        </label>
      </td>
      <td style="padding:5px 8px;color:#94a3b8">${c.sentAt ? new Date(c.sentAt).toLocaleString("en-IN", { dateStyle: "short", timeStyle: "short" }) : "—"}</td>
      <td style="padding:5px 8px;text-align:center"><button onclick="removeCampaignContact(${JSON.stringify(name)}, ${JSON.stringify(c.number)})" style="background:none;border:none;cursor:pointer;color:#ef4444;font-size:14px" title="Remove">✕</button></td>
    </tr>`).join("")}</tbody>
  </table>`;
};

window.toggleCampaignReply = async function(campaignName, number, replied) {
  await msg("UPDATE_CAMPAIGN_CONTACT", { campaignName, number, update: { replied } });
};

window.removeCampaignContact = async function(campaignName, number) {
  const res = await msg("GET_CAMPAIGNS");
  const campaigns = res.campaigns || [];
  const ci = campaigns.findIndex(c => c.name === campaignName);
  if (ci >= 0) {
    campaigns[ci].contacts = campaigns[ci].contacts.filter(c => c.number !== number);
    await msg("UPSERT_CAMPAIGN", { name: campaignName, contacts: campaigns[ci].contacts });
    showCampaignDetail(campaignName);
  }
};

// ── Follow-up Tab ──
async function loadFollowupTab() {
  const res = await msg("GET_CAMPAIGNS");
  const campaigns = res.campaigns || [];
  const fuSel = document.getElementById("fu-campaign-select");
  fuSel.innerHTML = '<option value="">— Campaign choose karo —</option>' +
    campaigns.map(c => `<option value="${escHtml(c.name)}">${escHtml(c.name)} (${c.contacts.length})</option>`).join("");

  const seqRes = await msg("GET_FOLLOWUP_SEQUENCES");
  const seqs = seqRes.seqs || [];
  const listEl = document.getElementById("fu-sequences-list");
  if (!seqs.length) {
    listEl.innerHTML = '<div class="log-empty" style="padding:16px;text-align:center;color:var(--text2,#64748b)">Koi sequence nahi.</div>';
  } else {
    listEl.innerHTML = seqs.map((s, i) => `<div style="padding:10px;border:1px solid var(--border,#e2e8f0);border-radius:8px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center">
      <div>
        <div style="font-weight:600;font-size:13px">${escHtml(s.campaignName)}</div>
        <div style="font-size:11px;color:#94a3b8">
          ${s.day1Enable ? "Day 1 ✅ " : ""}${s.day3Enable ? "Day 3 ✅ " : ""}${s.day7Enable ? "Day 7 ✅" : ""}
        </div>
      </div>
      <div style="display:flex;gap:6px;align-items:center">
        <label class="toggle" style="scale:.8"><input type="checkbox" ${s.enabled ? "checked" : ""} onchange="toggleFollowupSeq(${i}, this.checked)" /><span class="toggle-slider"></span></label>
        <button onclick="deleteFollowupSeq(${i})" style="background:none;border:none;cursor:pointer;color:#ef4444;font-size:16px" title="Delete">✕</button>
      </div>
    </div>`).join("");
  }

  // Sync template selects for followup
  const fuT = document.getElementById("fu-day1-template");
  fuT.innerHTML = '<option value="">Custom message</option>' +
    templates.map(t => `<option value="${escHtml(t.id)}">${escHtml(t.name)}</option>`).join("");
  fuT.addEventListener("change", function() {
    const t = templates.find(t => t.id === this.value);
    if (t) document.getElementById("fu-day1-msg").value = t.text;
  });
}

async function saveFollowupSequence() {
  const campaignName = document.getElementById("fu-campaign-select").value;
  if (!campaignName) { toast("Pehle campaign select karo"); return; }
  const seqRes = await msg("GET_FOLLOWUP_SEQUENCES");
  const seqs = seqRes.seqs || [];
  const idx = seqs.findIndex(s => s.campaignName === campaignName);
  const newSeq = {
    campaignName,
    target: document.getElementById("fu-target").value,
    day1Msg: document.getElementById("fu-day1-msg").value,
    day1Enable: document.getElementById("fu-day1-enable").checked,
    day3Msg: document.getElementById("fu-day3-msg").value,
    day3Enable: document.getElementById("fu-day3-enable").checked,
    day7Msg: document.getElementById("fu-day7-msg").value,
    day7Enable: document.getElementById("fu-day7-enable").checked,
    enabled: true,
    createdAt: new Date().toISOString(),
  };
  if (idx >= 0) seqs[idx] = { ...seqs[idx], ...newSeq };
  else seqs.push(newSeq);
  await msg("SAVE_FOLLOWUP_SEQUENCES", { seqs });
  toast("Sequence saved ✅");
  loadFollowupTab();
}

window.toggleFollowupSeq = async function(idx, enabled) {
  const res = await msg("GET_FOLLOWUP_SEQUENCES");
  const seqs = res.seqs || [];
  if (seqs[idx]) { seqs[idx].enabled = enabled; await msg("SAVE_FOLLOWUP_SEQUENCES", { seqs }); }
};

window.deleteFollowupSeq = async function(idx) {
  if (!confirm("Yeh sequence delete karo?")) return;
  const res = await msg("GET_FOLLOWUP_SEQUENCES");
  const seqs = res.seqs || [];
  seqs.splice(idx, 1);
  await msg("SAVE_FOLLOWUP_SEQUENCES", { seqs });
  loadFollowupTab();
};

// ── Blacklist Tab ──
async function loadBlacklistTab() {
  const res = await msg("GET_BROADCAST_BLACKLIST");
  const bl = res.blacklist || [];
  document.getElementById("bl-count").textContent = bl.length;
  const listEl = document.getElementById("bl-list");
  if (!bl.length) {
    listEl.innerHTML = '<div class="log-empty" style="padding:16px;text-align:center;color:var(--text2,#64748b)">Koi number blacklisted nahi hai</div>';
    return;
  }
  listEl.innerHTML = bl.map(b => `<div class="bl-row" data-number="${escHtml(b.number)}" style="padding:6px 8px;border-bottom:1px solid var(--border,#e2e8f0);display:flex;justify-content:space-between;align-items:center">
    <span style="font-size:13px">${escHtml(b.number)} ${b.name ? '<span style="color:#94a3b8;font-size:11px">· ' + escHtml(b.name) + '</span>' : ''}</span>
    <button onclick="removeFromBlacklist(${JSON.stringify(b.number)})" style="background:none;border:none;cursor:pointer;color:#ef4444;font-size:14px" title="Remove">✕</button>
  </div>`).join("");
}

async function addToBlacklist(numbers) {
  const res = await msg("GET_BROADCAST_BLACKLIST");
  const bl = res.blacklist || [];
  const existing = new Set(bl.map(b => b.number));
  let added = 0;
  numbers.forEach(n => {
    const clean = n.replace(/\D/g, "");
    if (clean && !existing.has(clean)) { bl.push({ number: clean }); existing.add(clean); added++; }
  });
  await msg("SAVE_BROADCAST_BLACKLIST", { blacklist: bl });
  toast(`${added} number(s) blacklisted 🚫`);
}

window.removeFromBlacklist = async function(number) {
  const res = await msg("GET_BROADCAST_BLACKLIST");
  const bl = (res.blacklist || []).filter(b => b.number !== number);
  await msg("SAVE_BROADCAST_BLACKLIST", { blacklist: bl });
  loadBlacklistTab();
};


/* ═══════════════════════════════════════════════════
   ANALYTICS TAB  –  v1.0
   Google Sheet data ko filter, chart & table se show
   ═══════════════════════════════════════════════════ */

const AN = {
  filters: {},        // colName → selected value
  searchText: '',
  filteredRows: [],
  allRows: [],
  headers: [],
  currentPage: 1,
  pageSize: 25,
  barCol: '',
  pieCol: '',
  summaryCol: '',
};

/* ── Colour palette for charts ── */
const AN_COLORS = [
  '#6366f1','#22c55e','#f59e0b','#ef4444','#06b6d4',
  '#a855f7','#ec4899','#14b8a6','#f97316','#3b82f6',
  '#84cc16','#e11d48','#0ea5e9','#d946ef','#10b981',
];

function anInit() {
  // Show/hide based on data availability
  const hasData = gsRawData && gsRawData.length > 0;
  document.getElementById('an-no-data').style.display  = hasData ? 'none'  : '';
  document.getElementById('an-content').style.display  = hasData ? ''      : 'none';
  if (!hasData) return;

  AN.allRows   = gsRawData;
  AN.headers   = gsHeaders || Object.keys(gsRawData[0] || {});
  AN.filters   = {};
  AN.searchText = '';
  AN.currentPage = 1;
  AN.pageSize = parseInt(document.getElementById('an-page-size').value) || 25;

  // Stats
  document.getElementById('an-stat-cols').textContent = AN.headers.length;

  // Build filter dropdowns
  anBuildFilters();
  // Populate chart column selects
  anPopulateColSelects();
  // Run initial render
  anApplyFilters();
  // Events
  anBindEvents();
}

function anBuildFilters() {
  const wrap = document.getElementById('an-filter-dropdowns');
  wrap.innerHTML = '';
  AN.headers.forEach(col => {
    // Get unique values for this column (max 80)
    const vals = [...new Set(AN.allRows.map(r => (r[col] ?? '')).filter(v => v !== ''))].sort();
    if (vals.length === 0 || vals.length > 80) return; // skip free-text
    const fg = document.createElement('div');
    fg.className = 'form-group';
    fg.style.cssText = 'min-width:160px;flex:1;max-width:220px;margin:0';
    const lbl = document.createElement('label');
    lbl.textContent = col;
    const sel = document.createElement('select');
    sel.id = `an-f-${col}`;
    sel.innerHTML = `<option value="">All</option>` + vals.map(v => `<option value="${v}">${v}</option>`).join('');
    sel.addEventListener('change', () => {
      if (sel.value) AN.filters[col] = sel.value;
      else delete AN.filters[col];
      AN.currentPage = 1;
      anApplyFilters();
    });
    fg.append(lbl, sel);
    wrap.appendChild(fg);
  });
}

function anPopulateColSelects() {
  const cols = AN.headers;
  ['an-bar-col','an-pie-col','an-summary-col'].forEach(id => {
    const sel = document.getElementById(id);
    sel.innerHTML = '<option value="">— Column —</option>' +
      cols.map(c => `<option value="${c}">${c}</option>`).join('');
  });
  // Default: first non-number-looking column
  const cat = cols.find(c => {
    const sample = AN.allRows.slice(0,5).map(r => r[c]).filter(Boolean);
    return sample.some(v => isNaN(v) && String(v).length < 40);
  }) || cols[0] || '';
  ['an-bar-col','an-pie-col','an-summary-col'].forEach(id => {
    document.getElementById(id).value = cat;
  });
  AN.barCol = cat; AN.pieCol = cat; AN.summaryCol = cat;
}

function anApplyFilters() {
  const q = AN.searchText.toLowerCase().trim();
  AN.filteredRows = AN.allRows.filter(row => {
    // Column filters
    for (const [col, val] of Object.entries(AN.filters)) {
      if ((row[col] ?? '') !== val) return false;
    }
    // Global search
    if (q) {
      const rowStr = Object.values(row).join(' ').toLowerCase();
      if (!rowStr.includes(q)) return false;
    }
    return true;
  });

  // Stats update
  document.getElementById('an-stat-total').textContent    = AN.allRows.length;
  document.getElementById('an-stat-filtered').textContent = AN.filteredRows.length;
  // Unique numbers
  const numCol = gsMapping?.number || AN.headers.find(h => /phone|mobile|number|whatsapp/i.test(h)) || AN.headers[0];
  const uniq = new Set(AN.filteredRows.map(r => r[numCol]).filter(Boolean));
  document.getElementById('an-stat-unique').textContent = uniq.size;

  // Active filter badge
  const activeCount = Object.keys(AN.filters).length + (q ? 1 : 0);
  const badge = document.getElementById('an-filter-count');
  badge.style.display = activeCount > 0 ? '' : 'none';
  badge.textContent = `${activeCount} active`;

  anRenderTable();
  anRenderBarChart();
  anRenderPieChart();
  anRenderSummaryTable();
}

/* ── Paginated Data Table ── */
function anRenderTable() {
  const thead = document.getElementById('an-data-thead');
  const tbody = document.getElementById('an-data-tbody');
  const rows  = AN.filteredRows;
  const total = rows.length;
  const ps    = AN.pageSize;
  const pg    = AN.currentPage;
  const start = (pg - 1) * ps;
  const end   = Math.min(start + ps, total);
  const pageRows = rows.slice(start, end);

  // Header
  thead.innerHTML = '<tr>' + AN.headers.map(h => `<th>${h}</th>`).join('') + '</tr>';
  // Body
  tbody.innerHTML = pageRows.map(row =>
    '<tr>' + AN.headers.map(h => `<td>${row[h] ?? ''}</td>`).join('') + '</tr>'
  ).join('');

  // Page info
  document.getElementById('an-page-info').textContent =
    total === 0 ? '0 rows' : `${start+1}–${end} / ${total}`;
  document.getElementById('an-prev-page').disabled = pg <= 1;
  document.getElementById('an-next-page').disabled = end >= total;
}

/* ── Bar Chart (Canvas) ── */
function anRenderBarChart() {
  const col    = AN.barCol;
  const canvas = document.getElementById('an-bar-canvas');
  const empty  = document.getElementById('an-bar-empty');
  if (!col) { canvas.style.display='none'; empty.style.display=''; return; }
  canvas.style.display=''; empty.style.display='none';

  // Count values
  const counts = {};
  AN.filteredRows.forEach(r => {
    const v = String(r[col] ?? '').trim() || '(empty)';
    counts[v] = (counts[v] || 0) + 1;
  });
  const sorted = Object.entries(counts).sort((a,b) => b[1]-a[1]).slice(0,15);
  if (sorted.length === 0) { canvas.style.display='none'; empty.style.display=''; return; }

  const labels = sorted.map(([k]) => k);
  const values = sorted.map(([,v]) => v);
  const maxVal = Math.max(...values);

  const dpr = window.devicePixelRatio || 1;
  const W = canvas.offsetWidth || 400;
  const H = 220;
  canvas.width  = W * dpr;
  canvas.height = H * dpr;
  canvas.style.width  = W + 'px';
  canvas.style.height = H + 'px';

  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, W, H);

  const isDark = document.body.classList.contains('dark');
  const textCol  = isDark ? '#94a3b8' : '#64748b';
  const gridCol  = isDark ? '#334155' : '#e2e8f0';

  const padL=40, padR=10, padT=10, padB=45;
  const chartW = W - padL - padR;
  const chartH = H - padT - padB;
  const barW   = Math.max(4, (chartW / labels.length) * 0.65);
  const gap    = chartW / labels.length;

  // Grid lines
  ctx.strokeStyle = gridCol; ctx.lineWidth = 1;
  [0,.25,.5,.75,1].forEach(t => {
    const y = padT + chartH * (1 - t);
    ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(padL+chartW, y); ctx.stroke();
    ctx.fillStyle = textCol; ctx.font = `10px sans-serif`;
    ctx.textAlign = 'right';
    ctx.fillText(Math.round(maxVal * t), padL - 4, y + 3);
  });

  // Bars
  sorted.forEach(([label, val], i) => {
    const x = padL + i * gap + gap/2 - barW/2;
    const barH_px = (val / maxVal) * chartH;
    const y = padT + chartH - barH_px;
    ctx.fillStyle = AN_COLORS[i % AN_COLORS.length];
    const r = Math.min(4, barW / 2);
    ctx.beginPath();
    ctx.moveTo(x+r, y); ctx.lineTo(x+barW-r, y);
    ctx.quadraticCurveTo(x+barW, y, x+barW, y+r);
    ctx.lineTo(x+barW, padT+chartH); ctx.lineTo(x, padT+chartH);
    ctx.lineTo(x, y+r);
    ctx.quadraticCurveTo(x, y, x+r, y);
    ctx.closePath(); ctx.fill();

    // Value on bar
    ctx.fillStyle = textCol; ctx.font = 'bold 10px sans-serif';
    ctx.textAlign = 'center';
    if (barH_px > 16) ctx.fillText(val, x+barW/2, y - 3);

    // X label
    ctx.fillStyle = textCol; ctx.font = '9px sans-serif';
    ctx.save(); ctx.translate(x+barW/2, padT+chartH+6);
    ctx.rotate(-Math.PI/4); ctx.textAlign = 'right';
    const maxLbl = 14;
    ctx.fillText(label.length > maxLbl ? label.slice(0,maxLbl)+'…' : label, 0, 0);
    ctx.restore();
  });
}

/* ── Pie / Donut Chart (Canvas) ── */
function anRenderPieChart() {
  const col    = AN.pieCol;
  const canvas = document.getElementById('an-pie-canvas');
  const legend = document.getElementById('an-pie-legend');
  const empty  = document.getElementById('an-pie-empty');
  if (!col) { canvas.style.display='none'; legend.innerHTML=''; empty.style.display=''; return; }
  canvas.style.display=''; empty.style.display='none';

  const counts = {};
  AN.filteredRows.forEach(r => {
    const v = String(r[col] ?? '').trim() || '(empty)';
    counts[v] = (counts[v] || 0) + 1;
  });
  let sorted = Object.entries(counts).sort((a,b) => b[1]-a[1]);
  if (sorted.length > 12) {
    const top = sorted.slice(0, 11);
    const otherSum = sorted.slice(11).reduce((s,[,v]) => s+v, 0);
    if (otherSum > 0) top.push(['Others', otherSum]);
    sorted = top;
  }
  const total = sorted.reduce((s,[,v]) => s+v, 0);
  if (total === 0) { canvas.style.display='none'; legend.innerHTML=''; empty.style.display=''; return; }

  const SIZE = 200;
  const dpr  = window.devicePixelRatio || 1;
  canvas.width  = SIZE * dpr; canvas.height = SIZE * dpr;
  canvas.style.width = SIZE + 'px'; canvas.style.height = SIZE + 'px';
  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, SIZE, SIZE);

  const cx = SIZE/2, cy = SIZE/2, outerR = SIZE/2 - 4, innerR = outerR * 0.45;
  let angle = -Math.PI/2;

  sorted.forEach(([label, val], i) => {
    const slice = (val / total) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, outerR, angle, angle + slice);
    ctx.closePath();
    ctx.fillStyle = AN_COLORS[i % AN_COLORS.length];
    ctx.fill();
    angle += slice;
  });

  // Donut hole
  ctx.beginPath();
  ctx.arc(cx, cy, innerR, 0, Math.PI*2);
  const isDark = document.body.classList.contains('dark');
  ctx.fillStyle = isDark ? '#1e293b' : '#ffffff';
  ctx.fill();

  // Center text
  ctx.fillStyle = isDark ? '#94a3b8' : '#64748b';
  ctx.font = 'bold 14px sans-serif'; ctx.textAlign='center';
  ctx.fillText(total, cx, cy + 5);

  // Legend
  legend.innerHTML = sorted.map(([label, val], i) => {
    const pct = ((val/total)*100).toFixed(1);
    return `<div class="an-pie-legend-item">
      <div class="an-pie-dot" style="background:${AN_COLORS[i % AN_COLORS.length]}"></div>
      <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${label}">${label}</span>
      <span style="font-weight:600;color:var(--text)">${val}</span>
      <span style="color:var(--text2)">&nbsp;${pct}%</span>
    </div>`;
  }).join('');
}

/* ── Summary Table ── */
function anRenderSummaryTable() {
  const col = AN.summaryCol;
  const tbody = document.getElementById('an-summary-tbody');
  if (!col) { tbody.innerHTML = ''; return; }

  const counts = {};
  AN.filteredRows.forEach(r => {
    const v = String(r[col] ?? '').trim() || '(empty)';
    counts[v] = (counts[v] || 0) + 1;
  });
  const sorted = Object.entries(counts).sort((a,b) => b[1]-a[1]);
  const total  = sorted.reduce((s,[,v]) => s+v, 0);

  tbody.innerHTML = sorted.map(([label, val]) => {
    const pct = total > 0 ? ((val/total)*100).toFixed(1) : 0;
    const barW = total > 0 ? Math.round((val/total)*80) : 0;
    return `<tr>
      <td>${label}</td>
      <td>${val}</td>
      <td><span>${pct}%</span><span class="an-pct-bar" style="width:${barW}px"></span></td>
    </tr>`;
  }).join('');
}

/* ── Event Bindings ── */
function anBindEvents() {
  // Search
  document.getElementById('an-search').value = '';
  document.getElementById('an-search').oninput = e => {
    AN.searchText = e.target.value;
    AN.currentPage = 1;
    anApplyFilters();
  };
  // Clear filters
  document.getElementById('an-clear-filters').onclick = () => {
    AN.filters = {}; AN.searchText = '';
    document.getElementById('an-search').value = '';
    document.querySelectorAll('#an-filter-dropdowns select').forEach(s => s.value = '');
    AN.currentPage = 1;
    anApplyFilters();
  };
  // Filter collapse toggle
  document.getElementById('an-filter-toggle').onclick = () => {
    const body  = document.getElementById('an-filter-body');
    const arrow = document.getElementById('an-filter-arrow');
    const open  = body.style.display !== 'none';
    body.style.display = open ? 'none' : '';
    arrow.textContent  = open ? '▶' : '▼';
  };
  // Chart column selects
  document.getElementById('an-bar-col').onchange = e => {
    AN.barCol = e.target.value; anRenderBarChart();
  };
  document.getElementById('an-pie-col').onchange = e => {
    AN.pieCol = e.target.value; anRenderPieChart();
  };
  document.getElementById('an-summary-col').onchange = e => {
    AN.summaryCol = e.target.value; anRenderSummaryTable();
  };
  // Pagination
  document.getElementById('an-prev-page').onclick = () => {
    if (AN.currentPage > 1) { AN.currentPage--; anRenderTable(); }
  };
  document.getElementById('an-next-page').onclick = () => {
    const maxPage = Math.ceil(AN.filteredRows.length / AN.pageSize);
    if (AN.currentPage < maxPage) { AN.currentPage++; anRenderTable(); }
  };
  document.getElementById('an-page-size').onchange = e => {
    AN.pageSize = parseInt(e.target.value);
    AN.currentPage = 1;
    anRenderTable();
  };
  // Refresh button
  document.getElementById('an-btn-refresh').onclick = anInit;
  // Export CSV
  document.getElementById('an-btn-export').onclick = () => {
    if (!AN.filteredRows.length) return;
    const hdr = AN.headers.join(',');
    const rows = AN.filteredRows.map(r => AN.headers.map(h => `"${(r[h]??'').toString().replace(/"/g,'""')}"`).join(','));
    const blob = new Blob([[hdr,...rows].join('\n')], {type:'text/csv'});
    const a = Object.assign(document.createElement('a'), {
      href: URL.createObjectURL(blob),
      download: `analytics_export_${Date.now()}.csv`
    });
    a.click();
  };
}

/* ── Hook into tab navigation ── */
(function patchTabNav() {
  // We wait for DOMContentLoaded to ensure nav items exist
  const patchFn = () => {
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', () => {
        if (item.dataset.tab === 'analytics') {
          // Small delay to let pane become visible (needed for canvas sizing)
          setTimeout(anInit, 60);
        }
      });
    });
  };
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', patchFn);
  } else {
    patchFn();
  }
})();

// ═══════════════════════════════════════════════════════════════════════════
// ── TWO-WAY GOOGLE SHEETS SYNC SYSTEM ────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════

// ─── Sync State ───────────────────────────────────────────────────────────
const SYNC_STORAGE_KEY = "gs_sync_config";

// Default sync config for each tab (gid → config)
function defaultSyncConfig() {
  return {
    autoSync: false,
    autoSyncInterval: 10,  // minutes
    deleteSync: true,
    lastSynced: null,
    scriptUrl: "",         // per-tab override (optional)
    numCol: "",            // number column name
  };
}

// Load sync config from storage
async function loadSyncConfig() {
  return new Promise(resolve => {
    chrome.storage.local.get([SYNC_STORAGE_KEY, "SCRIPT_URL"], data => {
      resolve({
        tabConfigs: data[SYNC_STORAGE_KEY] || {},
        globalScriptUrl: data.SCRIPT_URL || "",
      });
    });
  });
}

// Save sync config for a specific tab
async function saveSyncConfigForTab(gid, config) {
  const { tabConfigs } = await loadSyncConfig();
  tabConfigs[gid] = { ...(tabConfigs[gid] || defaultSyncConfig()), ...config };
  return new Promise(resolve => {
    chrome.storage.local.set({ [SYNC_STORAGE_KEY]: tabConfigs }, resolve);
  });
}

// Get script URL (per-tab override ya global config.js URL)
async function getScriptUrl(gid) {
  // Priority: storage mein saved URL (Settings tab se) → tab-specific → global
  return new Promise((resolve) => {
    chrome.storage.local.get(["SCRIPT_URL", "gs_sync_config"], (data) => {
      const tabConfigs = data.gs_sync_config || {};
      const tabCfg    = tabConfigs[gid]      || {};
      const resolved  = tabCfg.scriptUrl || data.SCRIPT_URL || "";
      resolve(resolved);
    });
  });
}

// ─── Core Sync API Calls ──────────────────────────────────────────────────

// Sheet se data read karo (via Apps Script)
async function syncReadFromSheet(sheetId, gid, scriptUrl) {
  const url = `${scriptUrl}?action=readSheet&sheetId=${encodeURIComponent(sheetId)}&gid=${encodeURIComponent(gid)}&t=${Date.now()}`;
  const resp = await fetch(url);
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  const data = await resp.json();
  if (!data.ok) throw new Error(data.error || "Sheet read failed");
  return data; // { headers, rows, totalRows }
}

// Sheet mein ek naya row append karo
async function syncAppendToSheet(sheetId, gid, scriptUrl, rowData, numCol) {
  const resp = await fetch(scriptUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "appendRow", sheetId, gid, row: rowData, numCol }),
  });
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  const data = await resp.json();
  if (!data.ok) throw new Error(data.error || "Append failed");
  return data;
}

// Sheet mein number se match karke row update karo
async function syncUpdateInSheet(sheetId, gid, scriptUrl, number, rowData, numCol) {
  const resp = await fetch(scriptUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "updateRow", sheetId, gid, number, row: rowData, numCol }),
  });
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  const data = await resp.json();
  if (!data.ok) throw new Error(data.error || "Update failed");
  return data;
}

// Sheet mein number se match karke row delete karo
async function syncDeleteFromSheet(sheetId, gid, scriptUrl, number, numCol) {
  const resp = await fetch(scriptUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "deleteRow", sheetId, gid, number, numCol }),
  });
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  const data = await resp.json();
  if (!data.ok) throw new Error(data.error || "Delete failed");
  return data;
}

// Full two-way sync: extension data → sheet push + sheet data → extension pull
async function syncTwoWay(sheetId, gid, scriptUrl, extensionRows, numCol, deleteSync = true) {
  const resp = await fetch(scriptUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      action: "twoWaySync", sheetId, gid,
      rows: extensionRows, numCol, deleteSync,
    }),
  });
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  const data = await resp.json();
  if (!data.ok) throw new Error(data.error || "Two-way sync failed");
  return data; // { added, updated, deleted, newFromSheet }
}

// ─── Extension data ko sync-friendly format mein convert karo ─────────────
function extensionRowsForSync(mappedData, headers) {
  // gsMappedData ko sheet format mein convert karo
  return mappedData.map(r => {
    const obj = {};
    if (headers && headers.length) {
      headers.forEach(h => { obj[h] = r[h] !== undefined ? r[h] : ""; });
    } else {
      Object.keys(r).forEach(k => {
        if (k !== "_raw") obj[k] = r[k] !== undefined ? r[k] : "";
      });
    }
    return obj;
  });
}

// ─── Sync UI Status Update ─────────────────────────────────────────────────
function updateSyncStatus(gid, text, type = "info") {
  const el = document.getElementById(`sync-status-${gid}`);
  if (!el) return;
  el.textContent = text;
  el.className = `gs-sync-status sync-${type}`;
}

function updateLastSyncedLabel(gid, isoStr) {
  const el = document.getElementById(`sync-last-${gid}`);
  if (!el) return;
  if (!isoStr) { el.textContent = "Never synced"; return; }
  const d = new Date(isoStr);
  el.textContent = "Last: " + d.toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

// ─── Main: "Sync Now" button ka handler ───────────────────────────────────
async function handleSyncNow(gid, tabName) {
  updateSyncStatus(gid, "⏳ Syncing...", "info");
  const btn = document.getElementById(`sync-btn-${gid}`);
  if (btn) { btn.disabled = true; btn.textContent = "⏳ Syncing..."; }

  try {
    const scriptUrl = await getScriptUrl(gid);
    if (!scriptUrl) throw new Error("Script URL missing! Tab ke 'Sync Settings' mein Script URL daalo aur Save dabao.");
    if (!gsSheetId)  throw new Error("Sheet connect nahi hai. Pehle sheet URL connect karo.");

    const { tabConfigs } = await loadSyncConfig();
    const cfg = tabConfigs[gid] || defaultSyncConfig();
    const numCol = cfg.numCol || gsMapping.number || "";

    // 1) Extension ka current data prepare karo
    const extRows = extensionRowsForSync(gsMappedData, gsHeaders);

    // 2) Two-way sync call
    const result = await syncTwoWay(gsSheetId, gid, scriptUrl, extRows, numCol, cfg.deleteSync);

    // 3) Sheet mein nayi rows hain toh extension ke gsRawData mein add karo
    if (result.newFromSheet && result.newFromSheet.length > 0) {
      // Existing numbers ka set
      const existingNums = new Set(gsMappedData.map(r => r.number));
      result.newFromSheet.forEach(row => {
        // Number column se number nikalo
        const rawNum = numCol ? (row[numCol] || "") : "";
        const cleanNum = rawNum.replace(/[\s\-()+]/g, "").replace(/^0+/, "");
        if (cleanNum && !existingNums.has(cleanNum)) {
          gsRawData.push(row);
          existingNums.add(cleanNum);
        }
      });
      // Re-apply mapping
      if (gsMapping.number) {
        applyGsMapping();
        buildCascadingFilters();
        applyGsFilters();
      }
    }

    // 4) Last synced time save karo
    const now = new Date().toISOString();
    await saveSyncConfigForTab(gid, { lastSynced: now });
    updateLastSyncedLabel(gid, now);

    const msg = `✅ Sync done! +${result.added} added, ${result.updated} updated, ${result.newFromSheetCount || 0} pulled from sheet`;
    updateSyncStatus(gid, msg, "success");
    toast(msg);

  } catch (err) {
    updateSyncStatus(gid, "❌ Error: " + err.message, "error");
    toast("Sync failed: " + err.message);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "🔄 Sync Now"; }
  }
}

// ─── Delete with Sheet Sync ────────────────────────────────────────────────
// Existing delete flow ke saath integrate hota hai
async function deleteWithSheetSync(number) {
  try {
    const { tabConfigs } = await loadSyncConfig();
    const cfg = tabConfigs[gsActiveGid] || defaultSyncConfig();
    if (!cfg.deleteSync) return; // sync off hai

    const scriptUrl = await getScriptUrl(gsActiveGid);
    if (!scriptUrl || !gsSheetId) return; // configured nahi

    const numCol = cfg.numCol || gsMapping.number || "";
    await syncDeleteFromSheet(gsSheetId, gsActiveGid, scriptUrl, number, numCol);
  } catch (e) {
    console.warn("[WA Sync] Delete sync failed:", e.message);
  }
}

// ─── Add/Update with Sheet Sync ───────────────────────────────────────────
async function addUpdateWithSheetSync(rowData, isNew = true) {
  try {
    const { tabConfigs } = await loadSyncConfig();
    const cfg = tabConfigs[gsActiveGid] || defaultSyncConfig();
    const scriptUrl = await getScriptUrl(gsActiveGid);
    if (!scriptUrl || !gsSheetId) return;

    const numCol = cfg.numCol || gsMapping.number || "";
    const number = numCol ? (rowData[numCol] || "") : "";

    if (isNew) {
      await syncAppendToSheet(gsSheetId, gsActiveGid, scriptUrl, rowData, numCol);
    } else {
      await syncUpdateInSheet(gsSheetId, gsActiveGid, scriptUrl, number, rowData, numCol);
    }
  } catch (e) {
    console.warn("[WA Sync] Add/Update sync failed:", e.message);
  }
}

// ─── Auto Sync Alarm System ────────────────────────────────────────────────
// background.js se auto sync trigger hoga — yahan handler hai
async function runAutoSyncForAllTabs() {
  const { tabConfigs } = await loadSyncConfig();
  for (const [gid, cfg] of Object.entries(tabConfigs)) {
    if (!cfg.autoSync) continue;
    await handleSyncNow(gid, "Tab " + gid);
  }
}

// ─── Sync Settings Panel Render ────────────────────────────────────────────
function renderSyncPanel(gid, tabName) {
  const container = document.getElementById(`sync-panel-${gid}`);
  if (!container) return;

  loadSyncConfig().then(({ tabConfigs, globalScriptUrl }) => {
    const cfg = tabConfigs[gid] || defaultSyncConfig();
    // Auto-fill script URL from config.js if not set manually
    const configJsUrl = (typeof SUBSCRIPTION_CONFIG !== "undefined" && SUBSCRIPTION_CONFIG.SCRIPT_URL)
      ? SUBSCRIPTION_CONFIG.SCRIPT_URL : "";
    const displayUrl = cfg.scriptUrl || globalScriptUrl || configJsUrl;

    container.innerHTML = `
      <div class="gs-sync-panel">
        <div class="gs-sync-header">
          <span style="font-weight:600;font-size:13px">🔄 Two-Way Sync — <em>${escHtml(tabName)}</em></span>
          <span id="sync-last-${escHtml(gid)}" style="font-size:11px;color:var(--text2)">Never synced</span>
        </div>

        <div class="gs-sync-row">
          <label class="gs-sync-label">Script URL
            <input type="text" id="sync-script-url-${escHtml(gid)}" class="gs-sync-input"
              placeholder="Apps Script /exec URL — config.js se auto detect hoga"
              value="${escHtml(displayUrl)}" />
            ${displayUrl ? `<small style="color:#10b981;font-size:11px">✅ URL detected — Save Settings dabao to confirm</small>` : `<small style="color:#f59e0b;font-size:11px">⚠️ Apps Script URL yahan paste karo phir Save dabao</small>`}
          </label>
        </div>

        <div class="gs-sync-row">
          <label class="gs-sync-label">Number Column
            <select id="sync-num-col-${escHtml(gid)}" class="gs-sync-select">
              <option value="">— Auto detect —</option>
              ${gsHeaders.map(h => `<option value="${escHtml(h)}" ${cfg.numCol === h ? "selected" : ""}>${escHtml(h)}</option>`).join("")}
            </select>
          </label>
        </div>

        <div class="gs-sync-toggles">
          <label class="gs-sync-toggle-label">
            <input type="checkbox" id="sync-auto-${escHtml(gid)}" ${cfg.autoSync ? "checked" : ""} />
            Auto-sync
          </label>
          <label class="gs-sync-toggle-label" style="margin-left:12px">
            <input type="text" id="sync-interval-${escHtml(gid)}" class="gs-sync-num-input"
              value="${cfg.autoSyncInterval || 10}" style="width:40px;padding:2px 6px" />
            min interval
          </label>
          <label class="gs-sync-toggle-label" style="margin-left:12px">
            <input type="checkbox" id="sync-delete-${escHtml(gid)}" ${cfg.deleteSync !== false ? "checked" : ""} />
            Delete sync
          </label>
        </div>

        <div class="gs-sync-actions">
          <button id="sync-btn-save-${escHtml(gid)}" class="btn btn-sm btn-secondary">💾 Save Settings</button>
          <button id="sync-btn-${escHtml(gid)}" class="btn btn-sm btn-primary">🔄 Sync Now</button>
          <button id="sync-btn-pull-${escHtml(gid)}" class="btn btn-sm btn-secondary">⬇️ Pull from Sheet</button>
          <button id="sync-btn-push-${escHtml(gid)}" class="btn btn-sm btn-secondary">⬆️ Push to Sheet</button>
        </div>

        <div id="sync-status-${escHtml(gid)}" class="gs-sync-status" style="margin-top:6px;font-size:12px;"></div>
      </div>
    `;

    // Restore last synced
    updateLastSyncedLabel(gid, cfg.lastSynced || null);

    // Save Settings button
    document.getElementById(`sync-btn-save-${gid}`).addEventListener("click", async () => {
      const scriptUrlVal = document.getElementById(`sync-script-url-${gid}`).value.trim();
      const numColVal    = document.getElementById(`sync-num-col-${gid}`).value;
      const autoSyncVal  = document.getElementById(`sync-auto-${gid}`).checked;
      const intervalVal  = parseInt(document.getElementById(`sync-interval-${gid}`).value) || 10;
      const deleteSyncV  = document.getElementById(`sync-delete-${gid}`).checked;

      await saveSyncConfigForTab(gid, {
        scriptUrl: scriptUrlVal,
        numCol: numColVal,
        autoSync: autoSyncVal,
        autoSyncInterval: intervalVal,
        deleteSync: deleteSyncV,
      });

      // Auto sync alarm update karo background mein
      chrome.runtime.sendMessage({ type: "UPDATE_SYNC_ALARMS" });
      toast("Sync settings saved ✅");
    });

    // Sync Now button
    document.getElementById(`sync-btn-${gid}`).addEventListener("click", () => {
      handleSyncNow(gid, tabName);
    });

    // Pull Only (Sheet → Extension)
    document.getElementById(`sync-btn-pull-${gid}`).addEventListener("click", async () => {
      updateSyncStatus(gid, "⏳ Pulling from sheet...", "info");
      try {
        const scriptUrl = await getScriptUrl(gid);
        if (!scriptUrl) throw new Error("Script URL missing! Sync panel mein Script URL daalo aur Save dabao.");
        if (!gsSheetId)  throw new Error("Sheet connect nahi hai");

        const result = await syncReadFromSheet(gsSheetId, gid, scriptUrl);
        gsRawData = result.rows;
        gsHeaders = result.headers;
        applyGsMapping();
        buildCascadingFilters();
        applyGsFilters();

        const now = new Date().toISOString();
        await saveSyncConfigForTab(gid, { lastSynced: now });
        updateLastSyncedLabel(gid, now);
        updateSyncStatus(gid, `✅ Pulled! ${result.totalRows} rows`, "success");
        toast(`Sheet se ${result.totalRows} rows pull kiye ✅`);
      } catch (err) {
        updateSyncStatus(gid, "❌ " + err.message, "error");
      }
    });

    // Push Only (Extension → Sheet)
    document.getElementById(`sync-btn-push-${gid}`).addEventListener("click", async () => {
      updateSyncStatus(gid, "⏳ Pushing to sheet...", "info");
      try {
        const scriptUrl = await getScriptUrl(gid);
        if (!scriptUrl) throw new Error("Script URL missing! Sync panel mein Script URL daalo aur Save dabao.");
        if (!gsSheetId)  throw new Error("Sheet connect nahi hai");

        const { tabConfigs } = await loadSyncConfig();
        const cfg    = tabConfigs[gid] || defaultSyncConfig();
        const numCol = cfg.numCol || gsMapping.number || "";
        const extRows = extensionRowsForSync(gsMappedData, gsHeaders);

        const resp = await fetch(scriptUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "bulkWrite", sheetId: gsSheetId, gid, rows: extRows, numCol, mode: "upsert" }),
        });
        const data = await resp.json();
        if (!data.ok) throw new Error(data.error || "Push failed");

        const now = new Date().toISOString();
        await saveSyncConfigForTab(gid, { lastSynced: now });
        updateLastSyncedLabel(gid, now);
        updateSyncStatus(gid, `✅ Pushed! +${data.added} added, ${data.updated} updated`, "success");
        toast(`Sheet mein push hua: +${data.added} add, ${data.updated} update ✅`);
      } catch (err) {
        updateSyncStatus(gid, "❌ " + err.message, "error");
      }
    });
  });
}

// ─── Sync Panel ko Tab Card mein inject karo ──────────────────────────────
function injectSyncPanelIntoTabCard(gid, tabName) {
  // Har tab button ke neeche sync panel container add karo
  const list = document.getElementById("gs-saved-tabs-list");
  if (!list) return;

  // Check: panel already inject hai?
  let panelEl = document.getElementById(`sync-panel-${gid}`);
  if (panelEl) { renderSyncPanel(gid, tabName); showQuickSyncButton(); return; }

  // Container banana
  panelEl = document.createElement("div");
  panelEl.id = `sync-panel-${gid}`;
  panelEl.style.cssText = "margin:4px 0 12px 0";
  list.insertAdjacentElement("afterend", panelEl);
  renderSyncPanel(gid, tabName);
  showQuickSyncButton(); // Tab load ke baad dikhao
}

// ─── CSS for Sync Panel ────────────────────────────────────────────────────
// (dashboard.css mein add hoga separately — yahan inline inject)
(function injectSyncStyles() {
  if (document.getElementById("gs-sync-styles")) return;
  const style = document.createElement("style");
  style.id = "gs-sync-styles";
  style.textContent = `
    .gs-sync-panel {
      background: var(--bg2, #f8fafc);
      border: 1px solid var(--border, #e2e8f0);
      border-radius: 10px;
      padding: 12px 14px;
      margin: 8px 0;
      font-size: 13px;
    }
    .gs-sync-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 10px;
    }
    .gs-sync-row { margin-bottom: 8px; }
    .gs-sync-label {
      display: flex;
      flex-direction: column;
      gap: 4px;
      font-size: 12px;
      color: var(--text2, #64748b);
      font-weight: 500;
    }
    .gs-sync-input {
      padding: 5px 8px;
      border: 1px solid var(--border, #e2e8f0);
      border-radius: 6px;
      font-size: 12px;
      background: var(--bg, #fff);
      color: var(--text, #1e293b);
      width: 100%;
      box-sizing: border-box;
    }
    .gs-sync-select {
      padding: 5px 8px;
      border: 1px solid var(--border, #e2e8f0);
      border-radius: 6px;
      font-size: 12px;
      background: var(--bg, #fff);
      color: var(--text, #1e293b);
    }
    .gs-sync-toggles {
      display: flex;
      align-items: center;
      gap: 4px;
      flex-wrap: wrap;
      margin-bottom: 10px;
    }
    .gs-sync-toggle-label {
      display: flex;
      align-items: center;
      gap: 4px;
      font-size: 12px;
      color: var(--text, #1e293b);
      cursor: pointer;
    }
    .gs-sync-actions {
      display: flex;
      gap: 6px;
      flex-wrap: wrap;
    }
    .gs-sync-status {
      padding: 5px 8px;
      border-radius: 6px;
      font-size: 12px;
      display: none;
    }
    .gs-sync-status:not(:empty) { display: block; }
    .sync-info    { background: #eff6ff; color: #1d4ed8; border: 1px solid #bfdbfe; }
    .sync-success { background: #f0fdf4; color: #166534; border: 1px solid #bbf7d0; }
    .sync-error   { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }
    .gs-sync-num-input {
      padding: 2px 6px;
      border: 1px solid var(--border, #e2e8f0);
      border-radius: 4px;
      font-size: 12px;
      background: var(--bg, #fff);
      color: var(--text, #1e293b);
    }
  `;
  document.head.appendChild(style);
})();

// ─── Hook: Tab load hone par sync panel dikhao ────────────────────────────
// loadTabByGid ke baad call karo — patched version
const _origLoadTabByGid = typeof loadTabByGid === "function" ? loadTabByGid : null;

// renderSavedTabs ko override karo taaki sync panel bhi render ho
const _origRenderSavedTabs = typeof renderSavedTabs === "function" ? renderSavedTabs : null;
if (_origRenderSavedTabs) {
  window._syncPatchedRenderSavedTabs = function() {
    _origRenderSavedTabs();
    // Active tab ke liye sync panel inject karo
    if (gsActiveGid && gsSheetTabs.length > 0) {
      const activeTab = gsSheetTabs.find(t => t.gid === gsActiveGid);
      if (activeTab) {
        setTimeout(() => injectSyncPanelIntoTabCard(gsActiveGid, activeTab.name), 100);
      }
    }
  };
}

// ─── "Sync Now" shortcut button ───────────────────────────────────────────
// Google Sheets tab header ke paas ek quick sync button inject karo
function injectQuickSyncButton() {
  const statusEl = document.getElementById("gs-status");
  if (!statusEl || document.getElementById("gs-quick-sync-btn")) return;

  const btn = document.createElement("button");
  btn.id = "gs-quick-sync-btn";
  btn.className = "btn btn-sm btn-secondary";
  btn.style.cssText = "margin-left:8px;font-size:12px;padding:4px 10px;display:none"; // hidden by default
  btn.innerHTML = "🔄 Quick Sync";
  btn.title = "Active tab ko two-way sync karo";
  btn.addEventListener("click", async () => {
    if (!gsActiveGid) { toast("Pehle ek tab load karo!"); return; }
    // Script URL check — agar nahi hai toh scroll to sync panel
    const scriptUrl = await getScriptUrl(gsActiveGid);
    if (!scriptUrl) {
      toast("⚠️ Sync panel mein Script URL daalo aur Save karo!");
      // Sync panel scroll karo
      const panel = document.getElementById(`sync-panel-${gsActiveGid}`);
      if (panel) panel.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    const activeTab = gsSheetTabs.find(t => t.gid === gsActiveGid);
    await handleSyncNow(gsActiveGid, activeTab?.name || gsActiveGid);
  });
  statusEl.insertAdjacentElement("afterend", btn);
}

// Show Quick Sync button only after a tab is successfully loaded
function showQuickSyncButton() {
  const btn = document.getElementById("gs-quick-sync-btn");
  if (btn) btn.style.display = "inline-flex";
}

// ─── Init: DOMContentLoaded ke baad quick sync button inject karo ────────
document.addEventListener("DOMContentLoaded", () => {
  setTimeout(injectQuickSyncButton, 1000);
});

// ─── Override: Delete action mein sheet sync bhi trigger karo ─────────────
// (yeh existing renderGsTable ke delete action ko extend karta hai — wahan
//  deleteWithSheetSync() call karo jab koi row delete ho)
// Note: existing code mein delete button nahi hai GS table mein —
// isliye yahan ek global function expose karte hain
window.gsSyncDeleteRow = async function(number) {
  if (!gsActiveGid) return;
  await deleteWithSheetSync(number);
  // Also remove from local gsMappedData
  gsMappedData = gsMappedData.filter(r => r.number !== number);
  gsRawData    = gsRawData.filter(r => {
    const n = (r[gsMapping.number] || "").replace(/[\s\-()+]/g, "").replace(/^0+/, "");
    return n !== number;
  });
  gsSelected.delete(number);
  applyGsFilters();
  toast(`Deleted ${number} from extension + sheet`);
};

// ─── BUG FIX: background.js se TRIGGER_AUTO_SYNC message receive karo ─────
// Pehle yeh listener missing tha — isliye auto-sync alarm ke baad bhi
// dashboard mein sync nahi hota tha
if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "TRIGGER_AUTO_SYNC") {
      runAutoSyncForAllTabs().catch(e => {
        console.warn("[WA Sync] Auto-sync trigger failed:", e.message);
      });
      sendResponse({ ok: true });
      return true;
    }
  });
}

// ─── Auto Pull: Tab visible hone par sheet se latest data khicho ────────────
// Jab user tab change karke dashboard par aaye, toh 3 second baad sheet refresh
(function setupGsAutoRefreshOnFocus() {
  let _gsPullTimer = null;
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState !== "visible") return;
    if (!gsSheetId || !gsActiveGid) return;
    clearTimeout(_gsPullTimer);
    _gsPullTimer = setTimeout(async () => {
      try {
        const scriptUrl = await getScriptUrl(gsActiveGid);
        if (!scriptUrl) return; // Script URL nahi hai toh skip
        const result = await syncReadFromSheet(gsSheetId, gsActiveGid, scriptUrl);
        if (result.rows && result.rows.length > 0) {
          gsRawData = result.rows;
          if (gsMapping.number) {
            applyGsMapping();
            buildCascadingFilters();
            applyGsFilters();
          }
          console.log("[WA Sync] Auto-pull on focus:", result.rows.length, "rows");
        }
      } catch(e) {
        console.warn("[WA Sync] Auto-pull on focus failed:", e.message);
      }
    }, 3000); // 3 second wait - user stable hone ke baad
  });
})();

// ─── GS Table Scroll Buttons ───────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  const leftBtn  = document.getElementById("gs-scroll-left");
  const rightBtn = document.getElementById("gs-scroll-right");
  const wrap     = document.getElementById("gs-table-wrap");
  if (leftBtn && rightBtn && wrap) {
    leftBtn.addEventListener("click",  () => { wrap.scrollBy({ left: -200, behavior: "smooth" }); });
    rightBtn.addEventListener("click", () => { wrap.scrollBy({ left:  200, behavior: "smooth" }); });
  }
});
