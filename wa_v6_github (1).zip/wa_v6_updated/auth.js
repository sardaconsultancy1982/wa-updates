// ================================================================
// 🔐 AUTH.JS — Subscription Authentication Module v2.2
// v6.0: sheetUrl system removed — sirf machineId send hoga
// ================================================================

const Auth = (() => {

  const STORAGE_KEY = 'wa_subscription_session';

  // ─── Session save karo ───────────────────────────────────────
  async function saveSession(data) {
    const session = {
      username:       data.username,
      name:           data.name || data.username,
      expiry:         data.expiry,
      machineId:      data.machineId || '',
      loginAt:        Date.now(),
      sessionExpires: Date.now() + (SUBSCRIPTION_CONFIG.SESSION_HOURS * 3600 * 1000),
      loginInfo:      data.loginInfo || null,
    };
    await chrome.storage.local.set({ [STORAGE_KEY]: session });
    return session;
  }

  // ─── Session load karo ───────────────────────────────────────
  async function getSession() {
    const data = await chrome.storage.local.get([STORAGE_KEY]);
    return data[STORAGE_KEY] || null;
  }

  // ─── Session clear karo (logout) ─────────────────────────────
  async function clearSession() {
    await chrome.storage.local.remove([STORAGE_KEY]);
  }

  // ─── Expiry se kitne din bache hain ──────────────────────────
  function getDaysLeft(expiryStr) {
    if (!expiryStr) return -1;
    const expiry = new Date(expiryStr);
    expiry.setHours(23, 59, 59, 999);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const diff = expiry - today;
    return Math.ceil(diff / (1000 * 60 * 60 * 24));
  }

  // ─── Client Info collect karo ────────────────────────────────
  function getClientInfo() {
    return {
      userAgent: navigator.userAgent || '',
      platform:  navigator.platform  || '',
    };
  }

  // ─── Device Fingerprint generate karo (machineId) ─────────────
  function generateDeviceFingerprint() {
    const components = [
      navigator.userAgent        || '',
      navigator.language         || '',
      navigator.platform         || '',
      screen.width               || '',
      screen.height              || '',
      screen.colorDepth          || '',
      navigator.hardwareConcurrency || '',
      navigator.deviceMemory     || '',
      Intl.DateTimeFormat().resolvedOptions().timeZone || '',
    ];
    const raw = components.join('|');
    let hash = 0;
    for (let i = 0; i < raw.length; i++) {
      const char = raw.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return 'MID-' + Math.abs(hash).toString(36).toUpperCase().substring(0, 8);
  }

  // ─── Login — Google Apps Script se verify karo ───────────────
  async function login(username, password) {
    if (!SUBSCRIPTION_CONFIG.SCRIPT_URL || SUBSCRIPTION_CONFIG.SCRIPT_URL.includes('APNA_SCRIPT_ID')) {
      return { success: false, message: '❌ Config.js mein Script URL set nahi hai! Developer se contact karo.' };
    }

    try {
      const clientInfo = getClientInfo();
      const machineId  = generateDeviceFingerprint();

      const url = new URL(SUBSCRIPTION_CONFIG.SCRIPT_URL);
      url.searchParams.set('action',    'verify');
      url.searchParams.set('username',   username.trim().toLowerCase());
      url.searchParams.set('password',   password.trim());
      url.searchParams.set('userAgent',  clientInfo.userAgent);
      url.searchParams.set('platform',   clientInfo.platform);
      url.searchParams.set('machineId',  machineId);
      // sheetUrl REMOVED in v6.0 — sheet block system nahi hai

      const response = await fetch(url.toString(), {
        method: 'GET',
        cache: 'no-cache',
      });

      if (!response.ok) {
        return { success: false, message: `❌ Server error: ${response.status}. Dobara try karo.` };
      }

      const result = await response.json();

      if (result.success) {
        const session = await saveSession({
          username:  username.trim().toLowerCase(),
          name:      result.name,
          expiry:    result.expiry,
          machineId: result.machineId || machineId,
          loginInfo: result.loginInfo || null,
        });
        return {
          success:   true,
          session,
          daysLeft:  getDaysLeft(result.expiry),
          name:      result.name,
          loginInfo: result.loginInfo || null,
        };

      } else {
        return { success: false, message: result.message || '❌ Username ya Password galat hai.' };
      }

    } catch (err) {
      console.error('Auth login error:', err);
      if (err.message && err.message.includes('fetch')) {
        return { success: false, message: '❌ Internet connection check karo aur dobara try karo.' };
      }
      return { success: false, message: '❌ Server se connect nahi ho pa raha. Dobara try karo.' };
    }
  }

  // ─── Check karo — logged in hai aur valid hai? ───────────────
  async function checkAuth() {
    const session = await getSession();
    if (!session) return { loggedIn: false, reason: 'no_session' };

    if (Date.now() > session.sessionExpires) {
      await clearSession();
      return { loggedIn: false, reason: 'session_expired' };
    }

    const daysLeft = getDaysLeft(session.expiry);
    if (daysLeft < 0) {
      await clearSession();
      return { loggedIn: false, reason: 'subscription_expired', expiry: session.expiry };
    }

    return {
      loggedIn:     true,
      session,
      daysLeft,
      showReminder: daysLeft <= SUBSCRIPTION_CONFIG.REMINDER_DAYS,
    };
  }

  // ─── User ke apne login logs fetch karo ──────────────────────
  async function getMyLogs(username, password) {
    if (!SUBSCRIPTION_CONFIG.SCRIPT_URL || SUBSCRIPTION_CONFIG.SCRIPT_URL.includes('APNA_SCRIPT_ID')) {
      return { success: false, message: '❌ Script URL set nahi hai.' };
    }
    try {
      const url = new URL(SUBSCRIPTION_CONFIG.SCRIPT_URL);
      url.searchParams.set('action',   'getUserLogs');
      url.searchParams.set('username', username.trim().toLowerCase());
      url.searchParams.set('password', password.trim());

      const response = await fetch(url.toString(), { method: 'GET', cache: 'no-cache' });
      if (!response.ok) return { success: false, message: `Server error: ${response.status}` };
      return await response.json();
    } catch (err) {
      return { success: false, message: '❌ Logs fetch nahi ho paye. Dobara try karo.' };
    }
  }

  // ─── Background se expiry notification ───────────────────────
  async function checkAndNotify() {
    const result = await checkAuth();
    if (!result.loggedIn) return;

    const daysLeft = result.daysLeft;
    const key = 'last_notif_day_' + daysLeft;
    const data = await chrome.storage.local.get([key]);
    if (data[key]) return;

    if (daysLeft <= SUBSCRIPTION_CONFIG.REMINDER_DAYS && daysLeft >= 0) {
      chrome.notifications.create('subscription_reminder', {
        type:     'basic',
        iconUrl:  'icons/icon128.png',
        title:    `⚠️ ${SUBSCRIPTION_CONFIG.APP_NAME} — Subscription Reminder`,
        message:  daysLeft === 0
          ? '🚨 Aaj aapka subscription expire ho raha hai! Renew karo abhi.'
          : `⏰ Aapka subscription ${daysLeft} din mein expire hoga. Renew karo.`,
        priority: 2,
      });
      await chrome.storage.local.set({ [key]: true });
    }
  }

  // Public API
  return { login, checkAuth, clearSession, getDaysLeft, checkAndNotify, getMyLogs };
})();
