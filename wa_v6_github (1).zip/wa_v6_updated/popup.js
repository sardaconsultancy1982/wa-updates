/**
 * popup.js — WhatsApp Number Manager Popup Logic
 */

"use strict";

// ─── Helpers ─────────────────────────────────────────────────────────────
function msg(type, data = {}) {
  return new Promise((res) =>
    chrome.runtime.sendMessage({ type, ...data }, (r) => res(r || {}))
  );
}

function formatTime(iso) {
  const d = new Date(iso);
  const now = new Date();
  const isToday = d.toDateString() === now.toDateString();
  return isToday
    ? d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    : d.toLocaleDateString([], { month: "short", day: "numeric" });
}

function initials(num) {
  return num.slice(-2);
}

// ─── Render number list ───────────────────────────────────────────────────
function renderNumbers(numbers) {
  const list = document.getElementById("number-list");
  const empty = document.getElementById("empty-state");
  const badge = document.getElementById("recent-count");

  const today = new Date().toDateString();
  const newToday = numbers.filter((n) => new Date(n.dateTime).toDateString() === today).length;
  const messaged = numbers.filter((n) => n.status === "Messaged").length;

  document.getElementById("stat-total-num").textContent = numbers.length;
  document.getElementById("stat-new-num").textContent = newToday;
  document.getElementById("stat-sent-num").textContent = messaged;
  badge.textContent = numbers.length;

  if (numbers.length === 0) {
    empty.style.display = "flex";
    list.querySelectorAll(".number-item").forEach((el) => el.remove());
    return;
  }

  empty.style.display = "none";

  // Remove old items
  list.querySelectorAll(".number-item").forEach((el) => el.remove());

  // Show latest 10
  numbers.slice(0, 10).forEach((n) => {
    const item = document.createElement("div");
    item.className = "number-item";
    item.title = "Click to open chat";

    const statusClass = n.blacklisted ? "blacklisted" : (n.status || "new").toLowerCase();

    item.innerHTML = `
      <div class="num-avatar${n.blacklisted ? " blacklisted" : ""}">${initials(n.number)}</div>
      <div class="num-info">
        <div class="num-phone">${n.number}</div>
        <div class="num-preview">${n.lastMessage || "No message preview"}</div>
      </div>
      <div class="num-meta">
        <div class="num-time">${formatTime(n.dateTime)}</div>
        <div class="num-status ${statusClass}">${n.blacklisted ? "Blocked" : n.status || "New"}</div>
      </div>
    `;

    item.addEventListener("click", async () => {
      const tabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
      if (tabs.length) {
        chrome.tabs.sendMessage(tabs[0].id, { type: "OPEN_CHAT", number: n.number });
      } else {
        chrome.tabs.create({ url: `https://web.whatsapp.com/send?phone=${n.number}` });
      }
      window.close();
    });

    list.appendChild(item);
  });
}

// ─── Export CSV ───────────────────────────────────────────────────────────
function exportCSV(numbers) {
  const headers = ["Number", "Last Message", "Date & Time", "Status", "Country", "Tags", "Notes"];
  const rows = numbers.map((n) => [
    n.number,
    `"${(n.lastMessage || "").replace(/"/g, '""')}"`,
    n.dateTime,
    n.status || "New",
    n.country || "",
    n.tags || "",
    `"${(n.notes || "").replace(/"/g, '""')}"`,
  ]);

  const csv = [headers, ...rows].map((r) => r.join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `wa_unsaved_numbers_${Date.now()}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

// ─── Status bar ───────────────────────────────────────────────────────────
async function checkWhatsAppStatus() {
  const dot = document.getElementById("status-dot");
  const text = document.getElementById("status-text");

  const tabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
  if (tabs.length > 0) {
    dot.className = "status-dot active";
    text.textContent = "WhatsApp Web active & monitoring";
  } else {
    dot.className = "status-dot error";
    text.textContent = "WhatsApp Web not open";
  }
}

// ─── Dark mode ────────────────────────────────────────────────────────────
async function initDarkMode() {
  const { settings } = await msg("GET_SETTINGS");
  if (settings.darkMode) document.body.classList.add("dark");

  document.getElementById("btn-dark-mode").addEventListener("click", async () => {
    document.body.classList.toggle("dark");
    const isDark = document.body.classList.contains("dark");
    await msg("SAVE_SETTINGS", { settings: { ...settings, darkMode: isDark } });
  });
}

// ─── Init ─────────────────────────────────────────────────────────────────
async function init() {
  await initDarkMode();

  // ─── Update Check — Login ke baad ─────────────────────────────────────
  // Sirf logged-in users ko update notification dikhao
  if (typeof WA_Updater !== "undefined") {
    setTimeout(() => WA_Updater.checkAfterLogin(), 1500);
  }

  // Load numbers
  const { numbers } = await msg("GET_ALL_NUMBERS");
  renderNumbers(numbers || []);

  // Check WA status
  await checkWhatsAppStatus();

  // ── Button: Open Dashboard — sirf login ke baad ──
  document.getElementById("btn-dashboard").addEventListener("click", async () => {
    const authCheck = await Auth.checkAuth();
    if (!authCheck.loggedIn) {
      // Login nahi hai — popup par login overlay dikhao
      showLoginOverlay(authCheck.reason || 'no_session');
      return;
    }
    chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });
    window.close();
  });

  // ── Button: Rescan ──
  document.getElementById("btn-rescan").addEventListener("click", async () => {
    const tabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
    if (tabs.length) {
      chrome.tabs.sendMessage(tabs[0].id, { type: "RESCAN" });
      setTimeout(async () => {
        const { numbers } = await msg("GET_ALL_NUMBERS");
        renderNumbers(numbers || []);
      }, 2000);
    } else {
      alert("Please open WhatsApp Web first.");
    }
  });

  // ── Button: Full Scan (scroll poori chat list) ──
  document.getElementById("btn-fullscan").addEventListener("click", async () => {
    const tabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
    if (!tabs.length) {
      alert("Pehle WhatsApp Web kholein, phir Full Scan karein.");
      return;
    }

    const btn      = document.getElementById("btn-fullscan");
    const progWrap = document.getElementById("fullscan-progress-wrap");
    const progBar  = document.getElementById("fullscan-bar");
    const progLbl  = document.getElementById("fullscan-label");

    // Disable button, show progress
    btn.disabled    = true;
    btn.textContent = "⏳ Scanning...";
    progWrap.style.display = "";
    progBar.style.width    = "0%";
    progLbl.textContent    = "🔍 Chat list scroll ho rahi hai...";

    // Listen for progress messages from content script
    function onProgress(message) {
      if (message.type === "FULL_SCAN_PROGRESS") {
        progBar.style.width    = message.percent + "%";
        progLbl.textContent    = `🔍 ${message.percent}% scan hua...`;
      }
    }
    chrome.runtime.onMessage.addListener(onProgress);

    // Send FULL_SCAN to content script
    chrome.tabs.sendMessage(tabs[0].id, { type: "FULL_SCAN" }, async (response) => {
      chrome.runtime.onMessage.removeListener(onProgress);

      // Restore button
      btn.disabled    = false;
      btn.innerHTML   = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="11" y1="8" x2="11" y2="14"/><line x1="8" y1="11" x2="14" y2="11"/></svg> Full Scan`;

      if (!response || !response.ok) {
        progLbl.textContent = "⚠️ Scan fail hua. WhatsApp Web reload karein.";
        progBar.style.width = "0%";
        setTimeout(() => { progWrap.style.display = "none"; }, 3000);
        return;
      }

      // Success
      progBar.style.width  = "100%";
      progBar.style.background = "#22c55e";
      const newlyAdded = response.newlyAdded || 0;
      const total      = response.total      || 0;
      progLbl.textContent = `✅ ${newlyAdded} naye numbers mile! Total: ${total}`;

      // Refresh list
      const { numbers } = await msg("GET_ALL_NUMBERS");
      renderNumbers(numbers || []);

      // Hide progress after 4 sec
      setTimeout(() => {
        progWrap.style.display = "none";
        progBar.style.background = "#8b5cf6";
        progBar.style.width = "0%";
      }, 4000);
    });
  });

  // ── Button: Export CSV ──
  document.getElementById("btn-export").addEventListener("click", async () => {
    const { numbers } = await msg("GET_ALL_NUMBERS");
    if (!numbers || numbers.length === 0) {
      alert("No numbers to export.");
      return;
    }
    exportCSV(numbers);
  });

  // ── Button: Clear All ──
  document.getElementById("btn-clear").addEventListener("click", async () => {
    if (confirm("Clear all stored numbers? This cannot be undone.")) {
      await msg("CLEAR_ALL");
      renderNumbers([]);
    }
  });
}

// ═══════════════════════════════════════════════════════════
// 🔐 AUTH FUNCTIONS — Login / Session / User Info Bar
// ═══════════════════════════════════════════════════════════

function showLoginOverlay(reason) {
  const overlay = document.getElementById('loginOverlay');
  overlay.style.display = 'flex';
  document.getElementById('expiredBanner').style.display =
    reason === 'subscription_expired' ? 'block' : 'none';
  setTimeout(() => {
    const un = document.getElementById('loginUsername');
    if (un) un.focus();
  }, 100);
}

function hideLoginOverlay() {
  document.getElementById('loginOverlay').style.display = 'none';
}

function setLoginLoading(loading) {
  document.getElementById('loginBtn').disabled = loading;
  document.getElementById('loginBtnText').style.display = loading ? 'none' : '';
  document.getElementById('loginBtnLoader').style.display = loading ? '' : 'none';
}

function showLoginError(msg) {
  const el = document.getElementById('loginError');
  el.textContent = msg;
  el.style.display = 'block';
}

function hideLoginError() {
  document.getElementById('loginError').style.display = 'none';
}

function updateUserInfoBar(session, daysLeft) {
  const bar = document.getElementById('userInfoBar');
  bar.style.display = 'flex';
  document.getElementById('userInfoText').textContent =
    `👤 ${session.name || session.username}  |  📅 ${daysLeft} din bache`;

  if (daysLeft <= SUBSCRIPTION_CONFIG.REMINDER_DAYS) {
    const banner = document.getElementById('subscriptionReminderBanner');
    const text = document.getElementById('reminderText');
    banner.style.display = 'flex';
    text.textContent = daysLeft === 0
      ? '🚨 Aaj aapka subscription expire ho raha hai! Renew karo abhi.'
      : `⏰ Subscription sirf ${daysLeft} din mein expire hoga — renew karo!`;
    banner.className = 'sub-reminder-banner' + (daysLeft <= 2 ? ' urgent' : '');
  }
}

async function initAuth() {
  const authResult = await Auth.checkAuth();

  if (!authResult.loggedIn) {
    showLoginOverlay(authResult.reason);

    document.getElementById('togglePassword')?.addEventListener('click', () => {
      const inp = document.getElementById('loginPassword');
      if (inp) inp.type = inp.type === 'password' ? 'text' : 'password';
    });

    document.getElementById('logoutBtn')?.addEventListener('click', async () => {
      await Auth.clearSession();
      document.getElementById('userInfoBar').style.display = 'none';
      showLoginOverlay('logout');
    });

    document.getElementById('subReminderCloseBtn')?.addEventListener('click', () => {
      document.getElementById('subscriptionReminderBanner').style.display = 'none';
    });

    return false;
  }

  updateUserInfoBar(authResult.session, authResult.daysLeft);

  document.getElementById('logoutBtn')?.addEventListener('click', async () => {
    await Auth.clearSession();
    document.getElementById('userInfoBar').style.display = 'none';
    showLoginOverlay('logout');
  });

  document.getElementById('togglePassword')?.addEventListener('click', () => {
    const inp = document.getElementById('loginPassword');
    if (inp) inp.type = inp.type === 'password' ? 'text' : 'password';
  });

  document.getElementById('subReminderCloseBtn')?.addEventListener('click', () => {
    document.getElementById('subscriptionReminderBanner').style.display = 'none';
  });

  return true;
}

async function initWithAuth() {
  const authOk = await initAuth();
  if (!authOk) {
    document.getElementById('loginBtn')?.addEventListener('click', async () => {
      const username = document.getElementById('loginUsername').value.trim();
      const password = document.getElementById('loginPassword').value.trim();
      hideLoginError();
      if (!username || !password) {
        showLoginError('❌ Username aur Password dono daalo.');
        return;
      }
      setLoginLoading(true);
      const result = await Auth.login(username, password);
      setLoginLoading(false);
      if (result.success) {
        hideLoginOverlay();
        updateUserInfoBar(result.session, result.daysLeft);
        // Content script ko notify karo — auth valid hai, ab init karo
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs[0]?.id) {
            chrome.tabs.sendMessage(tabs[0].id, { type: 'AUTH_LOGIN_SUCCESS' }).catch(() => {});
          }
        });
        init();
      } else {
        showLoginError(result.message);
      }
    });

    ['loginUsername', 'loginPassword'].forEach(id => {
      document.getElementById(id)?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') document.getElementById('loginBtn')?.click();
      });
    });

    return;
  }
  init();
}

document.addEventListener("DOMContentLoaded", initWithAuth);

// ─── Auto Update Check ────────────────────────────────────────────────────
// NOTE: Update check ab sirf login ke baad hoga — WA_Updater.autoCheck()
// Auth module ke andar check karta hai ki user logged in hai ya nahi.
// Login hone ke baad init() function mein WA_Updater.checkAfterLogin() call hoga.
