/**
 * group-extractor.js — MAIN world
 * Exact same module-loading approach as SheetWA (file2)
 * Uses named WA module IDs: WAWebChatCollection, WAWebGroupMetadataCollection, etc.
 */

(function () {
  "use strict";

  const WA_KEY = "WA_MODULE_WNUM";

  // ── Load WA modules by named IDs (SheetWA approach) ──────────────────
  function loadWAModules() {
    if (window[WA_KEY] && window[WA_KEY].Chat) return window[WA_KEY];

    if (
      !("function" === typeof window.webpackJsonp ||
        window.webpackChunkwhatsapp_web_client ||
        window.require)
    ) return null;

    try {
      const req = (id) => {
        try {
          return window.require ? window.require(id) : null;
        } catch (e) {
          console.log("[GroupExtractor] Module not found:", id, e.message);
          return null;
        }
      };

      window[WA_KEY] = {};

      const chatMod = req("WAWebChatCollection");
      window[WA_KEY].Chat = chatMod ? chatMod.ChatCollection : undefined;

      const labelMod = req("WAWebLabelCollection");
      window[WA_KEY].Label = labelMod ? labelMod.LabelCollection : undefined;

      window[WA_KEY].ContactMethods = req("WAWebContactGetters");

      try {
        window[WA_KEY].GroupMetadata = window.importDefault
          ? window.importDefault("WAWebGroupMetadataCollection")
          : null;
      } catch (e) {
        console.log("[GroupExtractor] GroupMetadata error:", e.message);
        window[WA_KEY].GroupMetadata = null;
      }

      const contactMod = req("WAWebContactCollection");
      window[WA_KEY].Contact = contactMod ? contactMod.ContactCollection : undefined;

      if (window[WA_KEY].Chat) {
        console.log("[GroupExtractor] WA modules loaded ✓ Chat:", !!window[WA_KEY].Chat,
          "GroupMetadata:", !!window[WA_KEY].GroupMetadata);
        return window[WA_KEY];
      }
      return null;
    } catch (e) {
      console.error("[GroupExtractor] loadWAModules error:", e);
      return null;
    }
  }

  // ── Get all groups ────────────────────────────────────────────────────
  function getAllGroups(m) {
    try {
      if (!m.Chat) return [];
      const groups = m.Chat.filter(
        (c) => c.id && c.id.server === "g.us" &&
               (!c.groupType || c.groupType === "DEFAULT")
      );
      return groups.map((g) => ({
        name: g.formattedTitle || g.name || "Unknown Group",
        id:   (g.id && g.id._serialized) || "",
      }));
    } catch (e) {
      console.error("[GroupExtractor] getAllGroups:", e);
      return [];
    }
  }

  // ── Get contacts of a group ───────────────────────────────────────────
  async function getGroupContacts(groupId, m) {
    try {
      if (!m.Chat || !m.GroupMetadata) return { error: "Modules not ready", contacts: [] };

      const chat = m.Chat.filter(
        (c) => c.id && c.id._serialized === groupId
      )[0];
      if (!chat) return { error: "Group not found", contacts: [] };

      const meta = await m.GroupMetadata.find(chat.id);
      if (!meta || !meta.participants) return { error: "No participants", contacts: [] };

      const getName = (contact) => {
        if (m.ContactMethods && m.ContactMethods.getName) {
          return m.ContactMethods.getName(contact) || "";
        }
        return contact.displayName || contact.pushname ||
               contact.name || contact.shortName || "";
      };

      const contacts = [];
      meta.participants.forEach((p, idx) => {
        try {
          const contact = p.contact;
          if (!contact) return;
          const phone =
            (contact.phoneNumber && contact.phoneNumber.user) ||
            (contact.id && contact.id.user) || "";
          if (!phone) return;
          contacts.push({
            index:      contacts.length + 1,
            name:       getName(contact),
            phone:      phone,
            isBusiness: contact.isBusiness || false,
          });
        } catch (e) {}
      });

      return { contacts };
    } catch (e) {
      return { error: e.message, contacts: [] };
    }
  }

  // ── Wait for WA to be ready then load modules ─────────────────────────
  let modules = null;
  let retries = 0;

  function tryInit() {
    modules = loadWAModules();
    if (!modules && retries++ < 30) {
      setTimeout(tryInit, 1000);
    } else if (modules) {
      console.log("[GroupExtractor] Ready ✓");
    }
  }

  // Start trying when #pane-side is available
  const observer = new MutationObserver(() => {
    if (document.querySelector("#pane-side")) {
      observer.disconnect();
      setTimeout(tryInit, 1500);
    }
  });
  observer.observe(document, { childList: true, subtree: true });
  // Also try immediately
  if (document.querySelector("#pane-side")) tryInit();

  // ── Message bridge ────────────────────────────────────────────────────
  window.addEventListener("message", async (event) => {
    if (!event.data || event.data.source !== "wnum-isolated") return;
    const { action, requestId } = event.data;

    // Re-try module load if not ready
    if (!modules) modules = loadWAModules();

    if (action === "GET_GROUPS") {
      if (!modules || !modules.Chat) {
        window.postMessage({
          source: "wnum-main", action: "GET_GROUPS_RESULT",
          requestId, groups: [], error: "WA modules not loaded yet. Refresh page."
        }, "*");
        return;
      }
      const groups = getAllGroups(modules);
      window.postMessage({
        source: "wnum-main", action: "GET_GROUPS_RESULT",
        requestId, groups
      }, "*");
    }

    if (action === "GET_GROUP_CONTACTS") {
      const { groupId } = event.data;
      if (!modules || !modules.Chat) {
        window.postMessage({
          source: "wnum-main", action: "GET_GROUP_CONTACTS_RESULT",
          requestId, groupId, contacts: [], error: "WA modules not loaded yet."
        }, "*");
        return;
      }
      const result = await getGroupContacts(groupId, modules);
      window.postMessage({
        source: "wnum-main", action: "GET_GROUP_CONTACTS_RESULT",
        requestId, groupId, ...result
      }, "*");
    }

    if (action === "GET_ALL_CONTACTS") {
      if (!modules) modules = loadWAModules();
      const contacts = [];
      try {
        // Method 1: ContactCollection (most reliable)
        if (modules && modules.Contact) {
          modules.Contact.forEach(c => {
            try {
              const phone = (c.id && c.id.user) ? c.id.user : '';
              if (!phone || c.id.server === 'g.us' || c.id.server === 'broadcast') return;
              const name = (modules.ContactMethods && modules.ContactMethods.getName)
                ? (modules.ContactMethods.getName(c) || '')
                : (c.displayName || c.pushname || c.name || c.shortName || '');
              contacts.push({
                name: name,
                phone: phone,
                isBusiness: !!c.isBusiness,
                // All name variations for matching
                aliases: [
                  name,
                  c.displayName || '',
                  c.pushname || '',
                  c.name || '',
                  c.shortName || '',
                  c.formattedName || '',
                  phone,
                  '+' + phone,
                ].filter(Boolean)
              });
            } catch(e) {}
          });
        }
        // Method 2: Chat collection fallback (individual chats only)
        if (!contacts.length && modules && modules.Chat) {
          modules.Chat.forEach(c => {
            try {
              if (!c.id || c.id.server === 'g.us' || c.id.server === 'broadcast') return;
              const phone = c.id.user || '';
              if (!phone) return;
              const name = c.formattedTitle || c.name || c.displayName || '';
              contacts.push({ name, phone, isBusiness: !!c.isBusiness, aliases: [name, phone, '+'+phone].filter(Boolean) });
            } catch(e) {}
          });
        }
      } catch(e) {}
      window.postMessage({
        source: "wnum-main", action: "GET_ALL_CONTACTS_RESULT",
        requestId, contacts
      }, "*");
    }

    // ── GET_ACTIVE_CHAT_PHONE: currently open chat ka phone number nikalo ──
    if (action === "GET_ACTIVE_CHAT_PHONE") {
      if (!modules) modules = loadWAModules();
      let phone = null;
      let debugInfo = [];

      try {
        // Helper: check karo ki value actual phone number hai ya LID/internal ID
        function isRealPhone(val) {
          if (!val) return false;
          const cleaned = String(val).replace(/\D/g, '');
          // Real Indian/international phone: 10-13 digits, starts with valid prefix
          // LID typically 15+ digits ya non-phone pattern
          if (cleaned.length < 7 || cleaned.length > 15) return false;
          // Valid: 10 digit Indian, or 91XXXXXXXXXX, or international
          if (/^[6-9]\d{9}$/.test(cleaned)) return true;      // 10-digit Indian
          if (/^91[6-9]\d{9}$/.test(cleaned)) return true;    // 91 + 10-digit
          if (/^[1-9]\d{6,14}$/.test(cleaned)) return true;   // other international
          return false;
        }

        // Method 1: ContactCollection mein active chat dhundo aur phone extract karo
        // (Most reliable — directly contacts se phone milta hai, LID nahi)
        if (modules && modules.Contact) {
          // Pehle active chat ka serialized ID lo
          let activeSerialized = null;

          // Try ChatCollection se active chat
          if (modules.Chat) {
            try {
              let ac = null;
              if (modules.Chat.getActive) ac = modules.Chat.getActive();
              if (!ac) ac = modules.Chat.find(c => c.active === true || c.isActive === true);
              if (ac && ac.id) {
                activeSerialized = ac.id._serialized || (ac.id.user + '@' + ac.id.server);
                debugInfo.push('active_serialized: ' + activeSerialized);
              }
            } catch(e) { debugInfo.push('chat_err: ' + e.message); }
          }

          // Ab ContactCollection mein usi serialized ID se contact dhundo
          if (activeSerialized) {
            try {
              modules.Contact.forEach(c => {
                if (phone) return;
                const cSer = c.id && (c.id._serialized || (c.id.user + '@' + (c.id.server||'c.us')));
                if (cSer === activeSerialized) {
                  // Phone number prefer karo — LID nahi
                  const candidates = [c.phoneNumber, c.phone, c.number];
                  for (const cand of candidates) {
                    if (cand && isRealPhone(cand)) { phone = String(cand).replace(/\D/g,'').replace(/^0+/,''); return; }
                  }
                  // id.user try karo only if real phone
                  if (c.id && c.id.user && isRealPhone(c.id.user)) {
                    phone = c.id.user;
                  }
                }
              });
            } catch(e) { debugInfo.push('contact_match_err: ' + e.message); }
          }

          // Agar contact se nahi mila — header title se name nikalo aur name se match karo
          if (!phone) {
            try {
              const headerEl = document.querySelector('[data-testid="conversation-header"]');
              const contactName = headerEl
                ? (headerEl.querySelector('[data-testid="conversation-info-header-chat-title"] span')
                   || headerEl.querySelector('span[title]')
                   || headerEl.querySelector('span'))
                : null;
              const nameStr = contactName
                ? (contactName.getAttribute('title') || contactName.textContent || '').trim()
                : '';
              debugInfo.push('header_name: ' + nameStr);

              if (nameStr) {
                const nameLow = nameStr.toLowerCase();
                modules.Contact.forEach(c => {
                  if (phone) return;
                  // Check karo ki id.user real phone hai
                  if (!c.id || !c.id.user) return;
                  if (c.id.server === 'g.us' || c.id.server === 'broadcast') return;
                  const cPhone = c.id.user;
                  if (!isRealPhone(cPhone)) return;

                  // Name match
                  const names = [
                    c.displayName, c.pushname, c.name, c.shortName, c.formattedName,
                    (modules.ContactMethods && modules.ContactMethods.getName) ? modules.ContactMethods.getName(c) : ''
                  ].filter(Boolean).map(n => n.toLowerCase());

                  if (names.some(n => n === nameLow || n.includes(nameLow) || nameLow.includes(n))) {
                    phone = cPhone.replace(/\D/g,'').replace(/^0+/,'');
                  }
                });
              }
            } catch(e) { debugInfo.push('name_match_err: ' + e.message); }
          }
        }

        // Method 2: WPP.chat.getActiveChat — only if returns real phone
        if (!phone) {
          try {
            if (window.WPP && window.WPP.chat && window.WPP.chat.getActiveChat) {
              const ac = window.WPP.chat.getActiveChat();
              if (ac && ac.id && ac.id.user && isRealPhone(ac.id.user)) {
                phone = ac.id.user;
                debugInfo.push('wpp_active: ' + phone);
              }
            }
          } catch(e) {}
        }

        // Method 3: DOM se data-id (unsaved numbers ke liye fallback)
        if (!phone) {
          try {
            const mainPanel = document.getElementById('main');
            if (mainPanel) {
              const els = mainPanel.querySelectorAll('[data-id*="@c.us"]');
              for (const el of els) {
                const did = el.getAttribute('data-id') || '';
                const m = did.match(/(\d{10,15})@c\.us/);
                if (m && isRealPhone(m[1])) { phone = m[1]; break; }
              }
            }
          } catch(e) {}
        }

      } catch(e) { debugInfo.push('outer_err: ' + e.message); }

      // Final clean — sirf digits, valid length
      if (phone) {
        const digits = String(phone).replace(/\D/g, '').replace(/^0+/, '');
        // Valid phone: 7-15 digits
        phone = (digits.length >= 7 && digits.length <= 15) ? digits : null;
      }
      console.log('[WNUM] GET_ACTIVE_CHAT_PHONE result:', phone, 'debug:', debugInfo.join(' | '));
      window.postMessage({
        source: "wnum-main", action: "GET_ACTIVE_CHAT_PHONE_RESULT",
        requestId, phone
      }, "*");
    }

    if (action === "GET_BROADCAST_LISTS") {
      if (!modules) modules = loadWAModules();
      const broadcasts = [];
      try {
        // ── DEBUG: Find first broadcast and dump ALL its keys to console ──
        const _debugChatStore = (window.WPP && window.WPP.whatsapp && window.WPP.whatsapp.ChatStore) || (modules && modules.Chat);
        if (_debugChatStore) {
          const _allChats = _debugChatStore.getModelsArray ? _debugChatStore.getModelsArray() : (Array.isArray(_debugChatStore) ? _debugChatStore : []);
          const _bcs = _allChats.filter(c => {
            const s = (c.id && c.id._serialized) || '';
            return c.id && (c.id.server === 'broadcast' || s.endsWith('@broadcast')) && s !== 'status@broadcast';
          });
          console.log('[WNUM-DEBUG] Total broadcast chats found:', _bcs.length);
          if (_bcs.length > 0) {
            const _bc = _bcs[0];
            console.log('[WNUM-DEBUG] First BC id:', _bc.id && _bc.id._serialized);
            console.log('[WNUM-DEBUG] First BC name:', _bc.formattedTitle || _bc.name);
            // Dump ALL keys and their types/values
            const _allKeys = Object.keys(_bc);
            console.log('[WNUM-DEBUG] ALL keys on broadcast object:', _allKeys);
            _allKeys.forEach(k => {
              try {
                const v = _bc[k];
                if (v === null || v === undefined) return;
                if (typeof v === 'function') return;
                if (Array.isArray(v)) console.log('[WNUM-DEBUG] KEY:', k, '=> Array length:', v.length, 'sample:', JSON.stringify(v.slice(0,2)));
                else if (typeof v === 'object') {
                  const subKeys = Object.keys(v);
                  console.log('[WNUM-DEBUG] KEY:', k, '=> Object keys:', subKeys.slice(0,10));
                  if (v.getModelsArray) {
                    const models = v.getModelsArray();
                    console.log('[WNUM-DEBUG] KEY:', k, '.getModelsArray() length:', models.length, 'sample:', JSON.stringify(models.slice(0,2)));
                  }
                  if (v._models) console.log('[WNUM-DEBUG] KEY:', k, '._models length:', Object.keys(v._models).length);
                }
                else console.log('[WNUM-DEBUG] KEY:', k, '=>', JSON.stringify(v));
              } catch(e) {}
            });
            // Also try attributes
            if (_bc.attributes) {
              console.log('[WNUM-DEBUG] BC attributes keys:', Object.keys(_bc.attributes));
            }
          }
        }
        // ── END DEBUG ──
        if (modules && modules.Chat) {

          // Build phone→contact map from ContactCollection for name lookup
          const phoneMap = {};
          if (modules.Contact) {
            modules.Contact.forEach(c => {
              try {
                const ph = c.id && c.id.user ? c.id.user : '';
                if (!ph) return;
                const nm = (modules.ContactMethods && modules.ContactMethods.getName)
                  ? (modules.ContactMethods.getName(c) || '')
                  : (c.displayName || c.pushname || c.name || c.shortName || '');
                phoneMap[ph] = { name: nm, isBusiness: !!c.isBusiness };
              } catch(e) {}
            });
          }

          modules.Chat.forEach(c => {
            try {
              const ser = (c.id && c.id._serialized) || '';
              // Broadcast detection - multiple strategies
              const isBroadcast = c.id && (
                c.id.server === 'broadcast' ||
                ser.endsWith('@broadcast') ||
                ser === 'status@broadcast' ||
                c.broadcast === true ||
                c.isBroadcast === true ||
                c.isGroup === false && ser.includes('@broadcast')
              );
              if (!isBroadcast) return;
              // Skip status broadcast
              if (ser === 'status@broadcast') return;

              const recipients = [];

              // Strategy 1: allowedContacts array (most common in WA Web)
              const allowed = c.allowedContacts || c.allowedContactsList || [];
              allowed.forEach(wid => {
                try {
                  // wid can be string "91XXXXXXXXXX@c.us" or object {_serialized, user}
                  const phone = typeof wid === 'string'
                    ? wid.replace('@c.us','').replace('@s.whatsapp.net','')
                    : (wid.user || (wid._serialized || '').replace('@c.us',''));
                  if (!phone) return;
                  const info = phoneMap[phone] || {};
                  recipients.push({ phone, name: info.name || '', isBusiness: !!info.isBusiness });
                } catch(e) {}
              });

              // Strategy 2: participants (WIDs as objects)
              if (!recipients.length) {
                const parts = c.participants || c.recipients || [];
                parts.forEach(p => {
                  try {
                    let phone = '';
                    if (typeof p === 'string') {
                      phone = p.replace('@c.us','').replace('@s.whatsapp.net','');
                    } else {
                      phone = (p.id && p.id.user) || (p.user) || '';
                      if (!phone && p._serialized) phone = p._serialized.replace('@c.us','');
                    }
                    if (!phone) return;
                    const contact = (typeof p === 'object' && p.contact) ? p.contact : {};
                    const info = phoneMap[phone] || {};
                    const nm = info.name ||
                      (modules.ContactMethods && modules.ContactMethods.getName ? modules.ContactMethods.getName(contact) : '') ||
                      contact.displayName || contact.pushname || contact.name || '';
                    recipients.push({ phone, name: nm, isBusiness: !!contact.isBusiness || !!info.isBusiness });
                  } catch(e) {}
                });
              }

              // Strategy 3: msgs ke through participants dhundho
              if (!recipients.length) {
                try {
                  const msgs = c.msgs && c.msgs.models ? c.msgs.models : [];
                  const seen = new Set();
                  msgs.slice(-50).forEach(m => {
                    try {
                      const phone = m.to && m.to.user ? m.to.user : '';
                      if (phone && !seen.has(phone)) {
                        seen.add(phone);
                        const info = phoneMap[phone] || {};
                        recipients.push({ phone, name: info.name||'', isBusiness: !!info.isBusiness });
                      }
                    } catch(e) {}
                  });
                } catch(e) {}
              }

              broadcasts.push({
                id: ser,
                name: c.formattedTitle || c.name || c.displayName || 'Broadcast List',
                count: recipients.length,
                recipients,
                // Debug info
                _raw_allowed: allowed.length,
                _raw_parts: (c.participants||c.recipients||[]).length,
              });
            } catch(e) {}
          });
        }
      } catch(e) { console.error('[GroupExtractor] Broadcast error:', e); }
      window.postMessage({
        source: "wnum-main", action: "GET_BROADCAST_LISTS_RESULT",
        requestId, broadcasts
      }, "*");
    }
  });

  // ── Reply Detection: MAIN world se incoming messages detect karo ────────
  (function attachMainWorldReplyDetector(retries) {
    if (retries <= 0) return;

    function tryAttach() {
      var attached = false;

      // Method A: WPP.ev
      try {
        if (window.WPP && window.WPP.ev && window.WPP.ev.on) {
          window.WPP.ev.on('chat.new_message', function(wmsg) {
            try {
              if (wmsg.fromMe) return;
              var rawNum = String(
                (wmsg.id && wmsg.id.remote) ||
                wmsg.chatId || wmsg.from || ''
              ).replace(/@.*$/, '').replace(/\D/g, '');
              if (!rawNum || rawNum.length < 7) return;
              window.postMessage({ source: 'wnum-main', action: 'INCOMING_MESSAGE', number: rawNum }, '*');
            } catch(e) {}
          });
          console.log('[GroupExtractor] WPP.ev reply detector attached ✓');
          attached = true;
        }
      } catch(e) {}

      // Method B: WPP.whatsapp.MsgStore / Backbone collection change
      try {
        if (!attached && window.WPP && window.WPP.whatsapp) {
          var store = window.WPP.whatsapp.MsgStore || window.WPP.whatsapp.ChatStore;
          if (store && store.on) {
            store.on('add change', function(model) {
              try {
                if (!model || model.get('id') === undefined) return;
                var fromMe = model.get('id') && model.get('id').fromMe;
                if (fromMe) return;
                var remote = model.get('id') && model.get('id').remote;
                if (!remote) return;
                var num = String(remote).replace(/@.*$/, '').replace(/\D/g, '');
                if (!num || num.length < 7) return;
                window.postMessage({ source: 'wnum-main', action: 'INCOMING_MESSAGE', number: num }, '*');
              } catch(e) {}
            });
            console.log('[GroupExtractor] MsgStore reply detector attached ✓');
            attached = true;
          }
        }
      } catch(e) {}

      return attached;
    }

    if (tryAttach()) return;
    setTimeout(function() { attachMainWorldReplyDetector(retries - 1); }, 2000);
  })(25);

  console.log("[GroupExtractor MAIN] Initialized — waiting for WA...");
})();
