/**
 * ================================================================
 * GoogleAppsScript.gs — WA Manager Two-Way Sync Backend
 * ================================================================
 * SETUP STEPS:
 *  1. Google Sheets kholo jisme sync karna hai
 *  2. Extensions > Apps Script > is file ka code paste karo
 *  3. Deploy > New Deployment > Web App
 *     - Execute as: Me
 *     - Who has access: Anyone
 *  4. Deploy karo → URL copy karo → Settings mein Script URL mein daalo
 * ================================================================
 */

// ─── JSON Response Helper (CORS headers ContentService mein nahi hote) ──────
function jsonResponse(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

// ─── Main GET Handler ────────────────────────────────────────────────────────
function doGet(e) {
  try {
    const action   = (e.parameter.action   || "").trim();
    const sheetId  = (e.parameter.sheetId  || "").trim();
    const gid      = (e.parameter.gid      || "").trim();
    const rowIndex    = parseInt(e.parameter.rowIndex || "-1");
    const reqUsername  = (e.parameter.username  || "").trim().toLowerCase();
    const reqMachineId = (e.parameter.machineId || "").trim();

    // ✅ Sheet Block Helper — Subscription script se verify karo
    // ⚠️ IMPORTANT: Neeche apna Code.gs (subscription) script URL daalo
    const SUB_SCRIPT_URL = ""; // ← YAHAN APNA SUBSCRIPTION SCRIPT URL DAALO

    function isUserBlocked() {
      if (!reqUsername || !SUB_SCRIPT_URL) return false;
      try {
        let url = SUB_SCRIPT_URL + "?action=checkStatus&username=" + encodeURIComponent(reqUsername);
        if (reqMachineId) url += "&machineId=" + encodeURIComponent(reqMachineId);
        const resp = UrlFetchApp.fetch(url, { muteHttpExceptions: true });
        if (resp.getResponseCode() === 200) {
          const d = JSON.parse(resp.getContentText());
          return d.valid === false;
        }
      } catch(e) {}
      return false;
    }

    let result;

    switch (action) {

      // ── Sheet ke saare tabs return karo ──
      case "getAllTabs": {
        if (!sheetId) throw new Error("sheetId missing");
        if (isUserBlocked()) { result = { ok: false, blocked: true, error: "🚫 Sheet access blocked by admin." }; break; }
        const ss   = SpreadsheetApp.openById(sheetId);
        const tabs = ss.getSheets().map(s => ({
          name: s.getName(),
          gid:  String(s.getSheetId()),
        }));
        result = { ok: true, tabs };
        break;
      }

      // ── Ek tab ka poora data return karo ──
      case "readSheet": {
        if (!sheetId) throw new Error("sheetId missing");
        if (isUserBlocked()) { result = { ok: false, blocked: true, error: "🚫 Sheet access blocked by admin." }; break; }
        const ss    = SpreadsheetApp.openById(sheetId);
        const sheet = gid ? getSheetByGid(ss, gid) : ss.getSheets()[0];
        if (!sheet) throw new Error("Tab nahi mili (gid=" + gid + ")");

        const values = sheet.getDataRange().getValues();
        if (values.length === 0) { result = { ok: true, headers: [], rows: [] }; break; }

        const headers = values[0].map(String);
        const rows    = values.slice(1).map(row => {
          const obj = {};
          headers.forEach((h, i) => { obj[h] = row[i] !== undefined ? String(row[i]) : ""; });
          return obj;
        });
        result = { ok: true, headers, rows, totalRows: rows.length };
        break;
      }

      // ── Ek specific row return karo ──
      case "readRow": {
        if (!sheetId || rowIndex < 0) throw new Error("sheetId ya rowIndex missing");
        const ss    = SpreadsheetApp.openById(sheetId);
        const sheet = gid ? getSheetByGid(ss, gid) : ss.getSheets()[0];
        if (!sheet) throw new Error("Tab nahi mili");

        const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
        const rowData = sheet.getRange(rowIndex + 1, 1, 1, sheet.getLastColumn()).getValues()[0];
        const obj     = {};
        headers.forEach((h, i) => { obj[h] = rowData[i] !== undefined ? String(rowData[i]) : ""; });
        result = { ok: true, row: obj, rowIndex };
        break;
      }

      case "checkSubscription":
      case "check": {
        result = { ok: true, status: "active" };
        break;
      }


      // ══════════════════════════════════════════════════════════════════
      // 📱 LIVE MOBILE DASHBOARD — action=dashboard&sheetId=...&gid=...
      //    Browser mein open karo ya mobile par install karo (PWA)
      //    Optional params: pin=YOUR_PIN (security ke liye)
      // ══════════════════════════════════════════════════════════════════
      case "dashboard": {
        return serveDashboard(e);
      }

      // ── Inline cell update (GET se karo — CORS ke liye) ──
      case "updateCell": {
        const sheetIdG  = (e.parameter.sheetId  || "").trim();
        const tabNameG  = (e.parameter.tabName  || "").trim();
        const numberG   = String(e.parameter.number  || "").replace(/\D/g,"").replace(/^0+/,"");
        const colNameG  = (e.parameter.colName  || "").trim();
        const valueG    = e.parameter.value !== undefined ? e.parameter.value : "";

        if (!sheetIdG) return jsonResponse({ ok: false, error: "sheetId missing" });
        if (!colNameG) return jsonResponse({ ok: false, error: "colName missing" });

        try {
          const ss = SpreadsheetApp.openById(sheetIdG);
          let sheet;
          if (tabNameG) sheet = ss.getSheets().find(function(s){ return s.getName() === tabNameG; });
          if (!sheet) sheet = ss.getSheets()[0];
          if (!sheet) return jsonResponse({ ok: false, error: "Sheet nahi mili" });

          const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
          const targetCol = headers.indexOf(colNameG);
          if (targetCol < 0) return jsonResponse({ ok: false, error: "Column nahi mila: " + colNameG });

          const allData = sheet.getDataRange().getValues();
          const phoneColIdx = headers.findIndex(function(h){
            return /phone|number|mobile|whatsapp|contact/i.test(h);
          });
          if (phoneColIdx < 0) return jsonResponse({ ok: false, error: "Phone column nahi mila" });

          const searchNum = numberG.slice(-10);
          let updated = false;
          for (let i = 1; i < allData.length; i++) {
            const cellNum = String(allData[i][phoneColIdx]||"").replace(/\D/g,"").replace(/^0+/,"").slice(-10);
            if (cellNum === searchNum) {
              sheet.getRange(i + 1, targetCol + 1).setValue(valueG);
              updated = true;
              break;
            }
          }
          return jsonResponse({ ok: updated, updated: updated, error: updated ? null : "Row nahi mili: " + numberG });
        } catch(ex) {
          return jsonResponse({ ok: false, error: ex.message });
        }
      }

      default:
        result = { ok: false, error: "Unknown GET action: " + action };
    }

    return jsonResponse(result);

  } catch (err) {
    return jsonResponse({ ok: false, error: err.message });
  }
}

// ─── Main POST Handler ───────────────────────────────────────────────────────
function doPost(e) {
  try {
    const body    = JSON.parse(e.postData.contents || "{}");
    const action  = body.action  || "";
    const sheetId = body.sheetId || "";
    const gid     = body.gid     || "";

    let result;

    switch (action) {

      // ── Naya row append karo ──
      case "appendRow": {
        if (!sheetId) throw new Error("sheetId missing");
        const ss    = SpreadsheetApp.openById(sheetId);
        const sheet = gid ? getSheetByGid(ss, gid) : ss.getSheets()[0];
        if (!sheet) throw new Error("Tab nahi mili (gid=" + gid + ")");

        const rowData = body.row || {};
        ensureHeaders(sheet, Object.keys(rowData));
        const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
        const newRow  = headers.map(h => rowData[h] !== undefined ? rowData[h] : "");
        sheet.appendRow(newRow);
        result = { ok: true, rowIndex: sheet.getLastRow() - 1, message: "Row append hua" };
        break;
      }

      // ── Existing row update karo (number se match karke) ──
      case "updateRow": {
        if (!sheetId) throw new Error("sheetId missing");
        const ss    = SpreadsheetApp.openById(sheetId);
        const sheet = gid ? getSheetByGid(ss, gid) : ss.getSheets()[0];
        if (!sheet) throw new Error("Tab nahi mili");

        const rowData   = body.row    || {};
        const numCol    = body.numCol || "";
        const number    = body.number || "";
        const headers   = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
        const allData   = sheet.getDataRange().getValues();
        const numColIdx = numCol ? headers.indexOf(numCol) : -1;
        let targetRowIdx = -1;

        if (numColIdx >= 0 && number) {
          const searchNum = number.replace(/\D/g, "").replace(/^0+/, "");
          for (let i = 1; i < allData.length; i++) {
            const cellNum = String(allData[i][numColIdx]).replace(/\D/g, "").replace(/^0+/, "");
            if (cellNum === searchNum || cellNum.slice(-10) === searchNum.slice(-10)) {
              targetRowIdx = i; break;
            }
          }
        } else if (body.rowIndex >= 0) {
          targetRowIdx = body.rowIndex;
        }

        if (targetRowIdx < 0) {
          ensureHeaders(sheet, Object.keys(rowData));
          const updatedHeaders = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
          sheet.appendRow(updatedHeaders.map(h => rowData[h] !== undefined ? rowData[h] : ""));
          result = { ok: true, action: "appended", rowIndex: sheet.getLastRow() - 1 };
        } else {
          headers.forEach((h, colIdx) => {
            if (rowData[h] !== undefined) {
              sheet.getRange(targetRowIdx + 1, colIdx + 1).setValue(rowData[h]);
            }
          });
          result = { ok: true, action: "updated", rowIndex: targetRowIdx };
        }
        break;
      }

      // ── Row delete karo (number se match karke) ──
      case "deleteRow": {
        if (!sheetId) throw new Error("sheetId missing");
        const ss    = SpreadsheetApp.openById(sheetId);
        const sheet = gid ? getSheetByGid(ss, gid) : ss.getSheets()[0];
        if (!sheet) throw new Error("Tab nahi mili");

        const number    = body.number  || "";
        const numCol    = body.numCol  || "";
        const headers   = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
        const allData   = sheet.getDataRange().getValues();
        const numColIdx = numCol ? headers.indexOf(numCol) : -1;
        let deletedCount = 0;

        if (numColIdx >= 0 && number) {
          const searchNum = number.replace(/\D/g, "").replace(/^0+/, "");
          const toDelete  = [];
          for (let i = 1; i < allData.length; i++) {
            const cellNum = String(allData[i][numColIdx]).replace(/\D/g, "").replace(/^0+/, "");
            if (cellNum === searchNum || cellNum.slice(-10) === searchNum.slice(-10)) {
              toDelete.push(i + 1);
            }
          }
          for (let i = toDelete.length - 1; i >= 0; i--) {
            sheet.deleteRow(toDelete[i]);
            deletedCount++;
          }
        } else if (body.rowIndex >= 0) {
          sheet.deleteRow(body.rowIndex + 1);
          deletedCount = 1;
        }

        result = { ok: true, deletedCount, message: deletedCount + " row(s) delete hui" };
        break;
      }

      // ── Multiple rows ek saath write karo (bulk upsert) ──
      case "bulkWrite": {
        if (!sheetId) throw new Error("sheetId missing");
        const ss    = SpreadsheetApp.openById(sheetId);
        const sheet = gid ? getSheetByGid(ss, gid) : ss.getSheets()[0];
        if (!sheet) throw new Error("Tab nahi mili");

        const rows   = body.rows   || [];
        const numCol = body.numCol || "";
        const mode   = body.mode   || "upsert";

        if (rows.length === 0) { result = { ok: true, added: 0, updated: 0 }; break; }

        const allKeys = [...new Set(rows.flatMap(r => Object.keys(r)))];
        ensureHeaders(sheet, allKeys);
        const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
        let added = 0, updated = 0;

        if (mode === "overwrite") {
          if (sheet.getLastRow() > 1) {
            sheet.getRange(2, 1, sheet.getLastRow() - 1, sheet.getLastColumn()).clearContent();
          }
          const matrix = rows.map(row => headers.map(h => row[h] !== undefined ? row[h] : ""));
          if (matrix.length > 0) sheet.getRange(2, 1, matrix.length, headers.length).setValues(matrix);
          added = rows.length;
        } else {
          const allData   = sheet.getDataRange().getValues();
          const numColIdx = numCol ? headers.indexOf(numCol) : -1;
          const existingMap = {};
          if (numColIdx >= 0) {
            for (let i = 1; i < allData.length; i++) {
              const cellNum = String(allData[i][numColIdx]).replace(/\D/g, "").replace(/^0+/, "");
              if (cellNum) existingMap[cellNum.slice(-10)] = i + 1;
            }
          }
          for (const rowData of rows) {
            const num10 = numCol && rowData[numCol]
              ? String(rowData[numCol]).replace(/\D/g, "").replace(/^0+/, "").slice(-10) : "";
            if (num10 && existingMap[num10]) {
              headers.forEach((h, ci) => {
                if (rowData[h] !== undefined && rowData[h] !== "")
                  sheet.getRange(existingMap[num10], ci + 1).setValue(rowData[h]);
              });
              updated++;
            } else {
              sheet.appendRow(headers.map(h => rowData[h] !== undefined ? rowData[h] : ""));
              if (num10) existingMap[num10] = sheet.getLastRow();
              added++;
            }
          }
        }
        result = { ok: true, added, updated, total: rows.length };
        break;
      }

      // ── Two-way sync ──
      case "twoWaySync": {
        if (!sheetId) throw new Error("sheetId missing");
        const ss    = SpreadsheetApp.openById(sheetId);
        const sheet = gid ? getSheetByGid(ss, gid) : ss.getSheets()[0];
        if (!sheet) throw new Error("Tab nahi mili");

        const extensionRows = body.rows   || [];
        const numCol        = body.numCol || "";

        ensureHeaders(sheet, extensionRows.length > 0 ? Object.keys(extensionRows[0]) : []);
        const headers   = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
        const allData   = sheet.getDataRange().getValues();
        const numColIdx = numCol ? headers.indexOf(numCol) : -1;

        const sheetMap = {};
        for (let i = 1; i < allData.length; i++) {
          if (numColIdx >= 0) {
            const cn = String(allData[i][numColIdx]).replace(/\D/g, "").replace(/^0+/, "").slice(-10);
            if (cn) sheetMap[cn] = { rowIdx: i + 1, data: allData[i] };
          }
        }

        const extSet = new Set();
        extensionRows.forEach(r => {
          const n = numCol && r[numCol] ? String(r[numCol]).replace(/\D/g, "").replace(/^0+/, "").slice(-10) : "";
          if (n) extSet.add(n);
        });

        let added = 0, updated = 0;
        const newFromSheet = [];

        for (const rowData of extensionRows) {
          const num10 = numCol && rowData[numCol]
            ? String(rowData[numCol]).replace(/\D/g, "").replace(/^0+/, "").slice(-10) : "";
          if (num10 && sheetMap[num10]) {
            headers.forEach((h, ci) => {
              if (rowData[h] !== undefined && rowData[h] !== "")
                sheet.getRange(sheetMap[num10].rowIdx, ci + 1).setValue(rowData[h]);
            });
            updated++;
          } else {
            sheet.appendRow(headers.map(h => rowData[h] !== undefined ? rowData[h] : ""));
            added++;
          }
        }

        Object.keys(sheetMap).forEach(num10 => {
          if (!extSet.has(num10)) {
            const obj = {};
            headers.forEach((h, i) => { obj[h] = String(sheetMap[num10].data[i] || ""); });
            newFromSheet.push(obj);
          }
        });

        result = {
          ok: true, added, updated, deleted: 0,
          newFromSheet, newFromSheetCount: newFromSheet.length,
          message: "Sync complete: " + added + " added, " + updated + " updated, " + newFromSheet.length + " new from sheet"
        };
        break;
      }

      // ── Single cell update (dashboard inline edit) ──
      case "updateCell": {
        if (!sheetId) throw new Error("sheetId missing");
        const ss      = SpreadsheetApp.openById(sheetId);
        const tabName = body.tabName || "";
        const number  = String(body.number || "").replace(/\D/g, "").replace(/^0+/, "");
        const colName = body.colName || "";
        const value   = body.value !== undefined ? body.value : "";

        // tabName se sheet dhundho, fallback gid/first sheet
        let sheet;
        if (tabName) {
          sheet = ss.getSheets().find(function(s){ return s.getName() === tabName; });
        }
        if (!sheet) sheet = gid ? getSheetByGid(ss, gid) : ss.getSheets()[0];
        if (!sheet) throw new Error("Sheet nahi mili: " + tabName);

        const headers  = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
        const targetCol = headers.indexOf(colName);
        if (targetCol < 0) throw new Error("Column nahi mila: " + colName);

        const allData = sheet.getDataRange().getValues();

        // Phone column auto-detect (numCol body se bhi le sakte hain)
        const numCol = body.numCol || "";
        let phoneColIdx = numCol ? headers.indexOf(numCol) : -1;
        if (phoneColIdx < 0) {
          phoneColIdx = headers.findIndex(function(h){
            return /phone|number|mobile|whatsapp|contact/i.test(h);
          });
        }
        if (phoneColIdx < 0) throw new Error("Phone column nahi mila sheet mein");

        // Row dhundho — last 10 digits match
        const searchNum = number.slice(-10);
        let updatedCell = false;
        for (let i = 1; i < allData.length; i++) {
          const cellNum = String(allData[i][phoneColIdx]||"").replace(/\D/g,"").replace(/^0+/,"").slice(-10);
          if (cellNum === searchNum) {
            sheet.getRange(i + 1, targetCol + 1).setValue(value);
            updatedCell = true;
            result = { ok: true, updated: true, row: i, col: targetCol };
            break;
          }
        }
        if (!updatedCell) {
          result = { ok: false, error: "Row nahi mili number: " + number + " (sheet: " + (tabName||"?") + ")" };
        }
        break;
      }

      default:
        result = { ok: false, error: "Unknown POST action: " + action };
    }

    return jsonResponse(result);

  } catch (err) {
    return jsonResponse({ ok: false, error: err.message });
  }
}

// ─── Helper: GID se sheet dhundho ───────────────────────────────────────────
function getSheetByGid(ss, gid) {
  return ss.getSheets().find(s => String(s.getSheetId()) === String(gid)) || null;
}

// ─── Helper: Headers ensure karo (naye columns add karo) ────────────────────
function ensureHeaders(sheet, newKeys) {
  if (!newKeys || newKeys.length === 0) return;
  const lastCol = sheet.getLastColumn();
  if (lastCol === 0) {
    sheet.getRange(1, 1, 1, newKeys.length).setValues([newKeys]);
    return;
  }
  const existing    = sheet.getRange(1, 1, 1, lastCol).getValues()[0].map(String);
  const existingSet = new Set(existing);
  const toAdd       = newKeys.filter(k => k && !existingSet.has(k));
  if (toAdd.length > 0) {
    sheet.getRange(1, lastCol + 1, 1, toAdd.length).setValues([toAdd]);
  }
}


// ════════════════════════════════════════════════════════════════════════════
// 📱 LIVE MOBILE DASHBOARD — Full PWA served from Google Apps Script
// ════════════════════════════════════════════════════════════════════════════

function serveDashboard(e) {
  const sheetId = (e.parameter.sheetId || "").trim();
  const pin     = (e.parameter.pin     || "").trim();
  const reqPin  = (e.parameter.reqPin  || "").trim();

  // ── LAYER 1: Allowed SheetId whitelist (aapke clients ki sheets) ──
  // Agar aap chahte hain ki sirf aapke diye hue sheets kaam kare toh
  // ALLOWED_SHEETS mein add karo. Empty rakhne pe sab allow hoga.
  const ALLOWED_SHEETS = []; // e.g. ["sheetId1","sheetId2"]
  if (ALLOWED_SHEETS.length > 0 && !ALLOWED_SHEETS.includes(sheetId)) {
    return HtmlService.createHtmlOutput(
      '<div style="font-family:sans-serif;background:#0f172a;color:#ef4444;display:flex;align-items:center;justify-content:center;min-height:100vh;font-size:18px;font-weight:700">❌ Unauthorized Access</div>'
    ).setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  }

  // Optional PIN protection
  if (reqPin && pin !== reqPin) {
    const pinHtml = `<!DOCTYPE html><html><head><meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>WA Dashboard — Login</title>
    <style>*{box-sizing:border-box}body{font-family:sans-serif;background:#0f172a;color:#e2e8f0;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}
    .box{background:#1e293b;border-radius:16px;padding:32px;width:90%;max-width:360px;text-align:center}
    h2{color:#25D366;margin-bottom:8px}p{color:#94a3b8;font-size:13px;margin-bottom:20px}
    input{width:100%;padding:12px;border-radius:8px;border:1px solid #334155;background:#0f172a;color:#e2e8f0;font-size:18px;text-align:center;letter-spacing:8px;margin-bottom:12px}
    button{width:100%;padding:12px;border-radius:8px;background:#25D366;color:#fff;font-weight:700;font-size:15px;border:none;cursor:pointer}</style></head>
    <body><div class="box"><h2>🔐 WA Dashboard</h2><p>PIN enter karo</p>
    <form id="f"><input type="password" id="p" maxlength="8" placeholder="••••" autofocus>
    <button type="submit">Open Dashboard</button></form></div>
    <script>document.getElementById('f').onsubmit=function(ev){ev.preventDefault();
    const url=new URL(location.href);url.searchParams.set('pin',document.getElementById('p').value);location.href=url.toString();}
    <\/script></body></html>`;
    return HtmlService.createHtmlOutput(pinHtml).setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  }

  // Fetch all sheets data
  const allTabs = [];
  const statsMap = { total:0, messaged:0, replied:0, blocked:0 };

  if (sheetId) {
    try {
      const ss = SpreadsheetApp.openById(sheetId);
      ss.getSheets().forEach(function(sheet) {
        try {
          const vals = sheet.getDataRange().getValues();
          if (vals.length < 2) { allTabs.push({name:sheet.getName(),headers:[],rows:[]}); return; }
          const headers = vals[0].map(String);
          const rows = vals.slice(1).map(function(row) {
            const obj = {}; headers.forEach(function(h,i){ obj[h] = row[i]!==undefined?String(row[i]):""; }); return obj;
          });
          // Stats: detect status column
          const sCol = headers.find(function(h){ return /status/i.test(h); });
          const pCol = headers.find(function(h){ return /phone|number|mobile|whatsapp/i.test(h); });
          rows.forEach(function(r) {
            if(pCol && r[pCol]) statsMap.total++;
            if(sCol) {
              const s = (r[sCol]||"").toLowerCase();
              if(s==="messaged"||s==="sent") statsMap.messaged++;
              if(s==="replied") statsMap.replied++;
              if(s==="blocked") statsMap.blocked++;
            }
          });
          allTabs.push({name:sheet.getName(), headers:headers, rows:rows});
        } catch(ex) { allTabs.push({name:sheet.getName(), headers:[], rows:[], error:ex.message}); }
      });
    } catch(ex) {
      allTabs.push({name:"Error", headers:[], rows:[], error:ex.message});
    }
  }

  const tabsJson    = JSON.stringify(allTabs);
  const statsJson   = JSON.stringify(statsMap);
  const genTime     = new Date().toLocaleString("en-IN", {timeZone:"Asia/Kolkata"});
  const scriptUrl   = ScriptApp.getService().getUrl();
  const dashboardUrl = scriptUrl + "?action=dashboard&sheetId=" + encodeURIComponent(sheetId);

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<meta name="theme-color" content="#128C7E">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="WA Dashboard">
<link rel="manifest" href="data:application/json,${encodeURIComponent(JSON.stringify({
  name:"WA Bulk Sender Dashboard",short_name:"WA Dashboard",
  start_url:dashboardUrl,display:"standalone",
  background_color:"#0f172a",theme_color:"#128C7E",
  icons:[{src:"https://www.gstatic.com/images/icons/material/system/2x/chat_white_24dp.png",sizes:"192x192",type:"image/png"}]
}))}">
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Cache-Control" content="no-store,no-cache">
<title>📱 WA Dashboard</title>
<style>
/* ── LAYER 2: Anti-Copy / Anti-Select CSS ── */
body { -webkit-user-select:none!important; -moz-user-select:none!important; user-select:none!important; }
/* Allow select only on editable cells */
.ie-cell, input, select, textarea { -webkit-user-select:text!important; user-select:text!important; }
/* Hide scrollbar in print */
@media print { body { display:none!important; } }
:root{--green:#25D366;--dark-green:#128C7E;--bg:#0f172a;--card:#1e293b;--border:#334155;--text:#e2e8f0;--muted:#64748b;--red:#ef4444;--blue:#3b82f6;--yellow:#f59e0b}
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;overscroll-behavior:none}
/* Header */
.hdr{background:linear-gradient(135deg,var(--dark-green),var(--green));padding:env(safe-area-inset-top,0) 0 0;position:sticky;top:0;z-index:100;box-shadow:0 2px 20px #0008}
.hdr-inner{padding:14px 16px 12px;display:flex;align-items:center;justify-content:space-between}
.hdr h1{font-size:16px;font-weight:700;color:#fff;white-space:nowrap}
.hdr p{font-size:10px;color:#dcfce7;margin-top:1px}
.refresh-btn{background:#ffffff22;border:1px solid #ffffff44;color:#fff;border-radius:8px;padding:7px 12px;font-size:12px;font-weight:600;cursor:pointer;white-space:nowrap;display:flex;align-items:center;gap:5px}
.refresh-btn:active{background:#ffffff44}
/* Stats */
.stats{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;padding:12px}
.sc{background:var(--card);border-radius:14px;padding:14px 12px;text-align:center;border:1px solid var(--border);position:relative;overflow:hidden}
.sc::before{content:"";position:absolute;inset:0;background:linear-gradient(135deg,currentColor,transparent);opacity:.04}
.sc .v{font-size:30px;font-weight:800;line-height:1}
.sc .l{font-size:10px;color:var(--muted);margin-top:4px;font-weight:600;text-transform:uppercase;letter-spacing:.04em}
/* Tabs */
.tabs{display:flex;border-bottom:2px solid var(--border);margin:0 12px;overflow-x:auto;-webkit-overflow-scrolling:touch;scrollbar-width:none}
.tabs::-webkit-scrollbar{display:none}
.tab{flex-shrink:0;padding:10px 14px;font-size:12px;font-weight:700;cursor:pointer;color:var(--muted);border:none;border-bottom:2px solid transparent;margin-bottom:-2px;background:none;transition:.2s;white-space:nowrap}
.tab.active{color:var(--green);border-bottom-color:var(--green)}
.tb{display:none;padding:12px}.tb.active{display:block}
/* Search */
.sb{width:100%;background:var(--card);border:1.5px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:14px;margin-bottom:10px;outline:none;transition:.2s}
.sb:focus{border-color:var(--green);box-shadow:0 0 0 3px #25D36622}
/* Table */
.tw{overflow-x:auto;border-radius:10px;border:1px solid var(--border);-webkit-overflow-scrolling:touch}
table{width:100%;border-collapse:collapse;font-size:12px}
th{background:var(--card);padding:9px 12px;text-align:left;font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:.04em;white-space:nowrap;position:sticky;top:0;z-index:2;border-bottom:1px solid var(--border)}
td{padding:10px 12px;border-top:1px solid var(--border);white-space:nowrap;vertical-align:middle}
tr:active td{background:var(--card)}
/* Sheet tabs */
.stabs{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px}
.stab{padding:6px 14px;border-radius:20px;background:var(--card);color:var(--muted);font-size:12px;font-weight:600;cursor:pointer;border:1.5px solid var(--border);transition:.15s;white-space:nowrap}
.stab.active{background:var(--green);color:#fff;border-color:var(--green)}
.stbody{display:none}.stbody.active{display:block}
/* Badges */
.badge{display:inline-block;padding:3px 9px;border-radius:999px;font-size:10px;font-weight:700}
.slbl{font-size:10px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px;display:flex;align-items:center;gap:8px}
.live-dot{width:7px;height:7px;background:var(--green);border-radius:50%;display:inline-block;animation:pulse 2s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
/* Stats cards colors */
.c-green{color:var(--green)}.c-blue{color:var(--blue)}.c-red{color:var(--red)}.c-yellow{color:var(--yellow)}
/* Campaign card */
.camp-card{background:var(--card);border-radius:12px;border:1px solid var(--border);padding:14px;margin-bottom:8px}
.camp-card h3{font-size:14px;font-weight:700;margin-bottom:6px}
.camp-meta{display:flex;gap:8px;flex-wrap:wrap}
.camp-pill{background:var(--bg);border-radius:6px;padding:4px 10px;font-size:11px;color:var(--muted)}
/* Inline Edit */
.ie-cell{cursor:pointer;border-radius:6px;padding:3px 6px;transition:.15s;min-width:30px;display:inline-block;outline:none}
.ie-cell:hover{background:#ffffff12}
.ie-cell:focus{background:var(--card);border:1.5px solid var(--green);outline:none;box-shadow:0 0 0 3px #25D36622;cursor:text}
.ie-cell:empty::before{content:"—";color:var(--muted)}
.ie-status-select{background:transparent;border:1.5px solid transparent;border-radius:8px;color:inherit;font-size:12px;font-weight:700;padding:2px 6px;cursor:pointer;outline:none;width:100%}
.ie-status-select:focus,.ie-status-select:hover{border-color:var(--green);background:var(--card)}
.saving-flash{animation:flash .4s ease}
@keyframes flash{0%{opacity:.3}100%{opacity:1}}
.toast-mini{position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:#1e293b;border:1px solid var(--green);color:var(--text);padding:8px 18px;border-radius:20px;font-size:12px;font-weight:600;z-index:9999;opacity:0;transition:.3s;pointer-events:none}
.toast-mini.show{opacity:1}
/* Loading */
.loading{display:flex;align-items:center;justify-content:center;padding:40px;flex-direction:column;gap:12px;color:var(--muted)}
.spinner{width:32px;height:32px;border:3px solid var(--border);border-top-color:var(--green);border-radius:50%;animation:spin .8s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
/* No data */
.empty{text-align:center;padding:32px;color:var(--muted);font-size:13px}
/* WA btn */
.wa-btn{display:inline-flex;align-items:center;gap:4px;color:var(--green);font-weight:700;text-decoration:none;font-size:12px}
.wa-btn:active{opacity:.7}
/* Footer */
.ftr{text-align:center;padding:20px 16px;color:var(--border);font-size:11px;border-top:1px solid var(--border);margin-top:8px}
/* Install banner */
.install-bar{background:#1e293b;border:1px solid var(--green);border-radius:12px;margin:0 12px 4px;padding:10px 14px;display:flex;align-items:center;justify-content:space-between;gap:10px;font-size:12px}
.install-bar button{background:var(--green);color:#fff;border:none;border-radius:7px;padding:7px 14px;font-size:12px;font-weight:700;cursor:pointer;white-space:nowrap}
/* Responsive */
@media(max-width:380px){.sc .v{font-size:24px}.stats{gap:6px;padding:8px}}
</style>
</head>
<body>

<div class="toast-mini" id="toast"></div>

<div class="hdr">
  <div class="hdr-inner">
    <div>
      <h1>📱 WA Bulk Sender Dashboard</h1>
      <p id="genTime">Last updated: ${genTime}</p>
    </div>
    <button class="refresh-btn" onclick="refreshData()">
      <span id="refreshIcon">🔄</span> Refresh
    </button>
  </div>
</div>



<div id="installBanner" class="install-bar" style="display:none">
  <span>📲 Home Screen par install karo — har baar browser open nahi karna padega</span>
  <button onclick="installPWA()">Install</button>
</div>

<div class="tabs">
  <button class="tab active" onclick="sw('sheet',this)">📊 Sheet Data</button>
  <button class="tab" onclick="sw('search',this)">🔍 Search</button>
  <button class="tab" onclick="sw('stats',this)">📈 Analytics</button>
  <button class="tab" onclick="sw('camp',this)">📣 Campaigns</button>
</div>

<!-- SHEET DATA TAB -->
<div id="tb-sheet" class="tb active">
  <div class="slbl"><span class="live-dot"></span> Live Sheet Data</div>
  <div id="sheetTabsArea"></div>
</div>

<!-- GLOBAL SEARCH TAB -->
<div id="tb-search" class="tb">
  <div class="slbl">🔍 Search All Data</div>
  <input class="sb" id="gSearch" placeholder="Number, name, status, city..." oninput="globalSearch(this.value)" autocomplete="off" autocorrect="off" spellcheck="false">
  <div id="searchResults"><div class="empty">Kuch type karo...</div></div>
</div>

<!-- ANALYTICS TAB -->
<div id="tb-stats" class="tb">
  <div class="slbl">📈 Analytics</div>
  <div id="analyticsContent"></div>
</div>

<!-- CAMPAIGNS TAB -->
<div id="tb-camp" class="tb">
  <div class="slbl">📣 Campaigns</div>
  <div id="campContent"><div class="empty">Loading...</div></div>
</div>

<div class="ftr">
  WA Bulk Sender &nbsp;•&nbsp; Powered by <strong style="color:var(--green)">WA Manager</strong>
  &nbsp;•&nbsp; <span style="font-size:10px;color:var(--border)">© 2026 All Rights Reserved. Unauthorized copying prohibited.</span>
</div>

<script>
// ── Data (injected at serve time) ──
const SHEET_ID   = ${JSON.stringify(sheetId)};
const SCRIPT_URL = ${JSON.stringify(scriptUrl)};
let   allTabs    = ${tabsJson};
let   deferredPrompt = null;

// ── PWA Install ──
window.addEventListener('beforeinstallprompt', e => {
  e.preventDefault(); deferredPrompt = e;
  document.getElementById('installBanner').style.display = 'flex';
});
function installPWA() {
  if (!deferredPrompt) { alert('Browser prompt nahi aaya. Manually: Share → Add to Home Screen'); return; }
  deferredPrompt.prompt();
  deferredPrompt.userChoice.then(() => { document.getElementById('installBanner').style.display='none'; deferredPrompt=null; });
}

// ── Tab switching ──
function sw(id, el) {
  document.querySelectorAll('.tb').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.getElementById('tb-'+id).classList.add('active');
  el.classList.add('active');
  if (id==='stats') buildAnalytics();
  if (id==='camp')  buildCampaigns();
}
function switchSTab(i, el) {
  document.querySelectorAll('.stbody').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.stab').forEach(t => t.classList.remove('active'));
  document.getElementById('st-'+i).classList.add('active');
  el.classList.add('active');
}

// ── Escape HTML ──
function esc(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

// ── Detect phone column ──
function phoneCol(headers) { return headers.findIndex(h => /phone|number|mobile|whatsapp|contact/i.test(h)); }
function statusCol(headers){ return headers.findIndex(h => /^status$/i.test(h)); }
function nameCol(headers)  { return headers.findIndex(h => /name/i.test(h)); }

// ── Status badge ──
function statusBadge(val) {
  const v = (val||'').toLowerCase();
  const color = v==='messaged'||v==='sent'?'#22c55e':v==='replied'?'#3b82f6':v==='blocked'?'#ef4444':'#64748b';
  return '<span class="badge" style="background:'+color+'22;color:'+color+';border:1px solid '+color+'44">'+esc(val||'New')+'</span>';
}

// ── Build WA link ──
function waLink(num) {
  const clean = String(num).replace(/\\D/g,'');
  return '<a class="wa-btn" href="https://wa.me/'+clean+'" target="_blank">'+esc(num)+' <svg width="14" height="14" viewBox="0 0 24 24" fill="#25D366"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg></a>';
}

// ── Render Sheet Tabs ──
function renderSheetTabs() {
  const area = document.getElementById('sheetTabsArea');
  if (!allTabs.length) { area.innerHTML = '<div class="empty">Koi sheet data nahi mila.</div>'; return; }

  let btns = '<div class="stabs">';
  let bodies = '';
  allTabs.forEach(function(tab, i) {
    btns += '<button class="stab'+(i===0?' active':'')+'" onclick="switchSTab('+i+',this)">'+esc(tab.name)+' <small style="opacity:.6">('+( tab.rows?tab.rows.length:0)+')</small></button>';

    let body = '';
    if (tab.error) {
      body = '<div class="empty" style="color:#fca5a5">⚠️ '+esc(tab.error)+'</div>';
    } else if (!tab.headers || !tab.headers.length) {
      body = '<div class="empty">No data</div>';
    } else {
      const pi = phoneCol(tab.headers);
      const si = statusCol(tab.headers);
      // Per-tab search
      body += '<input class="sb" placeholder="🔍 '+esc(tab.name)+' mein search..." oninput="filterTab('+i+',this.value)" autocomplete="off" autocorrect="off" spellcheck="false">';
      body += '<div class="tw"><table><thead><tr>';
      tab.headers.forEach(function(h, hi) { body += '<th>'+esc(h)+(hi!==pi?' ✏️':'')+'</th>'; });
      body += '</tr></thead><tbody id="tbody-'+i+'">';
      tab.rows.forEach(function(r, rowIdx) {
        body += '<tr>';
        tab.headers.forEach(function(h,ci) {
          const v = r[h]||'';
          if (ci===pi && v) body += '<td>'+waLink(v)+'</td>';
          else if (ci===pi && !v) body += '<td>'+esc(v)+'</td>';
          else if (ci===si) {
            // Inline status dropdown
            body += '<td><select class="ie-status-select" data-tab="'+i+'" data-row="'+rowIdx+'" data-col="'+esc(h)+'" data-num="'+esc(pi>=0?r[tab.headers[pi]]:'')+'">'
              +['New','Messaged','Replied','Interested','Not Interested','Blocked'].map(function(opt){
                return '<option value="'+opt+'"'+(v===opt?' selected':'')+'>'+opt+'</option>';
              }).join('')
              +'</select></td>';
          }
          else {
            // Sab columns inline editable
            body += '<td><span class="ie-cell" contenteditable="true" spellcheck="false" data-tab="'+i+'" data-row="'+rowIdx+'" data-col="'+esc(h)+'" data-num="'+esc(pi>=0?r[tab.headers[pi]]:'')+'" data-orig="'+esc(v)+'">'+esc(v)+'</span></td>';
          }
        });
        body += '</tr>';
      });
      body += '</tbody></table></div>';
      body += '<div style="text-align:right;font-size:10px;color:var(--muted);margin-top:6px">'+tab.rows.length+' rows</div>';
    }
    bodies += '<div id="st-'+i+'" class="stbody'+(i===0?' active':'')+'">'+body+'</div>';
  });
  btns += '</div>';
  area.innerHTML = btns + bodies;
}

// ── Per-tab filter ──
function filterTab(tabIdx, q) {
  const q2 = q.toLowerCase();
  document.querySelectorAll('#tbody-'+tabIdx+' tr').forEach(function(r) {
    r.style.display = r.textContent.toLowerCase().includes(q2) ? '' : 'none';
  });
}

// ── Global Search ──
let searchTimer;
function globalSearch(q) {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(function() {
    const box = document.getElementById('searchResults');
    if (q.length < 2) { box.innerHTML = '<div class="empty">2 ya zyada characters likho...</div>'; return; }
    const q2 = q.toLowerCase();
    let results = [];
    allTabs.forEach(function(tab) {
      if (!tab.rows) return;
      const pi = phoneCol(tab.headers);
      const si = statusCol(tab.headers);
      const ni = nameCol(tab.headers);
      tab.rows.forEach(function(r) {
        const text = Object.values(r).join(' ').toLowerCase();
        if (!text.includes(q2)) return;
        const phone = pi>=0?r[tab.headers[pi]]:'';
        const name  = ni>=0?r[tab.headers[ni]]:'';
        const status= si>=0?r[tab.headers[si]]:'';
        results.push({phone,name,status,tab:tab.name,row:r,headers:tab.headers,pi,si});
      });
    });

    if (!results.length) { box.innerHTML = '<div class="empty">Koi result nahi mila 😔</div>'; return; }

    let html = '<div style="font-size:11px;color:var(--muted);margin-bottom:8px">'+results.length+' results</div><div class="tw"><table><thead><tr><th>Number</th><th>Name</th><th>Status</th><th>Sheet</th>';
    // Extra columns from first result
    const extraCols = results[0].headers.filter(function(h,i){ return i!==results[0].pi && i!==results[0].si && nameCol([h])<0 && results[0].headers.indexOf(h)===i; }).slice(0,3);
    extraCols.forEach(function(h){ html+='<th>'+esc(h)+'</th>'; });
    html += '</tr></thead><tbody>';
    results.slice(0,100).forEach(function(res) {
      html += '<tr>';
      html += '<td>'+(res.phone?waLink(res.phone):'-')+'</td>';
      html += '<td>'+esc(res.name||'-')+'</td>';
      html += '<td>'+statusBadge(res.status)+'</td>';
      html += '<td><span style="font-size:10px;background:var(--card);padding:2px 6px;border-radius:4px;">'+esc(res.tab)+'</span></td>';
      extraCols.forEach(function(h){ html+='<td>'+esc(res.row[h]||'')+'</td>'; });
      html += '</tr>';
    });
    if(results.length>100) html+='<tr><td colspan="'+(4+extraCols.length)+'" style="text-align:center;color:var(--muted);font-size:11px;padding:8px">...aur '+(results.length-100)+' results (search refine karo)</td></tr>';
    html += '</tbody></table></div>';
    box.innerHTML = html;
  }, 250);
}

// ── Analytics ──
function buildAnalytics() {
  const box = document.getElementById('analyticsContent');
  if (box.dataset.built) return;
  box.dataset.built = '1';

  let totalRows=0, byStatus={}, bySheet={}, phoneNums=new Set();
  allTabs.forEach(function(tab) {
    if (!tab.rows) return;
    const si = statusCol(tab.headers);
    const pi = phoneCol(tab.headers);
    bySheet[tab.name] = tab.rows.length;
    totalRows += tab.rows.length;
    tab.rows.forEach(function(r) {
      if(pi>=0 && r[tab.headers[pi]]) phoneNums.add(r[tab.headers[pi]]);
      if(si>=0){ const s=r[tab.headers[si]]||'New'; byStatus[s]=(byStatus[s]||0)+1; }
    });
  });

  // Bar chart with CSS
  function bar(label, val, max, color) {
    const pct = max?Math.round(val/max*100):0;
    return '<div style="margin-bottom:10px"><div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px"><span>'+esc(label)+'</span><span style="font-weight:700;color:'+color+'">'+val+'</span></div><div style="background:var(--border);border-radius:999px;height:8px;overflow:hidden"><div style="background:'+color+';width:'+pct+'%;height:100%;border-radius:999px;transition:.5s"></div></div></div>';
  }

  let html = '';
  // Summary cards
  html += '<div class="stats" style="padding:0;margin-bottom:12px">';
  html += '<div class="sc"><div class="v c-green">'+totalRows+'</div><div class="l">Total Rows</div></div>';
  html += '<div class="sc"><div class="v c-blue">'+phoneNums.size+'</div><div class="l">Unique Numbers</div></div>';
  html += '</div>';

  // Status breakdown
  if(Object.keys(byStatus).length) {
    html += '<div class="slbl">Status Breakdown</div>';
    const maxS = Math.max(...Object.values(byStatus));
    const colors={'Messaged':'#22c55e','Sent':'#22c55e','Replied':'#3b82f6','Blocked':'#ef4444','New':'#64748b'};
    Object.entries(byStatus).sort((a,b)=>b[1]-a[1]).forEach(function(e){ html+=bar(e[0],e[1],maxS,colors[e[0]]||'#8b5cf6'); });
  }

  // Sheet breakdown
  if(Object.keys(bySheet).length>1) {
    html += '<div class="slbl" style="margin-top:12px">Rows per Sheet</div>';
    const maxR = Math.max(...Object.values(bySheet));
    Object.entries(bySheet).forEach(function(e){ html+=bar(e[0],e[1],maxR,'#8b5cf6'); });
  }

  box.innerHTML = html;
}

// ── Campaigns (from local storage via extension — not available in PWA) ──
function buildCampaigns() {
  const box = document.getElementById('campContent');
  if (box.dataset.built) return;
  box.dataset.built = '1';
  box.innerHTML = '<div class="empty" style="padding:24px">📣 Campaigns extension ke local storage mein hain.<br><br>Desktop par extension kholo → Campaigns tab dekho.<br><br style="margin:4px"><span style="color:var(--green);font-size:12px">Tip: Campaigns bhi sheet mein save karne ka feature agle update mein aayega.</span></div>';
}

// ── Refresh Data ──
async function refreshData() {
  const icon = document.getElementById('refreshIcon');
  icon.style.animation='spin .5s linear infinite';
  try {
    const url = SCRIPT_URL+'?action=dashboard&sheetId='+encodeURIComponent(SHEET_ID)+'&_t='+Date.now();
    const resp = await fetch(url);
    const text = await resp.text();
    // Extract JSON from injected allTabs
    const m = text.match(/let\\s+allTabs\\s*=\\s*(\\[.*?\\]);/s);
    if(m) {
      allTabs = JSON.parse(m[1]);
      renderSheetTabs();
      document.getElementById('genTime').textContent = 'Last updated: '+new Date().toLocaleString('en-IN',{timeZone:'Asia/Kolkata'});
      document.getElementById('analyticsContent').removeAttribute('data-built');
      buildAnalytics();
    }
  } catch(e) { alert('Refresh failed: '+e.message); }
  icon.style.animation='';
}

// ── Toast ──
let toastTimer;
function showToast(msg, color) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.style.borderColor = color||'var(--green)';
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function(){ t.classList.remove('show'); }, 2500);
}

// ── Inline Edit: updateCell via GET (CORS fix) ──
async function updateCell(tabName, number, colName, newVal, elRef) {
  if (!SHEET_ID) { showToast('❌ Sheet ID missing', '#ef4444'); return; }
  if (elRef) elRef.style.opacity = '0.4';
  try {
    const params = new URLSearchParams({
      action:   'updateCell',
      sheetId:  SHEET_ID,
      tabName:  tabName || '',
      number:   number  || '',
      colName:  colName,
      value:    newVal
    });
    const resp = await fetch(SCRIPT_URL + '?' + params.toString());
    const data = await resp.json();
    if (data.ok) {
      showToast('✅ Saved: ' + colName + ' → ' + newVal);
      if (elRef) { elRef.classList.add('saving-flash'); setTimeout(function(){ elRef.classList.remove('saving-flash'); }, 500); }
    } else {
      showToast('❌ ' + (data.error || 'Update failed'), '#ef4444');
    }
  } catch(e) {
    showToast('❌ Network error: ' + e.message, '#ef4444');
  }
  if (elRef) elRef.style.opacity = '1';
}

// ── Bind inline edit events after render ──
function bindInlineEdits() {
  // Status dropdowns
  document.querySelectorAll('.ie-status-select').forEach(function(sel) {
    sel.addEventListener('change', function() {
      const ti = parseInt(sel.dataset.tab);
      const ri = parseInt(sel.dataset.row);
      const col = sel.dataset.col;
      const num = sel.dataset.num;
      const tabName = allTabs[ti] && allTabs[ti].name;
      const newVal = sel.value;
      // Update local data
      if (allTabs[ti] && allTabs[ti].rows[ri]) allTabs[ti].rows[ri][col] = newVal;
      updateCell(tabName, num, col, newVal, sel);
    });
  });

  // Contenteditable cells
  document.querySelectorAll('.ie-cell').forEach(function(span) {
    let origVal = span.dataset.orig || span.textContent;
    let isEditing = false;

    span.addEventListener('focus', function() {
      isEditing = true;
      origVal = span.textContent.trim();
      // Cursor end pe le jao
      const range = document.createRange();
      const sel = window.getSelection();
      range.selectNodeContents(span);
      range.collapse(false);
      sel.removeAllRanges();
      sel.addRange(range);
    });

    span.addEventListener('blur', function() {
      isEditing = false;
      const newVal = span.textContent.trim();
      // Agar value same hai ya bahut zyada characters aaye (garbage) toh revert
      if (newVal === origVal) return;
      if (newVal.length > 200) { span.textContent = origVal; return; }
      const ti = parseInt(span.dataset.tab);
      const ri = parseInt(span.dataset.row);
      const col = span.dataset.col;
      const num = span.dataset.num;
      const tabName = allTabs[ti] && allTabs[ti].name;
      if (allTabs[ti] && allTabs[ti].rows[ri]) allTabs[ti].rows[ri][col] = newVal;
      span.dataset.orig = newVal;
      updateCell(tabName, num, col, newVal, span);
    });

    // Paste — plain text only
    span.addEventListener('paste', function(e) {
      e.preventDefault();
      const text = (e.clipboardData || window.clipboardData).getData('text/plain').trim();
      document.execCommand('insertText', false, text);
    });

    span.addEventListener('keydown', function(e) {
      if (e.key === 'Enter') { e.preventDefault(); span.blur(); }
      if (e.key === 'Escape') { span.textContent = origVal; span.blur(); }
    });
  });
}

// ── LAYER 3: JS Security — Right-click, DevTools, Shortcuts block ──
(function(){
  // Right-click disable
  document.addEventListener('contextmenu', function(e){ e.preventDefault(); return false; });

  // F12, Ctrl+Shift+I/J/C/U, Ctrl+S, Ctrl+U block
  document.addEventListener('keydown', function(e){
    if (e.key==='F12') { e.preventDefault(); return false; }
    if (e.ctrlKey && e.shiftKey && ['I','J','C','K'].includes(e.key.toUpperCase())) { e.preventDefault(); return false; }
    if (e.ctrlKey && ['U','S','A'].includes(e.key.toUpperCase())) { e.preventDefault(); return false; }
  });

  // DevTools open detect — sirf bahut bada difference ho toh
  let devOpen = false;
  const threshold = 300; // increased to avoid false positives from browser bars
  setInterval(function(){
    const wDiff = window.outerWidth - window.innerWidth > threshold;
    const hDiff = window.outerHeight - window.innerHeight > threshold;
    if ((wDiff || hDiff) && !devOpen) {
      devOpen = true;
      document.body.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0f172a;color:#ef4444;font-family:sans-serif;font-size:20px;font-weight:700;text-align:center;padding:20px">🔒 Developer Tools band karo<br><small style="font-size:13px;color:#64748b;margin-top:8px;display:block">Security violation detected</small></div>';
    } else if (!wDiff && !hDiff) {
      devOpen = false;
    }
  }, 1000);

  // Text selection disable on non-editable elements
  document.addEventListener('selectstart', function(e){
    if (!e.target.isContentEditable && e.target.tagName !== 'INPUT' && e.target.tagName !== 'SELECT') {
      e.preventDefault();
    }
  });

  // Drag disable
  document.addEventListener('dragstart', function(e){ e.preventDefault(); });
})();

// ── Init ──
renderSheetTabs();
bindInlineEdits();
</script>
</body>
</html>`;

  return HtmlService.createHtmlOutput(html)
    .setTitle("WA Dashboard")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}
