/**
 * background.js
 * WhatsApp Unsaved Number Manager - Background Service Worker
 * Handles storage, alarms, scheduling, and notifications.
 */

"use strict";

// ─── REMINDER SYSTEM ──────────────────────────────────────────────────────
const ALARM_REMINDER = "wnum_reminder_check";
const REMIND_KEY = "wnum_reminders";

async function checkReminders() {
  const res = await chrome.storage.local.get(REMIND_KEY);
  const reminders = res[REMIND_KEY] || [];
  if (!reminders.length) return;
  const today = new Date(); today.setHours(0,0,0,0);
  let changed = false;
  reminders.forEach(r => {
    if (r.dismissed) return;
    const due = new Date(r.dueDate); due.setHours(0,0,0,0);
    const diff = Math.round((due - today) / (1000*60*60*24));
    const alertOn = (diff === r.alertDays) || (diff === 0) || (diff < 0 && diff >= -1);
    if (alertOn) {
      const lastNotif = r.lastNotifDate;
      const todayStr = today.toISOString().split('T')[0];
      if (lastNotif === todayStr) return; // already notified today
      let msg = diff > 0
        ? `📅 ${r.name} — ${diff} din mein due hai!`
        : diff === 0
        ? `🚨 ${r.name} — AAJ DUE HAI!`
        : `⚠️ ${r.name} — ${Math.abs(diff)} din OVERDUE!`;
      if (r.note) msg += "\n" + r.note;
      chrome.notifications.create('remind_' + r.id, {
        type: 'basic',
        iconUrl: 'icons/icon48.png',
        title: '🔔 WhatsApp Manager — Reminder',
        message: msg,
        priority: 2,
      });
      r.lastNotifDate = todayStr;
      changed = true;
    }
  });
  if (changed) await chrome.storage.local.set({ [REMIND_KEY]: reminders });
}

// Setup reminder alarm (run every hour)
async function setupReminderAlarm() {
  await chrome.alarms.clear(ALARM_REMINDER);
  chrome.alarms.create(ALARM_REMINDER, { delayInMinutes: 1, periodInMinutes: 60 });
}


// ─── Storage Keys ─────────────────────────────────────────────────────────
const STORAGE_KEY_NUMBERS = "wnum_numbers";
const STORAGE_KEY_TEMPLATES = "wnum_templates";
const STORAGE_KEY_CAMPAIGNS = "wnum_campaigns";
const STORAGE_KEY_FOLLOWUP_SEQS = "wnum_followup_sequences";
const STORAGE_KEY_BROADCAST_BLACKLIST = "wnum_broadcast_blacklist";
const ALARM_FOLLOWUP = "wa_manager_followup_check";

// ─── Campaign helpers ──────────────────────────────────────────────────────
async function getCampaigns() {
  const res = await chrome.storage.local.get(STORAGE_KEY_CAMPAIGNS);
  return res[STORAGE_KEY_CAMPAIGNS] || [];
}
async function saveCampaigns(campaigns) {
  await chrome.storage.local.set({ [STORAGE_KEY_CAMPAIGNS]: campaigns });
}
async function upsertCampaign(name, contacts) {
  const campaigns = await getCampaigns();
  const now = new Date().toISOString();
  const idx = campaigns.findIndex(c => c.name === name);
  if (idx >= 0) {
    // Merge contacts
    const existing = campaigns[idx];
    contacts.forEach(nc => {
      const ci = existing.contacts.findIndex(ec => ec.number === nc.number);
      if (ci >= 0) existing.contacts[ci] = { ...existing.contacts[ci], ...nc };
      else existing.contacts.push(nc);
    });
    existing.updatedAt = now;
    campaigns[idx] = existing;
  } else {
    campaigns.unshift({ name, contacts, createdAt: now, updatedAt: now });
  }
  await saveCampaigns(campaigns);
}

// ─── Follow-up sequence helpers ────────────────────────────────────────────
async function getFollowupSequences() {
  const res = await chrome.storage.local.get(STORAGE_KEY_FOLLOWUP_SEQS);
  return res[STORAGE_KEY_FOLLOWUP_SEQS] || [];
}
async function saveFollowupSequences(seqs) {
  await chrome.storage.local.set({ [STORAGE_KEY_FOLLOWUP_SEQS]: seqs });
}

// ─── Broadcast Blacklist helpers ───────────────────────────────────────────
async function getBroadcastBlacklist() {
  const res = await chrome.storage.local.get(STORAGE_KEY_BROADCAST_BLACKLIST);
  return res[STORAGE_KEY_BROADCAST_BLACKLIST] || [];
}
async function saveBroadcastBlacklist(list) {
  await chrome.storage.local.set({ [STORAGE_KEY_BROADCAST_BLACKLIST]: list });
}

// ─── Follow-up alarm: check every 30 min ──────────────────────────────────
async function setupFollowupAlarm() {
  await chrome.alarms.clear(ALARM_FOLLOWUP);
  chrome.alarms.create(ALARM_FOLLOWUP, { periodInMinutes: 30 });
}

async function runFollowupSequences() {
  const sequences = await getFollowupSequences();
  if (!sequences.length) return;
  const campaigns = await getCampaigns();
  const settings = await getSettings();
  const tabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
  if (tabs.length === 0) return;
  const tabId = tabs[0].id;
  const now = Date.now();
  const DAY = 86400000;
  let totalSent = 0;

  for (const seq of sequences) {
    if (!seq.enabled) continue;
    const campaign = campaigns.find(c => c.name === seq.campaignName);
    if (!campaign) continue;

    let targets = campaign.contacts.filter(c => {
      if (c.broadcastBlacklisted) return false;
      if (seq.target === "not_replied") return c.replied !== true;
      return true;
    });

    const days = [
      { day: 1, msg: seq.day1Msg, enabled: seq.day1Enable, key: "fu_day1_sent" },
      { day: 3, msg: seq.day3Msg, enabled: seq.day3Enable, key: "fu_day3_sent" },
      { day: 7, msg: seq.day7Msg, enabled: seq.day7Enable, key: "fu_day7_sent" },
    ];

    for (const contact of targets) {
      const sentAt = contact.sentAt ? new Date(contact.sentAt).getTime() : 0;
      if (!sentAt) continue;

      for (const { day, msg, enabled, key } of days) {
        if (!enabled || !msg) continue;
        if (contact[key]) continue; // already sent
        const dueAt = sentAt + day * DAY;
        if (now < dueAt) continue; // not due yet

        const finalMsg = msg
          .replace(/\{name\}/gi, contact.name || contact.number)
          .replace(/\{number\}/gi, contact.number)
          .replace(/\{amount\}/gi, contact.amount || "")
          .replace(/\{date\}/gi, new Date().toLocaleDateString("en-IN"));

        const delay = (settings.minDelay + Math.random() * (settings.maxDelay - settings.minDelay)) * 1000;
        await new Promise(r => setTimeout(r, delay));

        try {
          await chrome.tabs.sendMessage(tabId, { type: "SEND_MESSAGE", number: contact.number, message: finalMsg });
          // Mark sent
          const cs = await getCampaigns();
          const ci = cs.findIndex(c => c.name === seq.campaignName);
          if (ci >= 0) {
            const cti = cs[ci].contacts.findIndex(c => c.number === contact.number);
            if (cti >= 0) cs[ci].contacts[cti][key] = new Date().toISOString();
            await saveCampaigns(cs);
          }
          totalSent++;
          await appendSendLog({ time: new Date().toLocaleTimeString("en-IN"), date: new Date().toLocaleDateString("en-IN"), number: contact.number, name: contact.name || "", status: "sent", source: `followup-day${day}` });
        } catch(e) {
          console.warn("[WA Manager] Follow-up send failed:", e.message);
        }
      }
    }
  }
  if (totalSent > 0) {
    chrome.notifications.create({ type: "basic", iconUrl: "icons/icon48.png", title: "Follow-up Messages Sent", message: `✅ ${totalSent} follow-up messages sent`, priority: 1 });
  }
}

const STORAGE_KEY_SCHEDULE = "wnum_schedule";
const STORAGE_KEY_SETTINGS = "wnum_settings";
const STORAGE_KEY_SEND_LOG = "wnum_send_log";
const ALARM_DAILY = "wnum_daily_send";

// ─── Send Log helpers ──────────────────────────────────────────────────────
async function getSendLog() {
  const res = await chrome.storage.local.get(STORAGE_KEY_SEND_LOG);
  return res[STORAGE_KEY_SEND_LOG] || [];
}

async function appendSendLog(entry) {
  const log = await getSendLog();
  log.unshift(entry); // newest first
  if (log.length > 200) log.length = 200; // keep last 200 entries
  await chrome.storage.local.set({ [STORAGE_KEY_SEND_LOG]: log });
}

// ─── Default Settings ─────────────────────────────────────────────────────
const DEFAULT_SETTINGS = {
  darkMode: false,
  notificationsEnabled: true,
  dailyLimit: 50,
  minDelay: 3,   // seconds
  maxDelay: 8,   // seconds
  autoDetect: true,
  exportFormat: "csv",
};

// ─── Helpers ──────────────────────────────────────────────────────────────
async function getNumbers() {
  const res = await chrome.storage.local.get(STORAGE_KEY_NUMBERS);
  return res[STORAGE_KEY_NUMBERS] || [];
}

async function saveNumbers(numbers) {
  await chrome.storage.local.set({ [STORAGE_KEY_NUMBERS]: numbers });
}

async function getTemplates() {
  const res = await chrome.storage.local.get(STORAGE_KEY_TEMPLATES);
  return res[STORAGE_KEY_TEMPLATES] || [
    {
      id: "t1",
      name: "Welcome",
      text: "Hello! Thank you for reaching out. How can we help you today?",
    },
    {
      id: "t2",
      name: "Follow-up",
      text: "Hi! We noticed you contacted us. Please let us know if you need any assistance.",
    },
    {
      id: "t3",
      name: "Offer",
      text: "Hello! We have a special offer just for you. Reply to know more!",
    },
  ];
}

async function getSettings() {
  const res = await chrome.storage.local.get(STORAGE_KEY_SETTINGS);
  return { ...DEFAULT_SETTINGS, ...(res[STORAGE_KEY_SETTINGS] || {}) };
}

async function saveSettings(settings) {
  await chrome.storage.local.set({ [STORAGE_KEY_SETTINGS]: settings });
}

async function getSchedule() {
  const res = await chrome.storage.local.get(STORAGE_KEY_SCHEDULE);
  return res[STORAGE_KEY_SCHEDULE] || { enabled: false, time: "09:00", template: "t1" };
}

// ─── Add or update a number record ────────────────────────────────────────
async function upsertNumber(data) {
  const numbers = await getNumbers();
  const existingIdx = numbers.findIndex((n) => n.number === data.number);

  if (existingIdx >= 0) {
    // Update existing entry
    numbers[existingIdx] = {
      ...numbers[existingIdx],
      lastMessage: data.lastMessage || numbers[existingIdx].lastMessage,
      dateTime: data.dateTime,
      status: numbers[existingIdx].status, // preserve existing status
    };
  } else {
    // New entry
    numbers.unshift({
      ...data,
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    });
  }

  await saveNumbers(numbers);
  return numbers;
}

// ─── Show browser notification ─────────────────────────────────────────────
async function showNotification(number) {
  const settings = await getSettings();
  if (!settings.notificationsEnabled) return;

  chrome.notifications.create({
    type: "basic",
    iconUrl: "icons/icon48.png",
    title: "New Unsaved Number Detected",
    message: `📱 ${number} messaged you on WhatsApp Web`,
    priority: 1,
  });
}

// ─── Daily scheduled send logic ───────────────────────────────────────────
async function runScheduledSend() {
  const schedule = await getSchedule();
  if (!schedule.enabled) return;

  const numbers = await getNumbers();
  const templates = await getTemplates();
  const settings = await getSettings();

  const template = templates.find((t) => t.id === schedule.template) || templates[0];
  if (!template) return;

  // Get numbers that haven't been messaged today
  const today = new Date().toDateString();

  let targets = [];

  if (schedule.target === "sheet") {
    // ── Google Sheet target: use ONLY user-selected numbers from dashboard ──
    const stored = await chrome.storage.local.get(["scheduleSelectedNumbers", "scheduleContactData"]);
    const selectedNums = stored.scheduleSelectedNumbers || [];
    const contactData  = stored.scheduleContactData || [];  // full row objects with all columns

    if (selectedNums.length === 0) {
      console.warn("[WA Manager] Sheet target: no selected numbers saved.");
      return;
    }

    // Build a map: number -> full contact object (all sheet columns)
    const contactMap = {};
    contactData.forEach(row => {
      if (row.number) contactMap[row.number] = row;
    });

    targets = selectedNums.map(num => ({
      number: num,
      contactRow: contactMap[num] || {},   // ← entire sheet row for this number
    }));
  } else if (schedule.target === "new") {
    // Only numbers NOT messaged today
    targets = numbers.filter(
      (n) => !n.blacklisted && n.lastSentDate !== today
    );
  } else {
    // All unsaved numbers (default)
    targets = numbers.filter(
      (n) => !n.blacklisted && n.lastSentDate !== today
    );
  }

  targets = targets.slice(0, schedule.limit || settings.dailyLimit);

  if (targets.length === 0) return;

  // Find active WhatsApp tab
  const tabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
  if (tabs.length === 0) return;

  const tab = tabs[0];
  let sent = 0;

  for (const target of targets) {
    const delay =
      (settings.minDelay + Math.random() * (settings.maxDelay - settings.minDelay)) * 1000;

    await new Promise((r) => setTimeout(r, delay));

    // Replace ALL sheet column variables in template
    // Supports: {PARTY NAME}, {PAN NO}, {FILING NO.}, {NUMBER}, {{name}}, etc.
    let message = template.text;

    if (target.contactRow && Object.keys(target.contactRow).length > 0) {
      // Replace every column from the sheet row: {COLUMN NAME} and {{column name}}
      Object.entries(target.contactRow).forEach(([col, val]) => {
        if (col === "number") return; // handled separately
        const escaped = col.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        // Match {COL}, {COL NAME}, case-insensitive
        message = message.replace(new RegExp("\\{" + escaped + "\\}", "gi"), val || "");
        // Also match {{col}}
        message = message.replace(new RegExp("\\{\\{" + escaped + "\\}\\}", "gi"), val || "");
      });
    }

    // Standard fallbacks
    const partyName = (target.contactRow && (
      target.contactRow["PARTY NAME"] ||
      target.contactRow["party name"] ||
      target.contactRow["Party Name"] ||
      target.contactRow["name"] ||
      target.contactRow["Name"]
    )) || target.number;

    message = message
      .replace(/\{PARTY NAME\}/gi, partyName)
      .replace(/\{\{name\}\}/gi, partyName)
      .replace(/\{NUMBER\}/gi, target.number)
      .replace(/\{\{number\}\}/gi, target.number);

    const partyLabel = (target.contactRow && (
      target.contactRow["PARTY NAME"] || target.contactRow["party name"] ||
      target.contactRow["Party Name"] || target.contactRow["name"] || ""
    )) || "";
    const logTime = new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });

    try {
      // Multiple attachments support: schedule.attachments[] array use karo
      const attachList = (schedule.attachments && schedule.attachments.length)
        ? schedule.attachments
        : (schedule.fileBase64 ? [{ fileBase64: schedule.fileBase64, fileMime: schedule.fileMime || "application/octet-stream", fileFilename: schedule.fileFilename || "" }] : []);

      if (attachList.length > 0) {
        // Har file bhejo; pehli file ko message caption milta hai
        for (let fi = 0; fi < attachList.length; fi++) {
          const att = attachList[fi];
          const fileCaption = fi === 0 ? message : "";
          await chrome.tabs.sendMessage(tab.id, {
            type:       "SEND_FILE",
            number:     target.number,
            fileBase64: att.fileBase64,
            fileMime:   att.fileMime    || "application/octet-stream",
            caption:    fileCaption,
            filename:   att.fileFilename || "",
            fileType:   att.fileMime && att.fileMime.startsWith("image/") ? "image"
                      : att.fileMime === "application/pdf" ? "document"
                      : att.fileMime && att.fileMime.startsWith("video/") ? "video"
                      : att.fileMime && att.fileMime.startsWith("audio/") ? "audio"
                      : "auto-detect",
          }).catch(e => console.warn("[WA Manager] File send failed:", e));
          if (fi < attachList.length - 1) await new Promise(r => setTimeout(r, 800));
        }
      } else {
        // Sirf text message (koi attachment nahi)
        await chrome.tabs.sendMessage(tab.id, {
          type: "SEND_MESSAGE",
          number: target.number,
          message,
        });
      }

      // Update record
      const allNumbers = await getNumbers();
      const idx = allNumbers.findIndex((n) => n.number === target.number);
      if (idx >= 0) {
        allNumbers[idx].lastSentDate = today;
        allNumbers[idx].status = "Messaged";
        allNumbers[idx].sentCount = (allNumbers[idx].sentCount || 0) + 1;
        await saveNumbers(allNumbers);
      }
      sent++;

      // Log success
      await appendSendLog({
        time: logTime,
        date: new Date().toLocaleDateString("en-IN"),
        number: target.number,
        name: partyLabel,
        status: "sent",
        source: "scheduled",
      });

    } catch (e) {
      console.error(`[WA Manager] Failed to send to ${target.number}:`, e);
      // Log failure
      await appendSendLog({
        time: logTime,
        date: new Date().toLocaleDateString("en-IN"),
        number: target.number,
        name: partyLabel,
        status: "failed",
        error: e.message || "Unknown error",
        source: "scheduled",
      });
    }

    // Respect daily limit
    if (sent >= settings.dailyLimit) break;
  }

  // Save run summary at top of log
  const _runDate = new Date();
  const runTime = _runDate.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
  const runDateStr = _runDate.toLocaleDateString("en-IN");
  await appendSendLog({
    type: "summary",
    time: runTime,
    date: runDateStr,
    sent,
    total: targets.length,
    source: "scheduled",
  });

  chrome.notifications.create({
    type: "basic",
    iconUrl: "icons/icon48.png",
    title: "Scheduled Messages Sent",
    message: `✅ Sent: ${sent} | Failed: ${targets.length - sent} | Total: ${targets.length}`,
    priority: 1,
  });
}

// ─── Alarm Setup ──────────────────────────────────────────────────────────
async function setupAlarm() {
  const schedule = await getSchedule();
  if (!schedule.enabled) {
    await chrome.alarms.clear(ALARM_DAILY);
    return;
  }

  const [hours, minutes] = schedule.time.split(":").map(Number);
  const now = new Date();
  let next = new Date();
  next.setHours(hours, minutes, 0, 0);
  if (next <= now) next.setDate(next.getDate() + 1);

  const delayMinutes = (next - now) / 60000;
  await chrome.alarms.clear(ALARM_DAILY);
  chrome.alarms.create(ALARM_DAILY, {
    delayInMinutes: delayMinutes,
    periodInMinutes: 1440, // 24 hours
  });
}

// ─── UPDATE CHECKER (Background) ─────────────────────────────────────────
const ALARM_UPDATE_CHECK = "wa_update_check";
const UPDATE_CHECK_HOURS = 6;

async function bgCheckForUpdate() {
  try {
    const cfgData = await chrome.storage.local.get(["wa_updater_last_check"]);
    const lastCheck = cfgData["wa_updater_last_check"] || 0;
    const hoursSince = (Date.now() - lastCheck) / (1000 * 60 * 60);
    if (hoursSince < UPDATE_CHECK_HOURS) return;

    // VERSION_JSON_URL storage se lo (config.js ne save ki hogi)
    const urlData = await chrome.storage.local.get(["wa_version_json_url", "wa_current_version"]);
    const versionUrl = urlData["wa_version_json_url"];
    const currentVersion = chrome.runtime.getManifest().version; // Hamesha manifest.json se

    if (!versionUrl || versionUrl.includes("YAHAN")) return;

    const url = versionUrl + (versionUrl.includes("?") ? "&" : "?") + "t=" + Date.now();
    const resp = await fetch(url);
    if (!resp.ok) return;
    const data = await resp.json();

    await chrome.storage.local.set({ "wa_updater_last_check": Date.now() });

    const remoteVersion = String(data.version || "");
    if (!remoteVersion) return;

    // Version compare
    const parse = (v) => String(v).split(".").map((x) => parseInt(x, 10) || 0);
    const r = parse(remoteVersion), c = parse(currentVersion);
    let isNewer = false;
    for (let i = 0; i < Math.max(r.length, c.length); i++) {
      if ((r[i]||0) > (c[i]||0)) { isNewer = true; break; }
      if ((r[i]||0) < (c[i]||0)) break;
    }

    if (isNewer) {
      // Dismissed check
      const dismissed = await chrome.storage.local.get("wa_updater_dismissed_version");
      if (dismissed["wa_updater_dismissed_version"] === remoteVersion) return;

      chrome.notifications.create("wa_update_available", {
        type: "basic",
        iconUrl: "icons/icon48.png",
        title: "🔄 WA Manager — Update Available!",
        message: `New version v${remoteVersion} available! (Current: v${currentVersion})\n${data.changelog || ""}`,
        priority: 2,
        buttons: [{ title: "⬇️ Download" }, { title: "✕ Dismiss" }],
      });

      // Notification button click
      chrome.notifications.onButtonClicked.addListener((notifId, btnIdx) => {
        if (notifId !== "wa_update_available") return;
        if (btnIdx === 0 && data.download_url) {
          chrome.downloads.download({ url: data.download_url });
        } else if (btnIdx === 1) {
          chrome.storage.local.set({ "wa_updater_dismissed_version": remoteVersion });
        }
        chrome.notifications.clear("wa_update_available");
      });
    }
  } catch (e) {
    console.log("[BG Updater] Error:", e.message);
  }
}

// ─── Alarm listener ───────────────────────────────────────────────────────
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_DAILY) {
    runScheduledSend();
  }
  if (alarm.name === ALARM_REMINDER) {
    checkReminders();
  }
  if (alarm.name === ALARM_FOLLOWUP) {
    runFollowupSequences();
  }
  if (alarm.name === ALARM_UPDATE_CHECK) {
    bgCheckForUpdate();
  }
  if (alarm.name === ALARM_SYNC) {
    // Dashboard tabs ko TRIGGER_AUTO_SYNC message bhejo
    chrome.tabs.query({ url: "chrome-extension://*/*" }, (tabs) => {
      for (const t of tabs) {
        try { chrome.tabs.sendMessage(t.id, { type: "TRIGGER_AUTO_SYNC" }); } catch(e) {}
      }
    });
  }
});

// ─── Extension installed / startup ────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async () => {
  await setupAlarm();
  await setupReminderAlarm();
  await setupFollowupAlarm();
  // Update check alarm: har 6 ghante
  await chrome.alarms.clear(ALARM_UPDATE_CHECK);
  chrome.alarms.create(ALARM_UPDATE_CHECK, { delayInMinutes: 5, periodInMinutes: 360 });
  console.log("[WA Manager] Extension installed.");
});

chrome.runtime.onStartup.addListener(async () => {
  await setupAlarm();
  await setupReminderAlarm();
  await setupFollowupAlarm();
  checkReminders(); // Check on startup
  // Update check alarm
  await chrome.alarms.clear(ALARM_UPDATE_CHECK);
  chrome.alarms.create(ALARM_UPDATE_CHECK, { delayInMinutes: 2, periodInMinutes: 360 });
  bgCheckForUpdate(); // Startup pe bhi check karo
});

// ─── Message handler ──────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    switch (msg.type) {

      // ── New number detected by content script ──
      case "NEW_UNSAVED_NUMBER": {
        await upsertNumber(msg.data);
        await showNotification(msg.data.number);
        // Update badge count
        const nums = await getNumbers();
        chrome.action.setBadgeText({ text: String(nums.length) });
        chrome.action.setBadgeBackgroundColor({ color: "#00a884" });
        sendResponse({ ok: true });
        break;
      }

      // ── Forward Full Scan progress to popup ──
      case "FULL_SCAN_PROGRESS": {
        // Broadcast to all extension views (popup)
        chrome.runtime.sendMessage(msg).catch(() => {});
        sendResponse({ ok: true });
        break;
      }

      // ── Get all stored numbers ──
      case "GET_ALL_NUMBERS": {
        const numbers = await getNumbers();
        sendResponse({ numbers });
        break;
      }

      // ── Delete a number ──
      case "DELETE_NUMBER": {
        const list = await getNumbers();
        const updated = list.filter((n) => n.number !== msg.number);
        await saveNumbers(updated);
        sendResponse({ ok: true, count: updated.length });
        break;
      }

      // ── Update a number record ──
      case "UPDATE_NUMBER": {
        const list = await getNumbers();
        const idx = list.findIndex((n) => n.number === msg.data.number);
        if (idx >= 0) list[idx] = { ...list[idx], ...msg.data };
        await saveNumbers(list);
        sendResponse({ ok: true });
        break;
      }

      // ── Blacklist a number ──
      case "BLACKLIST_NUMBER": {
        const list = await getNumbers();
        const idx = list.findIndex((n) => n.number === msg.number);
        if (idx >= 0) list[idx].blacklisted = !list[idx].blacklisted;
        await saveNumbers(list);
        sendResponse({ ok: true });
        break;
      }

      // ── Clear all numbers ──
      case "CLEAR_ALL": {
        await saveNumbers([]);
        chrome.action.setBadgeText({ text: "" });
        sendResponse({ ok: true });
        break;
      }

      // ── Templates ──
      case "GET_TEMPLATES": {
        const templates = await getTemplates();
        sendResponse({ templates });
        break;
      }
      case "SAVE_TEMPLATES": {
        await chrome.storage.local.set({ [STORAGE_KEY_TEMPLATES]: msg.templates });
        sendResponse({ ok: true });
        break;
      }

      // ── Settings ──
      case "GET_SETTINGS": {
        const settings = await getSettings();
        sendResponse({ settings });
        break;
      }
      case "SAVE_SETTINGS": {
        await saveSettings(msg.settings);
        await setupAlarm();
        sendResponse({ ok: true });
        break;
      }

      // ── Schedule ──
      case "GET_SCHEDULE": {
        const schedule = await getSchedule();
        sendResponse({ schedule });
        break;
      }
      case "SAVE_SCHEDULE": {
        await chrome.storage.local.set({ [STORAGE_KEY_SCHEDULE]: msg.schedule });
        await setupAlarm();
        sendResponse({ ok: true });
        break;
      }

      case "GET_SEND_LOG": {
        const log = await getSendLog();
        sendResponse({ log });
        break;
      }

      case "APPEND_SEND_LOG": {
        await appendSendLog(msg.entry);
        sendResponse({ ok: true });
        break;
      }

      case "CLEAR_SEND_LOG": {
        await chrome.storage.local.set({ [STORAGE_KEY_SEND_LOG]: [] });
        sendResponse({ ok: true });
        break;
      }

      // ── Bulk import numbers ──
      case "IMPORT_NUMBERS": {
        const existing = await getNumbers();
        const existingSet = new Set(existing.map((n) => n.number));
        const newEntries = msg.numbers.filter((n) => !existingSet.has(n.number));
        const merged = [...newEntries, ...existing];
        await saveNumbers(merged);
        sendResponse({ ok: true, imported: newEntries.length });
        break;
      }

      // ── Trigger scheduled send manually ──
      case "MANUAL_SCHEDULED_SEND": {
        runScheduledSend();
        sendResponse({ ok: true });
        break;
      }

      // ── Send file/attachment to a specific number ──
      case "SEND_FILE_TO_NUMBER": {
        const tabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
        if (tabs.length === 0) { sendResponse({ ok: false, error: "WhatsApp tab nahi mili" }); break; }
        // Content.js ko message bhejo jo internally WPP_SEND_FILE use karega
        const result = await chrome.tabs.sendMessage(tabs[0].id, {
          type:       "SEND_FILE",
          number:     msg.number,
          fileBase64: msg.fileBase64 || "",
          fileMime:   msg.fileMime   || "application/octet-stream",
          caption:    msg.caption    || "",
          filename:   msg.filename   || "",
          fileType:   msg.fileType   || "auto-detect",
        });
        sendResponse({ ok: true, result });
        break;
      }

      // ── SEND_MESSAGE: Dashboard/broadcast se text message bhejo ──────────
      case "SEND_MESSAGE": {
        const waTabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
        if (waTabs.length === 0) {
          sendResponse({ success: false, reason: "WhatsApp tab nahi mili" });
          break;
        }
        const tabId = waTabs[0].id;

        // Method 1: Content.js ke zariye (DOM-based, reliable for open chats)
        try {
          const contentRes = await chrome.tabs.sendMessage(tabId, {
            type: "SEND_MESSAGE",
            number: msg.number,
            message: msg.message,
          });
          if (contentRes && contentRes.success) {
            sendResponse({ success: true, method: "content" });
            break;
          }
        } catch(e) {
          // Content.js send fail — fallback to WPP
        }

        // Method 2: WPP.chat.sendTextMessage via MAIN world (most reliable)
        let _clean = (msg.number || "").toString().replace(/\D/g, "").replace(/^0+/, "");
        if (_clean.length === 10 && /^[6-9]/.test(_clean)) _clean = "91" + _clean;
        const chatId = _clean + "@c.us";

        try {
          const results = await chrome.scripting.executeScript({
            target: { tabId },
            world: "MAIN",
            func: async (chatId, message) => {
              try {
                if (!window.WPP || !window.WPP.chat || !window.WPP.chat.sendTextMessage) {
                  return { success: false, reason: "WPP library loaded nahi hai" };
                }
                if (window.WPP.webpack && window.WPP.webpack.isReady) {
                  await window.WPP.webpack.isReady;
                }
                const result = await window.WPP.chat.sendTextMessage(chatId, message, { waitForAck: false });
                return { success: true, method: "WPP_MAIN", msgId: result?.id?.toString?.() || "" };
              } catch (err) {
                return { success: false, reason: err.message || String(err) };
              }
            },
            args: [chatId, msg.message || ""],
          });
          const res = results?.[0]?.result;
          sendResponse(res || { success: false, reason: "WPP script result nahi aaya" });
        } catch(err) {
          sendResponse({ success: false, reason: err.message });
        }
        break;
      }

      // ── WPP via MAIN world scripting (SheetWA wppconnect method) ──────────
      // content.js ISOLATED world se yeh request aata hai.
      // Hum yahan chrome.scripting.executeScript se MAIN world mein
      // WPP.chat.sendFileMessage directly call karte hain.
      case "WPP_SEND_FILE": {
        const waTabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
        if (waTabs.length === 0) { sendResponse({ success: false, reason: "WhatsApp tab nahi mili" }); break; }
        const tabId    = waTabs[0].id;
        let _cleanFile = msg.number.toString().replace(/\D/g, "").replace(/^0+/, "");
        if (_cleanFile.length === 10 && /^[6-9]/.test(_cleanFile)) _cleanFile = "91" + _cleanFile;
        const chatId   = _cleanFile + "@c.us";

        try {
          const results = await chrome.scripting.executeScript({
            target: { tabId },
            world: "MAIN",
            func: async (chatId, fileBase64, fileMime, filename, caption, fileType) => {
              try {
                // WPP available hai?
                if (!window.WPP || !window.WPP.chat || !window.WPP.chat.sendFileMessage) {
                  return { success: false, reason: "WPP library loaded nahi hai" };
                }

                // WPP webpack ready hone ka wait karo
                if (window.WPP.webpack && window.WPP.webpack.isReady) {
                  await window.WPP.webpack.isReady;
                }

                // base64 → File object
                const byteChars = atob(fileBase64);
                const bytes     = new Uint8Array(byteChars.length);
                for (let i = 0; i < byteChars.length; i++) bytes[i] = byteChars.charCodeAt(i);
                const file = new File([bytes], filename, { type: fileMime });

                // Mime se type auto-detect (SheetWA jaisa)
                let resolvedType = fileType;
                if (!resolvedType || resolvedType === "auto-detect") {
                  if (fileMime.startsWith("image/"))      resolvedType = "image";
                  else if (fileMime.startsWith("video/")) resolvedType = "video";
                  else if (fileMime.startsWith("audio/")) resolvedType = "audio";
                  else                                    resolvedType = "document";
                }

                // WPP.chat.sendFileMessage call (SheetWA wppconnect method)
                const result = await window.WPP.chat.sendFileMessage(chatId, file, {
                  type:       resolvedType,
                  caption:    caption  || "",
                  filename:   filename || file.name,
                  waitForAck: false,
                });

                return {
                  success: true,
                  method:  "WPP_MAIN",
                  msgId:   result?.id?.toString?.() || "",
                };
              } catch (err) {
                return { success: false, reason: err.message || String(err) };
              }
            },
            args: [
              chatId,
              msg.fileBase64  || "",
              msg.fileMime    || "application/octet-stream",
              msg.filename    || "file",
              msg.caption     || "",
              msg.fileType    || "auto-detect",
            ],
          });

          const res = results?.[0]?.result;
          sendResponse(res || { success: false, reason: "Script execution mein koi result nahi aaya" });
        } catch (err) {
          console.warn("[WA Manager] WPP scripting error:", err.message);
          sendResponse({ success: false, reason: err.message });
        }
        break;
      }

      // ── WPP Text Message via MAIN world scripting ──────────────────────────
      case "WPP_SEND_TEXT": {
        const waTabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
        if (waTabs.length === 0) { sendResponse({ success: false, reason: "WhatsApp tab nahi mili" }); break; }
        const tabId  = waTabs[0].id;
        let _cleanTxt = msg.number.toString().replace(/\D/g, "").replace(/^0+/, "");
        if (_cleanTxt.length === 10 && /^[6-9]/.test(_cleanTxt)) _cleanTxt = "91" + _cleanTxt;
        const chatId = _cleanTxt + "@c.us";

        try {
          const results = await chrome.scripting.executeScript({
            target: { tabId },
            world: "MAIN",
            func: async (chatId, message) => {
              try {
                if (!window.WPP || !window.WPP.chat || !window.WPP.chat.sendTextMessage) {
                  return { success: false, reason: "WPP library loaded nahi hai" };
                }
                if (window.WPP.webpack && window.WPP.webpack.isReady) {
                  await window.WPP.webpack.isReady;
                }
                const result = await window.WPP.chat.sendTextMessage(chatId, message, { waitForAck: false });
                return { success: true, method: "WPP_TEXT", msgId: result?.id?.toString?.() || "" };
              } catch (err) {
                return { success: false, reason: err.message || String(err) };
              }
            },
            args: [chatId, msg.message || ""],
          });

          const res = results?.[0]?.result;
          sendResponse(res || { success: false, reason: "Script execution mein result nahi aaya" });
        } catch (err) {
          console.warn("[WA Manager] WPP_SEND_TEXT scripting error:", err.message);
          sendResponse({ success: false, reason: err.message });
        }
        break;
      }

      case "SETUP_REMINDER_ALARM": {
        await setupReminderAlarm();
        await checkReminders();
        sendResponse({ ok: true });
        break;
      }
      case "GET_REMINDERS": {
        const remRes = await chrome.storage.local.get(REMIND_KEY);
        sendResponse({ reminders: remRes[REMIND_KEY] || [] });
        break;
      }
      case "SAVE_REMINDERS": {
        await chrome.storage.local.set({ [REMIND_KEY]: msg.reminders });
        sendResponse({ ok: true });
        break;
      }

      // ── Mark replied in all campaigns ──
      case "MARK_CAMPAIGN_REPLIED": {
        const campaigns = await getCampaigns();
        const inNum = (msg.number || "").replace(/\D/g, "");
        let changed = false;
        campaigns.forEach(camp => {
          camp.contacts.forEach(c => {
            const cNum = (c.number || "").replace(/\D/g, "");
            // Match last 10 digits (handles 91XXXXXXXXXX vs XXXXXXXXXX)
            if (cNum.slice(-10) === inNum.slice(-10) && !c.replied) {
              c.replied = true;
              c.repliedAt = new Date().toISOString();
              changed = true;
            }
          });
        });
        if (changed) await saveCampaigns(campaigns);
        sendResponse({ ok: true, changed });
        break;
      }

      // ── Campaigns ──
      case "GET_CAMPAIGNS": {
        const campaigns = await getCampaigns();
        sendResponse({ campaigns });
        break;
      }
      case "UPSERT_CAMPAIGN": {
        await upsertCampaign(msg.name, msg.contacts);
        sendResponse({ ok: true });
        break;
      }
      case "UPDATE_CAMPAIGN_CONTACT": {
        const cs = await getCampaigns();
        const ci = cs.findIndex(c => c.name === msg.campaignName);
        if (ci >= 0) {
          const cti = cs[ci].contacts.findIndex(c => c.number === msg.number);
          if (cti >= 0) cs[ci].contacts[cti] = { ...cs[ci].contacts[cti], ...msg.update };
          else cs[ci].contacts.push({ number: msg.number, ...msg.update });
          await saveCampaigns(cs);
        }
        sendResponse({ ok: true });
        break;
      }
      case "DELETE_CAMPAIGN": {
        const cs = await getCampaigns();
        await saveCampaigns(cs.filter(c => c.name !== msg.name));
        sendResponse({ ok: true });
        break;
      }

      // ── Follow-up sequences ──
      case "GET_FOLLOWUP_SEQUENCES": {
        const seqs = await getFollowupSequences();
        sendResponse({ seqs });
        break;
      }
      case "SAVE_FOLLOWUP_SEQUENCES": {
        await saveFollowupSequences(msg.seqs);
        sendResponse({ ok: true });
        break;
      }
      case "RUN_FOLLOWUP_NOW": {
        runFollowupSequences();
        sendResponse({ ok: true });
        break;
      }

      // ── Broadcast Blacklist ──
      case "GET_BROADCAST_BLACKLIST": {
        const bl = await getBroadcastBlacklist();
        sendResponse({ blacklist: bl });
        break;
      }
      case "SAVE_BROADCAST_BLACKLIST": {
        await saveBroadcastBlacklist(msg.blacklist);
        sendResponse({ ok: true });
        break;
      }

      // ── Resolve label contacts via content.js (needs MAIN world WPP) ──
      case "GET_LABEL_CONTACTS": {
        const waTabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
        if (waTabs.length === 0) { sendResponse({ contacts: [], error: "WhatsApp tab nahi mili" }); break; }
        try {
          const result = await chrome.tabs.sendMessage(waTabs[0].id, {
            type: "GET_LABEL_CONTACTS",
            labelId: msg.labelId,
          });
          sendResponse(result || { contacts: [] });
        } catch(e) {
          sendResponse({ contacts: [], error: e.message });
        }
        break;
      }


      // ── Two-Way Sheet Sync handlers ──────────────────────────────────────────
      case "UPDATE_SYNC_ALARMS": {
        await setupSyncAlarms();
        sendResponse({ ok: true });
        break;
      }

      case "RUN_AUTO_SYNC": {
        // Dashboard.js mein handleSyncNow call karo via tabs message
        const waTabs2 = await chrome.tabs.query({ url: "chrome-extension://*/*" });
        for (const t of waTabs2) {
          try {
            chrome.tabs.sendMessage(t.id, { type: "TRIGGER_AUTO_SYNC" });
          } catch(e) {}
        }
        sendResponse({ ok: true });
        break;
      }

      case "GS_SYNC_APPEND": {
        // background se sheet append call (scheduled messages ke baad status update ke liye)
        try {
          const syncData = await chrome.storage.local.get(["gs_sync_config", "gsSheetId", "SCRIPT_URL"]);
          const cfg = (syncData.gs_sync_config || {})[msg.gid || ""] || {};
          const scriptUrl = cfg.scriptUrl || syncData.SCRIPT_URL || "";
          const sheetId   = syncData.gsSheetId || "";
          if (!scriptUrl || !sheetId) { sendResponse({ ok: false, reason: "not configured" }); break; }

          const resp = await fetch(scriptUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              action: "appendRow",
              sheetId, gid: msg.gid || "",
              row: msg.row || {}, numCol: msg.numCol || "",
            }),
          });
          const data = await resp.json();
          sendResponse(data);
        } catch(e) {
          sendResponse({ ok: false, error: e.message });
        }
        break;
      }

      case "GS_SYNC_UPDATE": {
        try {
          const syncData = await chrome.storage.local.get(["gs_sync_config", "gsSheetId", "SCRIPT_URL"]);
          const cfg = (syncData.gs_sync_config || {})[msg.gid || ""] || {};
          const scriptUrl = cfg.scriptUrl || syncData.SCRIPT_URL || "";
          const sheetId   = syncData.gsSheetId || "";
          if (!scriptUrl || !sheetId) { sendResponse({ ok: false, reason: "not configured" }); break; }

          const resp = await fetch(scriptUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              action: "updateRow",
              sheetId, gid: msg.gid || "",
              number: msg.number || "", row: msg.row || {}, numCol: msg.numCol || "",
            }),
          });
          const data = await resp.json();
          sendResponse(data);
        } catch(e) {
          sendResponse({ ok: false, error: e.message });
        }
        break;
      }

      case "GS_SYNC_DELETE": {
        try {
          const syncData = await chrome.storage.local.get(["gs_sync_config", "gsSheetId", "SCRIPT_URL"]);
          const cfg = (syncData.gs_sync_config || {})[msg.gid || ""] || {};
          const scriptUrl = cfg.scriptUrl || syncData.SCRIPT_URL || "";
          const sheetId   = syncData.gsSheetId || "";
          if (!scriptUrl || !sheetId) { sendResponse({ ok: false, reason: "not configured" }); break; }

          const resp = await fetch(scriptUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              action: "deleteRow",
              sheetId, gid: msg.gid || "",
              number: msg.number || "", numCol: msg.numCol || "",
            }),
          });
          const data = await resp.json();
          sendResponse(data);
        } catch(e) {
          sendResponse({ ok: false, error: e.message });
        }
        break;
      }

      default:
        sendResponse({ error: "Unknown message type" });
    }
  })();

  return true; // keep channel open for async responses
});

// ─── Two-Way Sync Alarm Setup (setupSyncAlarms) ───────────────────────────
// BUG FIX: setupSyncAlarms function missing thi — yahan define ki
const ALARM_SYNC = "wa_manager_auto_sync";

async function setupSyncAlarms() {
  // Pehle purana alarm clear karo
  await chrome.alarms.clear(ALARM_SYNC);

  // gs_sync_config se sabhi tabs ka config padho
  const data = await chrome.storage.local.get(["gs_sync_config"]);
  const tabConfigs = data.gs_sync_config || {};

  // Koi bhi tab mein autoSync on hai? Sabse chhota interval lo
  let minInterval = null;
  for (const cfg of Object.values(tabConfigs)) {
    if (cfg.autoSync) {
      const interval = parseInt(cfg.autoSyncInterval) || 10;
      if (minInterval === null || interval < minInterval) {
        minInterval = interval;
      }
    }
  }

  if (minInterval !== null) {
    chrome.alarms.create(ALARM_SYNC, {
      delayInMinutes: minInterval,
      periodInMinutes: minInterval,
    });
    console.log("[WA Sync] Auto-sync alarm set:", minInterval, "min interval");
  } else {
    console.log("[WA Sync] Auto-sync disabled — no alarm created");
  }
}
