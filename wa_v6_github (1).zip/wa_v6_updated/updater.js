// ================================================================
// 🔄 UPDATER.JS — Auto Update Checker (Google Drive)
// Ye file check karti hai ki naya version available hai ya nahi
// ================================================================

(function () {
  "use strict";

  // ────────────────────────────────────────────────────────────────
  // STEP 1: Ye URL config.js mein set karo (neeche template diya hai)
  //         Yahan sirf fallback ke liye rakha hai
  // ────────────────────────────────────────────────────────────────
  const UPDATE_CHECK_INTERVAL_HOURS = 6; // Kitne ghante baad check kare
  const STORAGE_KEY_LAST_CHECK = "wa_updater_last_check";
  const STORAGE_KEY_DISMISSED = "wa_updater_dismissed_version";

  // ── Helper: config se URL lo ────────────────────────────────────
  function getVersionUrl() {
    if (typeof SUBSCRIPTION_CONFIG !== "undefined" && SUBSCRIPTION_CONFIG.VERSION_JSON_URL) {
      return SUBSCRIPTION_CONFIG.VERSION_JSON_URL;
    }
    return null;
  }

  // ── Helper: current version — HAMESHA manifest.json se ──────────
  // config.js mein VERSION rakhne ki zaroorat NAHI — sirf manifest.json update karo
  function getCurrentVersion() {
    return chrome.runtime.getManifest().version;
  }

  // ── Version compare: "4.0" > "3.2" ──────────────────────────────
  function isNewerVersion(remote, current) {
    const parse = (v) => String(v).split(".").map((x) => parseInt(x, 10) || 0);
    const r = parse(remote);
    const c = parse(current);
    for (let i = 0; i < Math.max(r.length, c.length); i++) {
      const rv = r[i] || 0;
      const cv = c[i] || 0;
      if (rv > cv) return true;
      if (rv < cv) return false;
    }
    return false;
  }

  // ── Main check function ──────────────────────────────────────────
  async function checkForUpdate(forceCheck = false) {
    const versionUrl = getVersionUrl();
    if (!versionUrl) {
      console.warn("[Updater] VERSION_JSON_URL config mein set nahi hai. Skipping update check.");
      return null;
    }

    // Throttle: X ghante se pehle dobara check nahi
    if (!forceCheck) {
      const stored = await chrome.storage.local.get(STORAGE_KEY_LAST_CHECK);
      const lastCheck = stored[STORAGE_KEY_LAST_CHECK] || 0;
      const hoursSince = (Date.now() - lastCheck) / (1000 * 60 * 60);
      if (hoursSince < UPDATE_CHECK_INTERVAL_HOURS) {
        console.log(`[Updater] Last check ${hoursSince.toFixed(1)}h ago. Skipping.`);
        return null;
      }
    }

    try {
      // Google Drive direct link: ?t= se cache bust karo
      const url = versionUrl + (versionUrl.includes("?") ? "&" : "?") + "t=" + Date.now();
      const resp = await fetch(url);
      if (!resp.ok) throw new Error("HTTP " + resp.status);
      const data = await resp.json();

      await chrome.storage.local.set({ [STORAGE_KEY_LAST_CHECK]: Date.now() });

      const remoteVersion = String(data.version || "");
      const currentVersion = getCurrentVersion();

      if (!remoteVersion) {
        console.warn("[Updater] version.json mein 'version' field nahi mila.");
        return null;
      }

      console.log(`[Updater] Remote: ${remoteVersion} | Current: ${currentVersion}`);

      if (isNewerVersion(remoteVersion, currentVersion)) {
        return {
          remoteVersion,
          currentVersion,
          downloadUrl: data.download_url || null,
          changelog: data.changelog || "",
          updateAvailable: true,
        };
      }
      return { updateAvailable: false, currentVersion, remoteVersion };
    } catch (e) {
      console.error("[Updater] Check failed:", e.message);
      return null;
    }
  }

  // ── Popup mein banner dikhao ─────────────────────────────────────
  function showUpdateBanner(info) {
    // Agar user ne is version ko dismiss kiya hai to mat dikhao
    chrome.storage.local.get(STORAGE_KEY_DISMISSED, (res) => {
      if (res[STORAGE_KEY_DISMISSED] === info.remoteVersion) return;

      // Banner element banao
      const existing = document.getElementById("wa-updater-banner");
      if (existing) existing.remove();

      const banner = document.createElement("div");
      banner.id = "wa-updater-banner";
      banner.style.cssText = `
        background: linear-gradient(135deg, #16a34a, #15803d);
        color: white;
        padding: 10px 12px;
        font-size: 12px;
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
        border-bottom: 2px solid #14532d;
        animation: slideDown 0.3s ease;
      `;

      const changelog = info.changelog
        ? `<div style="font-size:11px;opacity:0.85;margin-top:3px;width:100%">📝 ${info.changelog}</div>`
        : "";

      banner.innerHTML = `
        <span style="font-size:16px">🔄</span>
        <div style="flex:1">
          <strong>Update Available! v${info.remoteVersion}</strong>
          <span style="opacity:0.8;margin-left:4px">(Current: v${info.currentVersion})</span>
          ${changelog}
        </div>
        <button id="wa-update-download-btn" style="
          background: white;
          color: #16a34a;
          border: none;
          border-radius: 6px;
          padding: 5px 10px;
          font-size: 11px;
          font-weight: 700;
          cursor: pointer;
          white-space: nowrap;
        ">⬇️ Download</button>
        <button id="wa-update-dismiss-btn" style="
          background: transparent;
          color: white;
          border: 1px solid rgba(255,255,255,0.5);
          border-radius: 6px;
          padding: 5px 8px;
          font-size: 11px;
          cursor: pointer;
        ">✕</button>
      `;

      // Body ke top mein insert karo
      document.body.insertBefore(banner, document.body.firstChild);

      // Download button
      document.getElementById("wa-update-download-btn").addEventListener("click", () => {
        if (info.downloadUrl) {
          // Auto-download ZIP
          chrome.downloads
            ? chrome.downloads.download({ url: info.downloadUrl, saveAs: false })
            : window.open(info.downloadUrl, "_blank");
        }
        banner.innerHTML = `
          <span style="font-size:16px">✅</span>
          <div style="flex:1">
            <strong>Download shuru ho gaya!</strong>
            <div style="font-size:11px;opacity:0.85;margin-top:2px">
              ZIP download hone ke baad:<br>
              1. Unzip karo<br>
              2. Chrome mein chrome://extensions kholo<br>
              3. Purani extension remove karo<br>
              4. "Load unpacked" se naya folder load karo
            </div>
          </div>
          <button id="wa-update-ok-btn" style="background:white;color:#16a34a;border:none;border-radius:6px;padding:5px 10px;font-size:11px;font-weight:700;cursor:pointer">OK</button>
        `;
        document.getElementById("wa-update-ok-btn").addEventListener("click", () => banner.remove());
      });

      // Dismiss button
      document.getElementById("wa-update-dismiss-btn").addEventListener("click", () => {
        chrome.storage.local.set({ [STORAGE_KEY_DISMISSED]: info.remoteVersion });
        banner.remove();
      });
    });
  }

  // ── Login check helper ───────────────────────────────────────────
  // Sirf logged-in users ko update dikhao
  async function isUserLoggedIn() {
    try {
      if (typeof Auth !== "undefined" && Auth.checkAuth) {
        const authResult = await Auth.checkAuth();
        return authResult && authResult.loggedIn === true;
      }
      // Auth module nahi mila — fallback: chrome.storage se session check karo
      const data = await chrome.storage.local.get(["wa_subscription_session"]);
      const session = data["wa_subscription_session"];
      if (!session) return false;
      // Session expire check
      if (Date.now() > session.sessionExpires) return false;
      return true;
    } catch (e) {
      console.warn("[Updater] Login check failed:", e.message);
      return false;
    }
  }

  // ── Public API ───────────────────────────────────────────────────
  window.WA_Updater = {
    checkForUpdate,
    showUpdateBanner,

    // Popup load hone par auto-check — SIRF LOGIN KE BAAD
    async autoCheck() {
      const loggedIn = await isUserLoggedIn();
      if (!loggedIn) {
        console.log("[Updater] User logged in nahi hai — update check skip.");
        return null;
      }
      const result = await checkForUpdate(false);
      if (result && result.updateAvailable) {
        showUpdateBanner(result);
      }
      return result;
    },

    // Force check (button click se) — SIRF LOGIN KE BAAD
    async forceCheck() {
      const loggedIn = await isUserLoggedIn();
      if (!loggedIn) {
        console.log("[Updater] User logged in nahi hai — force check skip.");
        return null;
      }
      const result = await checkForUpdate(true);
      if (result && result.updateAvailable) {
        showUpdateBanner(result);
      }
      return result;
    },

    // Login hone ke turant baad call karo — ek baar check karo
    async checkAfterLogin() {
      const result = await checkForUpdate(true); // force = true (fresh check)
      if (result && result.updateAvailable) {
        showUpdateBanner(result);
      }
      return result;
    },
  };

  console.log("[Updater] WA_Updater ready. Version:", getCurrentVersion());
})();
