# WhatsApp Unsaved Number Manager — Chrome Extension

A powerful Chrome Extension that automatically detects and manages unsaved WhatsApp numbers from WhatsApp Web, with bulk messaging, scheduling, and a full dashboard.

---

## 📦 Installation (Developer Mode)

1. **Download** and unzip the extension folder.
2. Open Chrome and go to: `chrome://extensions/`
3. Enable **Developer Mode** (toggle in top-right corner).
4. Click **"Load unpacked"**.
5. Select the `whatsapp-extension` folder.
6. The extension icon will appear in your Chrome toolbar.

---

## 🚀 How to Use

### Step 1 — Open WhatsApp Web
Go to [https://web.whatsapp.com](https://web.whatsapp.com) and scan the QR code to log in.

### Step 2 — Let it detect numbers
The extension automatically monitors incoming chats. When a message arrives from an **unsaved number** (a number shown as digits rather than a contact name), it is captured and stored.

A floating notification badge will appear in WhatsApp Web when a new number is detected.

### Step 3 — Open the Dashboard
Click the extension icon → **Dashboard** button, or navigate directly to the dashboard tab.

---

## ✨ Features

| Feature | Description |
|---------|-------------|
| 🔍 Auto-detection | Detects unsaved numbers from chat list in real time |
| 📊 Dashboard | Full table view with search, filter, sort, and edit |
| 💬 Messaging | Send custom messages to individual or bulk numbers |
| 📅 Scheduler | Daily automated messaging at a set time |
| 📋 Templates | Save reusable message templates with `{{name}}` variables |
| 📤 Export | Export all numbers to CSV |
| 📥 Import | Import numbers from CSV |
| 🔒 Blacklist | Block numbers from receiving messages |
| 💾 Backup | Full JSON backup and restore |
| 🌙 Dark Mode | Toggle dark theme |
| 🇮🇳 India Detection | Automatically detects Indian phone numbers |

---

## ⚠️ Important Notes

- This extension **only reads** from WhatsApp Web's visible chat list. It does not hack, intercept, or bypass WhatsApp's security.
- Use the messaging features **responsibly**. Excessive automated messaging may violate WhatsApp's Terms of Service.
- Random delays between messages (configurable) help avoid detection as spam.
- The extension stores all data **locally** in your browser using Chrome Storage API — no data leaves your device.

---

## 📁 File Structure

```
whatsapp-extension/
├── manifest.json        # Chrome Extension MV3 config
├── content.js           # WhatsApp Web integration & number detection
├── content.css          # Floating badge styles for WhatsApp Web
├── background.js        # Service worker: storage, alarms, scheduling
├── popup.html           # Extension popup
├── popup.css            # Popup styles
├── popup.js             # Popup logic
├── dashboard.html       # Full-featured dashboard page
├── dashboard.css        # Dashboard styles
├── dashboard.js         # Dashboard logic
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```

---

## 🛠️ Message Variables

Use these placeholders in message templates:

| Variable | Replaced With |
|----------|---------------|
| `{{name}}` | The phone number (since name is unknown) |
| `{{number}}` | The phone number |
| `{{date}}` | Today's date |

Example: `Hello {{name}}, thank you for reaching out! How can we help you?`

---

## 🔐 Permissions Explained

| Permission | Reason |
|-----------|--------|
| `storage` | Save numbers and settings locally |
| `alarms` | Daily scheduled messaging |
| `notifications` | Alert when new number detected |
| `tabs` | Open WhatsApp Web chats |
| `scripting` | Inject content script into WhatsApp Web |

---

## 📞 Troubleshooting

**Numbers not being detected?**
- Make sure you're on `https://web.whatsapp.com`
- Click the extension popup → **Rescan** button
- WhatsApp Web must be fully loaded (QR code scanned)

**Extension not loading?**
- Check `chrome://extensions/` for error messages
- Make sure Developer Mode is ON
- Try reloading the extension

---

*Built with ❤️ using Chrome Extension Manifest V3, Vanilla JS, and CSS.*
