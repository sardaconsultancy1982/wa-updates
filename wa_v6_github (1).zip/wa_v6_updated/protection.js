// ═══════════════════════════════════════════════════════════
// 🔒 PROTECTION.JS — Anti Copy / Anti Inspect / Anti Save
// Chrome Extension CSP compatible — NO inline scripts
// ═══════════════════════════════════════════════════════════

(function() {

  // 1. Right-click (Context Menu) disable
  document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
    e.stopPropagation();
    return false;
  }, true);

  // 2. Keyboard shortcuts block
  document.addEventListener('keydown', function(e) {
    // Ctrl+U = View Source
    if (e.ctrlKey && (e.key === 'u' || e.key === 'U')) {
      e.preventDefault(); e.stopImmediatePropagation(); return false;
    }
    // Ctrl+S = Save
    if (e.ctrlKey && (e.key === 's' || e.key === 'S')) {
      e.preventDefault(); e.stopImmediatePropagation(); return false;
    }
    // Ctrl+P = Print
    if (e.ctrlKey && (e.key === 'p' || e.key === 'P')) {
      e.preventDefault(); e.stopImmediatePropagation(); return false;
    }
    // Ctrl+Shift+I = DevTools Elements
    if (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'i')) {
      e.preventDefault(); e.stopImmediatePropagation(); return false;
    }
    // Ctrl+Shift+J = DevTools Console
    if (e.ctrlKey && e.shiftKey && (e.key === 'J' || e.key === 'j')) {
      e.preventDefault(); e.stopImmediatePropagation(); return false;
    }
    // Ctrl+Shift+C = DevTools Inspector
    if (e.ctrlKey && e.shiftKey && (e.key === 'C' || e.key === 'c')) {
      e.preventDefault(); e.stopImmediatePropagation(); return false;
    }
    // F12 = DevTools
    if (e.key === 'F12') {
      e.preventDefault(); e.stopImmediatePropagation(); return false;
    }
    // Ctrl+A = Select All
    if (e.ctrlKey && (e.key === 'a' || e.key === 'A')) {
      e.preventDefault(); e.stopImmediatePropagation(); return false;
    }
    // Ctrl+C = Copy
    if (e.ctrlKey && (e.key === 'c' || e.key === 'C')) {
      e.preventDefault(); e.stopImmediatePropagation(); return false;
    }
    // Ctrl+X = Cut
    if (e.ctrlKey && (e.key === 'x' || e.key === 'X')) {
      e.preventDefault(); e.stopImmediatePropagation(); return false;
    }
  }, true); // <-- capture phase = sabse pehle fire hota hai

  // 3. Copy event block
  document.addEventListener('copy', function(e) {
    e.preventDefault();
    e.stopImmediatePropagation();
    return false;
  }, true);

  // 4. Cut event block
  document.addEventListener('cut', function(e) {
    e.preventDefault();
    e.stopImmediatePropagation();
    return false;
  }, true);

  // 5. Text selection block
  document.addEventListener('selectstart', function(e) {
    // Input fields mein allow karo (login ke liye)
    if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA')) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    return false;
  }, true);

  // 6. Drag block
  document.addEventListener('dragstart', function(e) {
    e.preventDefault();
    e.stopImmediatePropagation();
    return false;
  }, true);

  // 7. Print block (Ctrl+P via beforeprint event)
  window.addEventListener('beforeprint', function(e) {
    e.preventDefault();
    e.stopImmediatePropagation();
    return false;
  }, true);

  // 8. DevTools open detection — window size difference method
  (function devToolsDetect() {
    let devToolsOpen = false;
    const threshold = 160;

    function check() {
      const widthDiff  = window.outerWidth  - window.innerWidth;
      const heightDiff = window.outerHeight - window.innerHeight;
      const isOpen = widthDiff > threshold || heightDiff > threshold;

      if (isOpen && !devToolsOpen) {
        devToolsOpen = true;
        // Page content wipe
        document.body.innerHTML =
          '<div style="display:flex;align-items:center;justify-content:center;' +
          'height:100vh;font-family:sans-serif;font-size:18px;font-weight:bold;' +
          'color:#c62828;background:#fff3f3;flex-direction:column;gap:12px;">' +
          '<span style="font-size:48px;">🔒</span>' +
          '<span>Unauthorized Access Detected</span>' +
          '<span style="font-size:13px;font-weight:400;color:#888;">DevTools use karna allowed nahi hai.</span>' +
          '</div>';
      } else if (!isOpen) {
        devToolsOpen = false;
      }
    }

    // Check every 800ms
    setInterval(check, 800);
  })();

})();
