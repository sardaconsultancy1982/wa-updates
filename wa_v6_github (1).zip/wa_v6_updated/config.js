// ================================================================
// ⚙️  CONFIG.JS — SIRF YE FILE UPDATE KARO
// Extension update karna ho to SIRF YE FILE badlo aur sab ko do
// ================================================================

const SUBSCRIPTION_CONFIG = {
  // 🔗 Google Apps Script URL
  SCRIPT_URL: "https://script.google.com/macros/s/AKfycbwsI7g4N-lEMzu0ZBFuO3MNA0jhL6IjK3Y4tGQgoOUfC0-5BIv9w_dxMKLWTL1KYVSr/exec",

  // 📛 App ka naam
  APP_NAME: "WA Bulk Sender",

  // 🔄 AUTO-UPDATE — GitHub + jsDelivr CDN
  VERSION_JSON_URL: "https://cdn.jsdelivr.net/gh/sardaconsultancy1982/wa-updates@main/version.json",
  DEFAULT_DOWNLOAD_URL: "https://cdn.jsdelivr.net/gh/sardaconsultancy1982/wa-updates@main/wa_extension.zip",

  // ⏱️ Session kitni der valid rahe (hours mein)
  SESSION_HOURS: 24,

  // 🔔 Kitne din pehle reminder aaye
  REMINDER_DAYS: 7,

  // 🔄 Background me subscription check interval (minutes)
  CHECK_INTERVAL_MINUTES: 60,
};

if (typeof chrome !== "undefined" && chrome.storage) {
  chrome.storage.local.set({
    "wa_version_json_url": SUBSCRIPTION_CONFIG.VERSION_JSON_URL,
  });
}
