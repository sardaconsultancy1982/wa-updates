/**
 * ================================================================
 * Code.gs — WA Manager Subscription Backend v6.0
 * ================================================================
 * v6.0 CHANGES (sheet_block system REMOVED):
 *   - ❌ SHEET_URL column hataya (COL.SHEET_URL removed)
 *   - ❌ SHEET_BLOCK column hataya (COL.SHEET_BLOCK removed)
 *   - ❌ handleUpdateSheetUrl() function hataya
 *   - ❌ _updateClientsSheet() aur Clients sheet hataya
 *   - ❌ sheetUrl parameter har jagah se hataya
 *   - ❌ sheet_block checks removed from _globalBlockCheck, handleVerify, handleCheckStatus
 *   - ❌ resetSheet admin action hataya
 *   - ✅ Sirf login_id (username/password) + machine_id block system hai
 *   - ✅ mobile_block feature barkarar hai (v5.3 se)
 *   - ✅ TOTAL_COLS 14 ho gaya (pehle 16 tha)
 * ================================================================
 */

const SHEET_ID       = "1jffMCW6fq9dR_RsqM9WGbP-YoXQBRmEXYtGnedBQfNE";
const ADMIN_PASSWORD = "admin@1234";
const ADMIN_KEY      = "123456";

const USERS_SHEET    = "Users";
const LOGS_SHEET     = "LoginLogs";
const MACHINES_SHEET = "Machines";

const COL = {
  USERNAME:     0,
  PASSWORD:     1,
  NAME:         2,
  PHONE:        3,
  EXPIRY:       4,
  STATUS:       5,
  CREATED_AT:   6,
  NOTES:        7,
  DEVICE_TOKEN: 8,
  MACHINE_BLOCK:9,
  LOGIN_COUNT:  10,
  LAST_LOGIN:   11,
  LAST_AGENT:   12,
  MOBILE_BLOCK: 13,  // v5.3 — Mobile Dashboard Block
};
const TOTAL_COLS = 14;

const USERS_HEADERS = [
  "username","password","name","phone","expiry","status","created_at","notes",
  "device_token","machine_block","login_count","last_login","last_agent",
  "mobile_block"
];

const LOG = {
  TIMESTAMP:  0, USERNAME: 1, STATUS: 2, IP: 3,
  DEVICE: 4, BROWSER: 5, OS: 6, LOCATION: 7,
  FAIL_REASON: 8, MACHINE_ID: 9,
};
const LOGS_HEADERS = ["Timestamp","Username","Status","IP Address","Device","Browser","OS","Location","Fail Reason","Machine ID"];

// ══════════════════════════════════════════════════════════════
// 🏗️ AUTO SETUP
// ══════════════════════════════════════════════════════════════
function setupSheets() {
  const ss = SpreadsheetApp.openById(SHEET_ID);

  let usersSheet = ss.getSheetByName(USERS_SHEET);
  if (!usersSheet) { usersSheet = ss.insertSheet(USERS_SHEET); }
  _ensureExactHeaders(usersSheet, USERS_HEADERS, "#25d366");

  let logsSheet = ss.getSheetByName(LOGS_SHEET);
  if (!logsSheet) { logsSheet = ss.insertSheet(LOGS_SHEET); }
  _ensureExactHeaders(logsSheet, LOGS_HEADERS, "#1a73e8");

  let machinesSheet = ss.getSheetByName(MACHINES_SHEET);
  if (!machinesSheet) {
    machinesSheet = ss.insertSheet(MACHINES_SHEET);
    _ensureExactHeaders(machinesSheet, ["machine_id","username","registered_at","last_seen","status"], "#7c3aed");
  }

  return { ok: true, message: "✅ Sare sheets aur columns setup ho gaye! (v6.0 — sheet_block system removed)" };
}

function _ensureExactHeaders(sheet, headers, bgColor) {
  const lastCol = sheet.getLastColumn();
  let existing = [];
  if (lastCol > 0) {
    existing = sheet.getRange(1, 1, 1, lastCol).getValues()[0].map(String);
  }
  const toAdd = headers.filter(h => !existing.includes(h));
  if (toAdd.length > 0) {
    sheet.getRange(1, lastCol + 1, 1, toAdd.length).setValues([toAdd]);
  }
  const totalCols = Math.max(lastCol, headers.length);
  if (totalCols > 0 && bgColor) {
    sheet.getRange(1, 1, 1, totalCols)
      .setBackground(bgColor).setFontColor("#ffffff").setFontWeight("bold");
    sheet.setFrozenRows(1);
  }
}

// ══════════════════════════════════════════════════════════════
// 🛡️ GLOBAL BLOCK MIDDLEWARE
// ══════════════════════════════════════════════════════════════
/**
 * Checks machine_block, mobile_block, status for a user.
 * mobile_block check tabhi hoga jab request mein "source=mobile" ya "source=dashboard" ho.
 * BYPASS actions: admin, adminApi, setup, getLogs, verify, checkStatus
 */
function _globalBlockCheck(e) {
  const action = (e.parameter.action || "").trim();
  const BYPASS_ACTIONS = ["admin","adminApi","setup","getLogs","verify","checkStatus"];
  if (BYPASS_ACTIONS.includes(action)) return null;

  const adminKey = (e.parameter.adminKey || "").trim();
  if (adminKey === ADMIN_KEY || adminKey === ADMIN_PASSWORD) return null;

  const username = (e.parameter.username || "").trim().toLowerCase();
  if (!username) return null;

  const source = (e.parameter.source || "").trim().toLowerCase();
  const isMobileSource = source === "mobile" || source === "dashboard";

  try {
    const sheet = getSheet(USERS_SHEET);
    if (!sheet) return null;
    const data = sheet.getDataRange().getValues();
    for (let i = 1; i < data.length; i++) {
      const row = data[i];
      const rowUser = String(row[COL.USERNAME] || "").trim().toLowerCase();
      if (rowUser !== username) continue;

      const machineBlk = String(row[COL.MACHINE_BLOCK] || "").trim().toLowerCase();
      const mobileBlk  = String(row[COL.MOBILE_BLOCK]  || "").trim().toLowerCase();
      const status     = String(row[COL.STATUS]         || "").trim().toLowerCase();

      if (machineBlk === "yes") {
        return { blocked: true, success: false, ok: false, valid: false,
          reason: "machine_blocked",
          message: "🖥️ Aapki machine block kar di gayi hai. Admin se contact karo." };
      }
      if (mobileBlk === "yes" && isMobileSource) {
        return { blocked: true, success: false, ok: false, valid: false,
          reason: "mobile_blocked",
          message: "📱 Aapka mobile dashboard block kar diya gaya hai. Admin se contact karo." };
      }
      if (status === "blocked") {
        return { blocked: true, success: false, ok: false, valid: false,
          reason: "account_blocked",
          message: "🚫 Aapka account block hai. Admin se contact karo." };
      }
      if (status === "inactive") {
        return { blocked: true, success: false, ok: false, valid: false,
          reason: "inactive",
          message: "🚫 Account inactive hai. Admin se contact karo." };
      }
      return null;
    }
  } catch(err) {
    console.error("Block check error:", err.message);
  }
  return null;
}

// ══════════════════════════════════════════════════════════════
// 🔁 MAIN HANDLER
// ══════════════════════════════════════════════════════════════
function doGet(e) {
  try {
    _autoSetup();

    const blockResult = _globalBlockCheck(e);
    if (blockResult) return jsonRes(blockResult);

    const action = (e.parameter.action || "").trim();

    if (action === "admin") {
      const pass = (e.parameter.adminPass || "").trim();
      if (pass !== ADMIN_PASSWORD) {
        return HtmlService.createHtmlOutput(adminLoginPage())
          .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
      }
      return HtmlService.createHtmlOutputFromFile("admin")
        .setTitle("WA Manager Admin Panel")
        .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
    }

    if (action === "verify")       return jsonRes(handleVerify(e));
    if (action === "checkStatus")  return jsonRes(handleCheckStatus(e));
    if (action === "getUserLogs")  return jsonRes(handleGetUserLogs(e));
    if (action === "getLogs")      return jsonRes(handleGetLogs(e));
    if (action === "setup")        return jsonRes(setupSheets());
    if (action === "adminApi") {
      const pass = (e.parameter.adminPass || "").trim();
      if (pass !== ADMIN_PASSWORD && (e.parameter.adminKey || "") !== ADMIN_KEY) {
        return jsonRes({ ok: false, error: "Unauthorized" });
      }
      return jsonRes(handleAdminApi(e));
    }

    return handleSheetActions(e);
  } catch(err) {
    return jsonRes({ ok: false, success: false, error: err.message });
  }
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents || "{}");
    const pseudoE = {
      parameter: {
        username:  body.username  || "",
        machineId: body.machineId || "",
        action:    body.action    || "",
        adminKey:  body.adminKey  || "",
        source:    body.source    || "",
      }
    };
    const blockResult = _globalBlockCheck(pseudoE);
    if (blockResult) return jsonRes(blockResult);

    const action  = body.action  || "";
    const sheetId = body.sheetId || "";
    const gid     = body.gid     || "";
    let result;
    switch(action) {
      case "appendRow": {
        const ss=SpreadsheetApp.openById(sheetId), sh=gid?getSheetByGid(ss,gid):ss.getSheets()[0];
        const rd=body.row||{}; ensureHeaders(sh,Object.keys(rd));
        const hd=sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0].map(String);
        sh.appendRow(hd.map(h=>rd[h]!==undefined?rd[h]:""));
        result={ok:true,rowIndex:sh.getLastRow()-1}; break;
      }
      case "updateRow": {
        const ss=SpreadsheetApp.openById(sheetId),sh=gid?getSheetByGid(ss,gid):ss.getSheets()[0];
        const rd=body.row||{},nc=body.numCol||"",num=body.number||"";
        const hd=sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0].map(String);
        const allD=sh.getDataRange().getValues();
        const nci=nc?hd.indexOf(nc):-1; let tIdx=-1;
        if(nci>=0&&num){const sn=num.replace(/\D/g,"").replace(/^0+/,"");for(let i=1;i<allD.length;i++){const cn=String(allD[i][nci]).replace(/\D/g,"").replace(/^0+/,"");if(cn===sn||cn.slice(-10)===sn.slice(-10)){tIdx=i;break;}}}
        else if(body.rowIndex>=0){tIdx=body.rowIndex;}
        if(tIdx<0){ensureHeaders(sh,Object.keys(rd));sh.appendRow(sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0].map(String).map(h=>rd[h]||""));result={ok:true,action:"appended"};}
        else{hd.forEach((h,ci)=>{if(rd[h]!==undefined)sh.getRange(tIdx+1,ci+1).setValue(rd[h]);});result={ok:true,action:"updated",rowIndex:tIdx};}
        break;
      }
      case "bulkWrite": {
        const ss=SpreadsheetApp.openById(sheetId),sh=gid?getSheetByGid(ss,gid):ss.getSheets()[0];
        const rows=body.rows||[],nc=body.numCol||"",mode=body.mode||"upsert";
        if(!rows.length){result={ok:true,added:0,updated:0};break;}
        ensureHeaders(sh,[...new Set(rows.flatMap(r=>Object.keys(r)))]);
        const hd=sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0].map(String);
        let added=0,updated=0;
        if(mode==="overwrite"){if(sh.getLastRow()>1)sh.getRange(2,1,sh.getLastRow()-1,sh.getLastColumn()).clearContent();const mat=rows.map(r=>hd.map(h=>r[h]||""));if(mat.length)sh.getRange(2,1,mat.length,hd.length).setValues(mat);added=rows.length;}
        else{const allD=sh.getDataRange().getValues();const nci=nc?hd.indexOf(nc):-1;const exMap={};if(nci>=0)for(let i=1;i<allD.length;i++){const cn=String(allD[i][nci]).replace(/\D/g,"").replace(/^0+/,"").slice(-10);if(cn)exMap[cn]=i+1;}
        for(const rd of rows){const n10=nc&&rd[nc]?String(rd[nc]).replace(/\D/g,"").replace(/^0+/,"").slice(-10):"";if(n10&&exMap[n10]){hd.forEach((h,ci)=>{if(rd[h]!==undefined&&rd[h]!=="")sh.getRange(exMap[n10],ci+1).setValue(rd[h]);});updated++;}else{sh.appendRow(hd.map(h=>rd[h]||""));if(n10)exMap[n10]=sh.getLastRow();added++;}}}
        result={ok:true,added,updated,total:rows.length}; break;
      }
      default: result={ok:false,error:"Unknown POST action: "+action};
    }
    return jsonRes(result);
  } catch(err) { return jsonRes({ok:false,error:err.message}); }
}

let _setupDone = false;
function _autoSetup() {
  if (_setupDone) return;
  try { setupSheets(); _setupDone = true; } catch(e) {}
}

// ══════════════════════════════════════════════════════════════
// 🔐 VERIFY LOGIN
// ══════════════════════════════════════════════════════════════
function handleVerify(e) {
  const username  = (e.parameter.username  || "").trim().toLowerCase();
  const password  = (e.parameter.password  || "").trim();
  const userAgent = (e.parameter.userAgent || "").trim();
  const platform  = (e.parameter.platform  || "").trim();
  let machineId   = (e.parameter.machineId || "").trim();
  const source    = (e.parameter.source    || "").trim().toLowerCase();

  if (!username || !password) return { success: false, message: "❌ Username aur Password dono daalo." };

  if (!machineId) {
    const raw = username + "_" + (userAgent || "unknown").substring(0, 30);
    machineId = "MID-" + Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, raw)
      .slice(0,8).map(b => (b & 0xff).toString(16).padStart(2,"0")).join("")
      .toUpperCase().substring(0,8);
  }

  const clientInfo = parseClientInfo(userAgent, platform);
  const ipInfo     = getIPInfo();
  const sheet      = getSheet(USERS_SHEET);
  if (!sheet) return { success: false, message: "❌ Users sheet nahi mili." };

  const data = sheet.getDataRange().getValues();
  const isMobileSource = source === "mobile" || source === "dashboard";

  for (let i = 1; i < data.length; i++) {
    const row     = data[i];
    const rowUser = String(row[COL.USERNAME] || "").trim().toLowerCase();
    if (rowUser !== username) continue;

    const rowPass        = String(row[COL.PASSWORD]     || "").trim();
    const rowExpiry      = String(row[COL.EXPIRY]       || "").trim();
    const rowName        = String(row[COL.NAME]         || "").trim();
    const rowStatus      = String(row[COL.STATUS]       || "active").trim().toLowerCase();
    const rowDeviceToken = String(row[COL.DEVICE_TOKEN] || "").trim();
    const rowMachineBlk  = String(row[COL.MACHINE_BLOCK]|| "").trim().toLowerCase();
    const rowMobileBlk   = String(row[COL.MOBILE_BLOCK] || "").trim().toLowerCase();

    if (rowPass !== password) {
      writeLog(username, "FAILED", ipInfo, clientInfo, "Wrong Password", machineId);
      return { success: false, message: "❌ Password galat hai." };
    }
    if (rowStatus === "inactive") { writeLog(username,"FAILED",ipInfo,clientInfo,"Account Inactive",machineId); return { success:false, message:"🚫 Account inactive hai." }; }
    if (rowStatus === "blocked")  { writeLog(username,"FAILED",ipInfo,clientInfo,"Account Blocked",machineId);  return { success:false, message:"🔒 Account block hai." }; }
    if (rowStatus === "pending")  { writeLog(username,"FAILED",ipInfo,clientInfo,"Account Pending",machineId);  return { success:false, message:"⏳ Account activate nahi hua." }; }
    if (rowMachineBlk === "yes")  { writeLog(username,"FAILED",ipInfo,clientInfo,"Machine Blocked",machineId);  return { success:false, message:"🖥️ Machine block hai." }; }

    if (rowMobileBlk === "yes" && isMobileSource) {
      writeLog(username,"FAILED",ipInfo,clientInfo,"Mobile Dashboard Blocked",machineId);
      return { success:false, message:"📱 Mobile dashboard block hai. Admin se contact karo." };
    }

    if (!rowExpiry) { writeLog(username,"FAILED",ipInfo,clientInfo,"No Expiry",machineId); return { success:false, message:"❌ Expiry set nahi hai." }; }
    const expiryDate = new Date(rowExpiry); expiryDate.setHours(23,59,59,999);
    const today = new Date();
    if (expiryDate < today) {
      const daysAgo = Math.ceil((today - expiryDate) / 86400000);
      writeLog(username,"FAILED",ipInfo,clientInfo,"Expired ("+daysAgo+"d ago)",machineId);
      return { success:false, message:"⏰ Subscription "+daysAgo+" din pehle expire hua.", expired:true };
    }

    if (rowDeviceToken === "") {
      sheet.getRange(i+1, COL.DEVICE_TOKEN+1).setValue(machineId);
      _updateMachinesSheet(machineId, username);
    } else if (rowDeviceToken !== machineId) {
      writeLog(username,"FAILED",ipInfo,clientInfo,"Machine Mismatch",machineId);
      return { success:false, message:"🖥️ Ye account doosri machine pe register hai." };
    }

    const loginCount = (parseInt(row[COL.LOGIN_COUNT]) || 0) + 1;
    const nowStr = new Date().toLocaleString("en-IN", {timeZone:"Asia/Kolkata"});
    const agentStr = (clientInfo.browser+"/"+clientInfo.os+"/"+clientInfo.deviceType).substring(0,150);
    sheet.getRange(i+1, COL.LOGIN_COUNT+1).setValue(loginCount);
    sheet.getRange(i+1, COL.LAST_LOGIN+1).setValue(nowStr);
    sheet.getRange(i+1, COL.LAST_AGENT+1).setValue(agentStr);

    const daysLeft = Math.ceil((expiryDate - today) / 86400000);
    writeLog(username,"SUCCESS",ipInfo,clientInfo,"",machineId);
    return {
      success:true, name:rowName||username, expiry:rowExpiry, daysLeft,
      machineId,
      message:"✅ Login successful! "+daysLeft+" din baaki.",
      loginInfo:{ ip:ipInfo.ip, location:ipInfo.location, device:clientInfo.deviceType, browser:clientInfo.browser, os:clientInfo.os, time:nowStr }
    };
  }

  writeLog(username,"FAILED",ipInfo,clientInfo,"Username Not Found",machineId);
  return { success:false, message:"❌ Username nahi mila." };
}

function _updateMachinesSheet(machineId, username) {
  try {
    const ss = SpreadsheetApp.openById(SHEET_ID);
    let sh = ss.getSheetByName(MACHINES_SHEET);
    if (!sh) return;
    const now = new Date().toLocaleString("en-IN",{timeZone:"Asia/Kolkata"});
    const data = sh.getDataRange().getValues();
    for (let i=1; i<data.length; i++) {
      if (String(data[i][0]||"") === machineId) { sh.getRange(i+1,4).setValue(now); return; }
    }
    sh.appendRow([machineId, username, now, now, "active"]);
  } catch(e) {}
}

// ══════════════════════════════════════════════════════════════
// 🔄 LIVE STATUS CHECK
// ══════════════════════════════════════════════════════════════
function handleCheckStatus(e) {
  const username  = (e.parameter.username  || "").trim().toLowerCase();
  const machineId = (e.parameter.machineId || "").trim();
  const source    = (e.parameter.source    || "").trim().toLowerCase();

  if (!username) return { valid:false, reason:"no_username", message:"❌ Session invalid." };
  const sheet = getSheet(USERS_SHEET);
  if (!sheet) return { valid:true };
  const data = sheet.getDataRange().getValues();
  const isMobileSource = source === "mobile" || source === "dashboard";

  for (let i=1; i<data.length; i++) {
    const row = data[i];
    if (String(row[COL.USERNAME]||"").trim().toLowerCase() !== username) continue;
    const st  = String(row[COL.STATUS]       ||"").trim().toLowerCase();
    const dt  = String(row[COL.DEVICE_TOKEN] ||"").trim();
    const exp = String(row[COL.EXPIRY]       ||"").trim();
    const mb  = String(row[COL.MACHINE_BLOCK]||"").trim().toLowerCase();
    const mob = String(row[COL.MOBILE_BLOCK] ||"").trim().toLowerCase();

    if (st==="blocked")  return {valid:false,reason:"blocked",        message:"🚫 Account block hai."};
    if (st==="pending")  return {valid:false,reason:"pending",        message:"⏳ Account pending hai."};
    if (st==="inactive") return {valid:false,reason:"inactive",       message:"🚫 Account inactive hai."};
    if (mb==="yes")      return {valid:false,reason:"machine_blocked",message:"🖥️ Machine block hai."};

    if (mob==="yes" && isMobileSource) {
      return {valid:false, reason:"mobile_blocked", message:"📱 Mobile dashboard block hai. Admin se contact karo."};
    }

    if (exp) { const d=new Date(exp); d.setHours(23,59,59,999); if(Date.now()>d.getTime()) return {valid:false,reason:"expired",message:"⏰ Subscription expire ho gaya."}; }
    if (dt && machineId && dt !== machineId) return {valid:false,reason:"machine_mismatch",message:"🖥️ Account doosri machine par hai."};

    return { valid:true };
  }
  return { valid:false, reason:"user_not_found", message:"❌ Account nahi mila." };
}

// ══════════════════════════════════════════════════════════════
// 📋 LOGS
// ══════════════════════════════════════════════════════════════
function writeLog(username, status, ipInfo, clientInfo, failReason, machineId) {
  try {
    const ss = SpreadsheetApp.openById(SHEET_ID);
    let logSheet = ss.getSheetByName(LOGS_SHEET);
    if (!logSheet) {
      logSheet = ss.insertSheet(LOGS_SHEET);
      logSheet.getRange(1,1,1,LOGS_HEADERS.length).setValues([LOGS_HEADERS])
        .setBackground("#1a73e8").setFontColor("#ffffff").setFontWeight("bold");
      logSheet.setFrozenRows(1);
    }
    const istTime = Utilities.formatDate(new Date(),"Asia/Kolkata","dd/MM/yyyy HH:mm:ss");
    logSheet.appendRow([istTime,username,status,ipInfo.ip||"N/A",clientInfo.deviceType||"Unknown",clientInfo.browser||"Unknown",clientInfo.os||"Unknown",ipInfo.location||"N/A",failReason||"",machineId||""]);
    const nr = logSheet.getLastRow();
    logSheet.getRange(nr,1,1,10).setBackground(status==="SUCCESS"?"#d4edda":"#f8d7da");
  } catch(e) { console.error("Log error:",e.message); }
}

function handleGetUserLogs(e) {
  const username = (e.parameter.username||"").trim().toLowerCase();
  const password = (e.parameter.password||"").trim();
  const sheet = getSheet(USERS_SHEET);
  if (!sheet) return {success:false,message:"Sheet nahi mili."};
  const data = sheet.getDataRange().getValues();
  let valid = false;
  for (let i=1;i<data.length;i++) {
    if (String(data[i][COL.USERNAME]||"").trim().toLowerCase()===username && String(data[i][COL.PASSWORD]||"").trim()===password) { valid=true; break; }
  }
  if (!valid) return {success:false,message:"❌ Invalid credentials."};
  try {
    const ls = SpreadsheetApp.openById(SHEET_ID).getSheetByName(LOGS_SHEET);
    if (!ls) return {success:true,logs:[]};
    const ld = ls.getDataRange().getValues();
    if (ld.length<=1) return {success:true,logs:[]};
    const hd = ld[0];
    const ul = ld.slice(1).filter(r=>String(r[LOG.USERNAME]||"").trim().toLowerCase()===username).map(r=>{const o={};hd.forEach((h,i)=>o[h]=r[i]);return o;}).reverse().slice(0,50);
    return {success:true,logs:ul};
  } catch(e) { return {success:false,message:e.message}; }
}

function handleGetLogs(e) {
  const adminKey = (e.parameter.adminKey||"").trim();
  if (adminKey !== ADMIN_KEY && adminKey !== ADMIN_PASSWORD) return {success:false,message:"Unauthorized"};
  try {
    const ls = SpreadsheetApp.openById(SHEET_ID).getSheetByName(LOGS_SHEET);
    if (!ls) return {success:true,logs:[]};
    const d = ls.getDataRange().getValues();
    if (d.length<=1) return {success:true,logs:[]};
    const hd = d[0];
    const logs = d.slice(1).map(r=>{const o={};hd.forEach((h,i)=>o[h]=r[i]);return o;}).reverse();
    return {success:true,logs:logs.slice(0,500)};
  } catch(e) { return {success:false,message:e.message}; }
}

// ══════════════════════════════════════════════════════════════
// 🛡️ ADMIN API
// ══════════════════════════════════════════════════════════════
function handleAdminApi(e) {
  const sub   = (e.parameter.sub || "").trim();
  const sheet = getSheet(USERS_SHEET);

  if (sub === "getUsers") {
    const data    = sheet.getDataRange().getValues();
    const headers = data[0];
    const users   = data.slice(1).filter(r => String(r[0]||"").trim() !== "").map(row => {
      const obj = {}; headers.forEach((h,i) => obj[h] = String(row[i]||"")); return obj;
    });
    return { ok:true, users };
  }

  if (sub === "updateUser") {
    const username = (e.parameter.username||"").trim().toLowerCase();
    const field    = (e.parameter.field   ||"").trim();
    const value    = (e.parameter.value   !== undefined ? e.parameter.value : "").trim();
    const user     = findUser(sheet, username);
    if (!user) return { ok:false, error:"User nahi mila: "+username };
    const colMap = {
      status:        COL.STATUS+1,
      expiry:        COL.EXPIRY+1,
      expiry_date:   COL.EXPIRY+1,
      password:      COL.PASSWORD+1,
      name:          COL.NAME+1,
      phone:         COL.PHONE+1,
      device_token:  COL.DEVICE_TOKEN+1,
      machine_block: COL.MACHINE_BLOCK+1,
      mobile_block:  COL.MOBILE_BLOCK+1,
      notes:         COL.NOTES+1,
    };
    if (!colMap[field]) return { ok:false, error:"Invalid field: "+field };
    sheet.getRange(user.rowIdx, colMap[field]).setValue(value);
    return { ok:true, message:username+" → "+field+" = "+value };
  }

  if (sub === "addUser") {
    const un = (e.parameter.username||"").trim().toLowerCase();
    const pw = (e.parameter.password||"").trim();
    const nm = (e.parameter.name    ||"").trim();
    const ph = (e.parameter.phone   ||"").trim();
    const ex = (e.parameter.expiry  ||"").trim();
    const nt = (e.parameter.notes   ||"").trim();
    const st = (e.parameter.status  ||"active").trim();
    if (!un || !pw || !ex) return { ok:false, error:"username, password, expiry required." };
    if (findUser(sheet, un)) return { ok:false, error:"User already exists: "+un };
    const newRow = Array(TOTAL_COLS).fill("");
    newRow[COL.USERNAME]      = un;
    newRow[COL.PASSWORD]      = pw;
    newRow[COL.NAME]          = nm;
    newRow[COL.PHONE]         = ph;
    newRow[COL.EXPIRY]        = ex;
    newRow[COL.STATUS]        = st;
    newRow[COL.NOTES]         = nt;
    newRow[COL.CREATED_AT]    = new Date().toLocaleString("en-IN",{timeZone:"Asia/Kolkata"});
    newRow[COL.MACHINE_BLOCK] = "no";
    newRow[COL.MOBILE_BLOCK]  = "no";
    newRow[COL.LOGIN_COUNT]   = 0;
    sheet.appendRow(newRow);
    return { ok:true, message:"User add hua: "+un };
  }

  if (sub === "deleteUser") {
    const username = (e.parameter.username||"").trim().toLowerCase();
    const data = sheet.getDataRange().getValues();
    for (let i=1; i<data.length; i++) {
      if (String(data[i][COL.USERNAME]||"").trim().toLowerCase() === username) {
        sheet.deleteRow(i+1);
        return { ok:true, message:username+" delete ho gaya." };
      }
    }
    return { ok:false, error:"User nahi mila: "+username };
  }

  if (sub === "resetMachine") {
    const username = (e.parameter.username||"").trim().toLowerCase();
    const user = findUser(sheet, username);
    if (!user) return { ok:false, error:"User nahi mila." };
    sheet.getRange(user.rowIdx, COL.DEVICE_TOKEN+1).setValue("");
    sheet.getRange(user.rowIdx, COL.MACHINE_BLOCK+1).setValue("no");
    return { ok:true, message:username+" ki machine ID reset ho gayi." };
  }

  if (sub === "resetMobile") {
    const username = (e.parameter.username||"").trim().toLowerCase();
    const user = findUser(sheet, username);
    if (!user) return { ok:false, error:"User nahi mila." };
    sheet.getRange(user.rowIdx, COL.MOBILE_BLOCK+1).setValue("no");
    return { ok:true, message:username+" ka mobile dashboard unblock ho gaya." };
  }

  if (sub === "getMachines") {
    try {
      const ms = SpreadsheetApp.openById(SHEET_ID).getSheetByName(MACHINES_SHEET);
      let machines = [];
      if (ms) {
        const d = ms.getDataRange().getValues();
        if (d.length > 1) {
          const hd = d[0];
          machines = d.slice(1).filter(r => String(r[0]||"").trim()).map(r => { const o={}; hd.forEach((h,i) => o[h]=String(r[i]||"")); return o; });
        }
      }
      if (!machines.length) {
        const usersData = sheet.getDataRange().getValues();
        machines = usersData.slice(1)
          .filter(r => String(r[COL.USERNAME]||"").trim() && String(r[COL.DEVICE_TOKEN]||"").trim())
          .map(r => ({
            machine_id:    String(r[COL.DEVICE_TOKEN] ||""),
            username:      String(r[COL.USERNAME]     ||""),
            registered_at: String(r[COL.CREATED_AT]   ||"—"),
            last_seen:     String(r[COL.LAST_LOGIN]    ||"—"),
            status:        String(r[COL.MACHINE_BLOCK] ||"").toLowerCase() === "yes" ? "blocked" : "active",
          }));
      }
      return { ok:true, machines };
    } catch(e) { return { ok:false, error:e.message }; }
  }

  if (sub === "getStats") {
    const data = sheet.getDataRange().getValues();
    const users = data.slice(1).filter(r => String(r[0]||"").trim());
    const today = new Date(); today.setHours(0,0,0,0);
    const in7 = new Date(today); in7.setDate(in7.getDate()+7);
    return {
      ok:true,
      total:         users.length,
      active:        users.filter(u=>String(u[COL.STATUS]||"").toLowerCase()==="active").length,
      blocked:       users.filter(u=>String(u[COL.STATUS]||"").toLowerCase()==="blocked").length,
      pending:       users.filter(u=>String(u[COL.STATUS]||"").toLowerCase()==="pending").length,
      inactive:      users.filter(u=>String(u[COL.STATUS]||"").toLowerCase()==="inactive").length,
      expiring:      users.filter(u=>{ const exp=new Date(String(u[COL.EXPIRY]||"")); exp.setHours(23,59,59,999); return exp>=today && exp<=in7; }).length,
      mobile_blocked:users.filter(u=>String(u[COL.MOBILE_BLOCK]||"").toLowerCase()==="yes").length,
    };
  }

  return { ok:false, error:"Unknown sub: "+sub };
}

// ══════════════════════════════════════════════════════════════
// 🌐 SHEET DATA ACTIONS
// ══════════════════════════════════════════════════════════════
function handleSheetActions(e) {
  const action  = (e.parameter.action ||"").trim();
  const sheetId = (e.parameter.sheetId||"").trim();
  const gid     = (e.parameter.gid    ||"").trim();
  let result;
  switch(action) {
    case "getAllTabs": {
      if (!sheetId) throw new Error("sheetId missing");
      const tabs = SpreadsheetApp.openById(sheetId).getSheets().map(s=>({name:s.getName(),gid:String(s.getSheetId())}));
      result = {ok:true,tabs}; break;
    }
    case "readSheet": {
      if (!sheetId) throw new Error("sheetId missing");
      const ss2 = SpreadsheetApp.openById(sheetId);
      const sh2 = gid ? getSheetByGid(ss2,gid) : ss2.getSheets()[0];
      if (!sh2) throw new Error("Tab nahi mili");
      const vals = sh2.getDataRange().getValues();
      if (!vals.length) { result={ok:true,headers:[],rows:[]}; break; }
      const hd = vals[0].map(String);
      const rows = vals.slice(1).map(r=>{const o={};hd.forEach((h,i)=>o[h]=String(r[i]||""));return o;});
      result = {ok:true,headers:hd,rows,totalRows:rows.length}; break;
    }
    case "checkSubscription": case "check": result={ok:true,status:"active"}; break;
    case "dashboard": return serveDashboard(e);
    case "updateCell": {
      const sid=e.parameter.sheetId||"", tn=e.parameter.tabName||"", num=String(e.parameter.number||"").replace(/\D/g,"").replace(/^0+/,""), cn=e.parameter.colName||"", val=e.parameter.value!==undefined?e.parameter.value:"";
      if (!sid) return jsonRes({ok:false,error:"sheetId missing"});
      try {
        const ss3=SpreadsheetApp.openById(sid); let sh3;
        if (tn) sh3=ss3.getSheets().find(s=>s.getName()===tn);
        if (!sh3) sh3=ss3.getSheets()[0];
        const hd=sh3.getRange(1,1,1,sh3.getLastColumn()).getValues()[0].map(String);
        const tc=hd.indexOf(cn); if(tc<0) return jsonRes({ok:false,error:"Column nahi mila"});
        const allD=sh3.getDataRange().getValues();
        const pi=hd.findIndex(h=>/phone|number|mobile|whatsapp|contact/i.test(h));
        if(pi<0) return jsonRes({ok:false,error:"Phone column nahi mila"});
        const sn=num.slice(-10); let upd=false;
        for(let i=1;i<allD.length;i++){const cn2=String(allD[i][pi]||"").replace(/\D/g,"").replace(/^0+/,"").slice(-10);if(cn2===sn){sh3.getRange(i+1,tc+1).setValue(val);upd=true;break;}}
        return jsonRes({ok:upd,updated:upd});
      } catch(ex){return jsonRes({ok:false,error:ex.message});}
    }
    default: result={ok:false,error:"Unknown action: "+action};
  }
  return jsonRes(result);
}

// ══════════════════════════════════════════════════════════════
// 🌍 IP + CLIENT INFO
// ══════════════════════════════════════════════════════════════
function getIPInfo() {
  try {
    const r=UrlFetchApp.fetch("https://api.ipify.org?format=json",{muteHttpExceptions:true});
    if(r.getResponseCode()===200){
      const ip=JSON.parse(r.getContentText()).ip||"unknown";
      try{const g=UrlFetchApp.fetch("https://ipapi.co/"+ip+"/json/",{muteHttpExceptions:true});if(g.getResponseCode()===200){const geo=JSON.parse(g.getContentText());return{ip,location:(geo.city||"?")+", "+(geo.region||"?")+", "+(geo.country_name||"?")};}}catch(e2){}
      return{ip,location:"Location N/A"};
    }
  }catch(e){}
  return{ip:"Unknown",location:"Unknown"};
}

function parseClientInfo(userAgent, platform) {
  if(!userAgent) return{deviceType:"Unknown",browser:"Unknown",os:"Unknown"};
  const ua=userAgent.toLowerCase();
  const deviceType=/mobile|android.*mobile|iphone|ipod/.test(ua)?"Mobile":/tablet|ipad|android(?!.*mobile)/.test(ua)?"Tablet":"Desktop";
  const browser=ua.includes("edg/")?"Edge":(ua.includes("opr/")||ua.includes("opera"))?"Opera":ua.includes("chrome")?"Chrome":ua.includes("firefox")?"Firefox":ua.includes("safari")?"Safari":"Unknown";
  const os=ua.includes("windows nt 10")?"Windows 10/11":ua.includes("windows nt")?"Windows":ua.includes("android")?"Android "+(ua.match(/android ([\d.]+)/)||["",""])[1]:ua.includes("iphone os")?"iOS":ua.includes("mac os x")?"macOS":ua.includes("linux")?"Linux":"Unknown";
  return{deviceType,browser,os};
}

// ══════════════════════════════════════════════════════════════
// 🖥️ ADMIN LOGIN PAGE
// ══════════════════════════════════════════════════════════════
function adminLoginPage() {
  return `<!DOCTYPE html><html><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Login — WA Manager</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,sans-serif;background:#0f172a;color:#e2e8f0;min-height:100vh;display:flex;align-items:center;justify-content:center}
.box{background:#1e293b;border-radius:16px;padding:36px 28px;width:90%;max-width:380px;border:1px solid #334155;box-shadow:0 8px 32px #0008}
h2{color:#25d366;font-size:22px;margin-bottom:4px;text-align:center}
p{color:#64748b;font-size:13px;text-align:center;margin-bottom:28px}
label{font-size:11px;color:#94a3b8;margin-bottom:5px;display:block;font-weight:600;text-transform:uppercase;letter-spacing:.04em}
input{width:100%;padding:12px 14px;border-radius:8px;border:1.5px solid #334155;background:#0f172a;color:#e2e8f0;font-size:14px;margin-bottom:18px;outline:none;transition:.2s}
input:focus{border-color:#25d366}
button{width:100%;padding:13px;border-radius:8px;background:#25d366;color:#fff;font-size:15px;font-weight:700;border:none;cursor:pointer}
</style></head>
<body><div class="box">
<h2>🛡️ Admin Panel</h2>
<p>WA Manager v6.0 — Subscription Control</p>
<form method="get">
<input type="hidden" name="action" value="admin">
<label>Admin Password</label>
<input type="password" name="adminPass" placeholder="Password daalo" autofocus required>
<button type="submit">Login →</button>
</form>
</div></body></html>`;
}

// ══════════════════════════════════════════════════════════════
// 🔧 HELPERS
// ══════════════════════════════════════════════════════════════
function handleAdminApiFromHtml(params) {
  try {
    const e = { parameter: params };
    return handleAdminApi(e);
  } catch(err) {
    return { ok: false, error: err.message };
  }
}

function handleGetLogsFromHtml(params) {
  try {
    const ls = SpreadsheetApp.openById(SHEET_ID).getSheetByName(LOGS_SHEET);
    if (!ls) return { success: true, logs: [] };
    const d = ls.getDataRange().getValues();
    if (d.length <= 1) return { success: true, logs: [] };
    const hd = d[0];
    const logs = d.slice(1).map(r => { const o={}; hd.forEach((h,i) => o[h]=r[i]); return o; }).reverse();
    return { success: true, logs: logs.slice(0, 500) };
  } catch(err) {
    return { success: false, message: err.message };
  }
}

function jsonRes(data){return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);}
function getSheet(name){return SpreadsheetApp.openById(SHEET_ID).getSheetByName(name);}
function getSheetByGid(ss,gid){return ss.getSheets().find(s=>String(s.getSheetId())===String(gid))||null;}
function findUser(sheet,username){const data=sheet.getDataRange().getValues();for(let i=1;i<data.length;i++){if(String(data[i][COL.USERNAME]||"").trim().toLowerCase()===username.toLowerCase()){return{rowIdx:i+1,data:data[i]};}}return null;}
function ensureHeaders(sheet,newKeys){if(!newKeys||!newKeys.length)return;const lc=sheet.getLastColumn();if(lc===0){sheet.getRange(1,1,1,newKeys.length).setValues([newKeys]);return;}const ex=new Set(sheet.getRange(1,1,1,lc).getValues()[0].map(String));const ta=newKeys.filter(k=>k&&!ex.has(k));if(ta.length)sheet.getRange(1,lc+1,1,ta.length).setValues([ta]);}
function serveDashboard(e){return HtmlService.createHtmlOutput('<p style="font-family:sans-serif;padding:20px;color:#25d366;background:#0f172a;min-height:100vh">✅ Dashboard ready</p>').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);}
